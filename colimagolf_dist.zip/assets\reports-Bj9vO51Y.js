import{t as e}from"./dist-BN2bhVnw.js";var t=e(`https://tztolxgsaktqindoimtu.supabase.co`,`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR6dG9seGdzYWt0cWluZG9pbXR1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYyNzQ4ODAsImV4cCI6MjEwMTg1MDg4MH0.E2GABiOMXYb5hEwE9ErIcJa6_LHkj9lJUglQVoiLl0M`).schema(`colimaGC`),n=`this_month`,r=``,i=``,a=`AFLUENCIA`,o=[],s=[],c={};async function l(e){u(n),d(e),await p()}function u(e){let t=new Date,n=e=>String(e).padStart(2,`0`),a=e=>`${e.getFullYear()}-${n(e.getMonth()+1)}-${n(e.getDate())}`;if(e===`today`)r=a(t),i=a(t);else if(e===`this_week`){let e=t.getDay(),n=(e===0?-6:1)-e,o=new Date(t);o.setDate(t.getDate()+n);let s=new Date(o);s.setDate(o.getDate()+6),r=a(o),i=a(s)}else if(e===`this_month`){let e=new Date(t.getFullYear(),t.getMonth(),1),n=new Date(t.getFullYear(),t.getMonth()+1,0);r=a(e),i=a(n)}else if(e===`this_year`){let e=new Date(t.getFullYear(),0,1),n=new Date(t.getFullYear(),11,31);r=a(e),i=a(n)}}function d(e){e.innerHTML=`
        <div class="space-y-6 pb-12 animate-fade-in print:bg-white print:text-black">
            <!-- Header & Filter Bar -->
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl print:hidden">
                <div class="flex items-center gap-4">
                    <div class="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0 shadow-lg shadow-emerald-500/10">
                        <span class="material-icons" style="font-size:32px">insights</span>
                    </div>
                    <div>
                        <div class="flex items-center gap-2.5">
                            <h2 class="text-2xl font-black text-white uppercase tracking-tight">Reportes & Métricas Operativas</h2>
                            <span class="px-2.5 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-lg text-[10px] font-black uppercase">Analíticas</span>
                        </div>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Control de Jugadores, Carritos, Horas Pico, Ranking de Socios y Caja</p>
                    </div>
                </div>

                <!-- Export & Refresh Actions -->
                <div class="flex flex-wrap items-center gap-2.5">
                    <button id="btn-export-csv" class="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-md cursor-pointer">
                        <span class="material-icons text-emerald-400 text-base">download</span> Exportar Excel
                    </button>
                    <button id="btn-print-report" class="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-md cursor-pointer">
                        <span class="material-icons text-blue-400 text-base">print</span> Imprimir / PDF
                    </button>
                    <button id="btn-refresh-data" class="flex items-center gap-2 px-4 py-2.5 bg-primary hover:bg-primary/90 text-slate-900 rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-lg shadow-primary/20 cursor-pointer">
                        <span class="material-icons text-base">sync</span> Actualizar
                    </button>
                </div>
            </div>

            <!-- Date Range Controls -->
            <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 shadow-xl print:hidden">
                <div class="flex flex-wrap items-center gap-2" id="period-presets">
                    <button data-period="today" class="px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${n===`today`?`bg-primary text-slate-900 shadow-md shadow-primary/20`:`bg-slate-800/80 text-slate-400 hover:text-white`}">Hoy</button>
                    <button data-period="this_week" class="px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${n===`this_week`?`bg-primary text-slate-900 shadow-md shadow-primary/20`:`bg-slate-800/80 text-slate-400 hover:text-white`}">Esta Semana</button>
                    <button data-period="this_month" class="px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${n===`this_month`?`bg-primary text-slate-900 shadow-md shadow-primary/20`:`bg-slate-800/80 text-slate-400 hover:text-white`}">Este Mes</button>
                    <button data-period="this_year" class="px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${n===`this_year`?`bg-primary text-slate-900 shadow-md shadow-primary/20`:`bg-slate-800/80 text-slate-400 hover:text-white`}">Año Actual</button>
                    <button data-period="custom" class="px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${n===`custom`?`bg-primary text-slate-900 shadow-md shadow-primary/20`:`bg-slate-800/80 text-slate-400 hover:text-white`}">Personalizado</button>
                </div>

                <div class="flex items-center gap-2 bg-slate-950/80 border border-slate-800 p-1.5 rounded-xl">
                    <span class="material-icons text-slate-500 text-sm ml-2">date_range</span>
                    <input id="report-start-date" type="date" value="${r}" style="color-scheme: dark;"
                        class="bg-transparent text-white font-bold text-xs uppercase focus:outline-none cursor-pointer">
                    <span class="text-slate-600 font-black text-xs">AL</span>
                    <input id="report-end-date" type="date" value="${i}" style="color-scheme: dark;"
                        class="bg-transparent text-white font-bold text-xs uppercase focus:outline-none cursor-pointer mr-2">
                    <button id="btn-apply-custom-dates" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-primary border border-primary/30 rounded-lg text-xs font-black uppercase transition-all cursor-pointer">
                        Filtrar
                    </button>
                </div>
            </div>

            <!-- Print Header (Visible only when printing) -->
            <div class="hidden print:block mb-6 border-b-2 border-slate-900 pb-4">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-2xl font-black uppercase text-slate-900">Club de Golf Colima</h1>
                        <h2 class="text-base font-bold text-slate-700 uppercase">Informe Ejecutivo de Operaciones & Métricas</h2>
                    </div>
                    <div class="text-right text-xs font-bold text-slate-600">
                        <p>Periodo: <span class="font-black text-slate-900">${r} al ${i}</span></p>
                        <p>Generado: ${new Date().toLocaleString(`es-MX`)}</p>
                    </div>
                </div>
            </div>

            <!-- Top Summary KPI Cards -->
            <div id="reports-kpis" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                    <div>
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Jugadores</p>
                        <h3 id="kpi-total-players" class="text-3xl font-black text-white mt-1">...</h3>
                        <p id="kpi-players-breakdown" class="text-[10px] font-bold text-emerald-400 mt-1">Calculando...</p>
                    </div>
                    <div class="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                        <span class="material-icons">groups</span>
                    </div>
                </div>

                <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                    <div>
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Carritos Rentados</p>
                        <h3 id="kpi-total-carts" class="text-3xl font-black text-white mt-1">...</h3>
                        <p id="kpi-carts-income" class="text-[10px] font-bold text-teal-400 mt-1">Calculando...</p>
                    </div>
                    <div class="w-12 h-12 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-teal-400">
                        <span class="material-icons">electric_rickshaw</span>
                    </div>
                </div>

                <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                    <div>
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ingresos Totales (Caja)</p>
                        <h3 id="kpi-total-revenue" class="text-3xl font-black text-amber-400 mt-1">...</h3>
                        <p id="kpi-revenue-breakdown" class="text-[10px] font-bold text-slate-400 mt-1">Calculando...</p>
                    </div>
                    <div class="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                        <span class="material-icons">payments</span>
                    </div>
                </div>

                <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                    <div>
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Horario Pico</p>
                        <h3 id="kpi-peak-hour" class="text-2xl font-black text-white mt-1">...</h3>
                        <p id="kpi-peak-day" class="text-[10px] font-bold text-purple-400 mt-1">Calculando...</p>
                    </div>
                    <div class="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                        <span class="material-icons">schedule</span>
                    </div>
                </div>
            </div>

            <!-- Tab Navigation -->
            <div class="border-b border-slate-800 flex items-center gap-2 overflow-x-auto pb-1 print:hidden" id="report-tabs">
                <button data-tab="AFLUENCIA" class="report-tab-btn flex items-center gap-2 px-5 py-3 border-b-2 font-black text-xs uppercase tracking-wider transition-all cursor-pointer ${a===`AFLUENCIA`?`border-emerald-400 text-emerald-400 bg-emerald-500/5`:`border-transparent text-slate-400 hover:text-white`}">
                    <span class="material-icons text-base">bar_chart</span> Afluencia & Horas Pico
                </button>
                <button data-tab="CARRITOS" class="report-tab-btn flex items-center gap-2 px-5 py-3 border-b-2 font-black text-xs uppercase tracking-wider transition-all cursor-pointer ${a===`CARRITOS`?`border-teal-400 text-teal-400 bg-teal-500/5`:`border-transparent text-slate-400 hover:text-white`}">
                    <span class="material-icons text-base">electric_rickshaw</span> Renta de Carritos
                </button>
                <button data-tab="SOCIOS" class="report-tab-btn flex items-center gap-2 px-5 py-3 border-b-2 font-black text-xs uppercase tracking-wider transition-all cursor-pointer ${a===`SOCIOS`?`border-blue-400 text-blue-400 bg-blue-500/5`:`border-transparent text-slate-400 hover:text-white`}">
                    <span class="material-icons text-base">emoji_events</span> Ranking Socios & Fidelidad
                </button>
                <button data-tab="FINANZAS" class="report-tab-btn flex items-center gap-2 px-5 py-3 border-b-2 font-black text-xs uppercase tracking-wider transition-all cursor-pointer ${a===`FINANZAS`?`border-amber-400 text-amber-400 bg-amber-500/5`:`border-transparent text-slate-400 hover:text-white`}">
                    <span class="material-icons text-base">account_balance_wallet</span> Caja & Métodos de Pago
                </button>
            </div>

            <!-- Dynamic Tab Content -->
            <div id="reports-tab-content" class="space-y-6">
                <div class="py-16 text-center text-slate-500">
                    <div class="w-10 h-10 border-4 border-emerald-500/30 border-t-emerald-500 rounded-full animate-spin mx-auto mb-3"></div>
                    <p class="font-bold text-xs uppercase tracking-widest">Cargando métricas del periodo...</p>
                </div>
            </div>
        </div>
    `,f(e)}function f(e){let t=e.querySelectorAll(`#period-presets button`);t.forEach(a=>{a.onclick=async()=>{n=a.getAttribute(`data-period`),u(n),e.querySelector(`#report-start-date`).value=r,e.querySelector(`#report-end-date`).value=i,t.forEach(e=>{e.className=`px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${e===a?`bg-primary text-slate-900 shadow-md shadow-primary/20`:`bg-slate-800/80 text-slate-400 hover:text-white`}`}),await p()}});let o=e.querySelector(`#btn-apply-custom-dates`);o&&(o.onclick=async()=>{let a=e.querySelector(`#report-start-date`).value,o=e.querySelector(`#report-end-date`).value;!a||!o||(r=a,i=o,n=`custom`,t.forEach(e=>{e.className=`px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${e.getAttribute(`data-period`)===`custom`?`bg-primary text-slate-900 shadow-md shadow-primary/20`:`bg-slate-800/80 text-slate-400 hover:text-white`}`}),await p())});let s=e.querySelectorAll(`.report-tab-btn`);s.forEach(e=>{e.onclick=()=>{a=e.getAttribute(`data-tab`),s.forEach(t=>{let n=t===e,r=t.getAttribute(`data-tab`),i=r===`AFLUENCIA`?`emerald`:r===`CARRITOS`?`teal`:r===`SOCIOS`?`blue`:`amber`;t.className=`report-tab-btn flex items-center gap-2 px-5 py-3 border-b-2 font-black text-xs uppercase tracking-wider transition-all cursor-pointer ${n?`border-${i}-400 text-${i}-400 bg-${i}-500/5`:`border-transparent text-slate-400 hover:text-white`}`}),h()}});let c=e.querySelector(`#btn-refresh-data`);c&&(c.onclick=async()=>{c.classList.add(`animate-pulse`),await p(),c.classList.remove(`animate-pulse`)});let l=e.querySelector(`#btn-export-csv`);l&&(l.onclick=()=>w());let d=e.querySelector(`#btn-print-report`);d&&(d.onclick=()=>window.print())}async function p(){try{let{data:e,error:n}=await t.from(`tee_times`).select(`*`).gte(`booking_date`,r).lte(`booking_date`,i).neq(`status`,`CANCELLED`).order(`booking_date`,{ascending:!0}).order(`booking_time`,{ascending:!0});if(n)throw n;o=e||[];let{data:a,error:c}=await t.from(`members`).select(`*`);!c&&a&&(s=a),m(),h()}catch(e){console.error(`Error loading reports data:`,e);let t=document.getElementById(`reports-tab-content`);t&&(t.innerHTML=`
                <div class="p-8 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-center">
                    <span class="material-icons text-rose-400 text-4xl mb-2">error_outline</span>
                    <h4 class="text-lg font-black text-white">Error al cargar datos de reportes</h4>
                    <p class="text-xs text-rose-300 mt-1">${e.message||`Verifica la conexión a Supabase`}</p>
                </div>
            `)}}function m(){let e=0,t=0,n=0,r=0,i=0,a=0,s=0,c=0,l=0,u=0,d={},f={0:0,1:0,2:0,3:0,4:0,5:0,6:0},p=[`Domingo`,`Lunes`,`Martes`,`Miércoles`,`Jueves`,`Viernes`,`Sábado`];o.forEach(o=>{let p=Array.isArray(o.players)?o.players:[],m=p.length>0?p.length:o.total_players||1;e+=m;let h=0;p.length>0?p.forEach(e=>{let a=e.player_type||(e.is_member||e.isMember?`MEMBER`:e.convenio_id?`CONVENIO`:e.payment_method===`CORTESIA`?`CORTESIA`:`GUEST`);a===`MEMBER`||e.is_member||e.isMember?t++:a===`CORTESIA`||e.payment_method===`CORTESIA`||o.payment_method===`CORTESIA`?i++:a===`CONVENIO`||e.convenio_id?r++:n++,(e.has_cart||e.hasCart)&&h++}):o.payment_method===`CORTESIA`?i+=m:n+=m,h===0&&o.total_carts&&(h=Number(o.total_carts)||0),a+=h,s+=Number(o.cart_fee_total)||0,l+=Number(o.green_fee_total)||0,u+=Number(o.club_rental_total)||0,c+=Number(o.total_amount)||0;let g=(o.booking_time||`08:00`).substring(0,5);if(d[g]=(d[g]||0)+m,o.booking_date){let[e,t,n]=o.booking_date.split(`-`).map(Number),r=new Date(e,t-1,n);f[r.getDay()]=(f[r.getDay()]||0)+m}});let m=`--:--`,h=0;Object.entries(d).forEach(([e,t])=>{t>h&&(h=t,m=e)});let g=0,_=0;Object.entries(f).forEach(([e,t])=>{t>_&&(_=t,g=Number(e))});let v=document.getElementById(`kpi-total-players`);v&&(v.textContent=e.toLocaleString());let y=document.getElementById(`kpi-players-breakdown`);if(y){let e=[];e.push(`<span class="text-emerald-400 font-bold">${t} Socios</span>`),r>0&&e.push(`<span class="text-indigo-400 font-bold">${r} Convenios</span>`),e.push(`<span class="text-blue-400 font-bold">${n} Invitados</span>`),i>0&&e.push(`<span class="text-purple-400 font-bold">${i} Cortesías</span>`),y.innerHTML=e.join(` · `)}let b=document.getElementById(`kpi-total-carts`);b&&(b.textContent=a.toLocaleString());let x=document.getElementById(`kpi-carts-income`);x&&(x.textContent=`$${s.toLocaleString(`es-MX`,{minimumFractionDigits:2})} recaudados`);let S=document.getElementById(`kpi-total-revenue`);S&&(S.textContent=`$${c.toLocaleString(`es-MX`,{minimumFractionDigits:2})}`);let C=document.getElementById(`kpi-revenue-breakdown`);C&&(C.textContent=`GF: $${l.toLocaleString()} | Carros: $${s.toLocaleString()}${u>0?` | Equipos: $${u.toLocaleString()}`:``}`);let w=document.getElementById(`kpi-peak-hour`);w&&(w.textContent=m===`--:--`?`Sin datos`:`${m} hrs`);let T=document.getElementById(`kpi-peak-day`);T&&(T.textContent=_>0?`Día más activo: ${p[g]}`:`Sin salidas`)}function h(){let e=document.getElementById(`reports-tab-content`);e&&(a===`AFLUENCIA`?g(e):a===`CARRITOS`?y(e):a===`SOCIOS`?b(e):a===`FINANZAS`&&S(e))}function g(e){e.innerHTML=`
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Main Chart: Players over time (Socios vs Invitados) -->
            <div class="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-base font-black text-white uppercase tracking-tight">Evolución de Jugadores en el Periodo</h3>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Socios vs. Invitados / Externos por Fecha</p>
                    </div>
                    <span class="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-lg text-[10px] font-black uppercase">
                        ${o.length} Salidas Registradas
                    </span>
                </div>
                <div class="relative h-72 w-full">
                    <canvas id="chart-afluencia-timeline"></canvas>
                </div>
            </div>

            <!-- Day of Week Distribution -->
            <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 flex flex-col justify-between">
                <div>
                    <h3 class="text-base font-black text-white uppercase tracking-tight">Afluencia por Día de la Semana</h3>
                    <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Volumen Acumulado de Jugadores</p>
                </div>
                <div class="relative h-64 w-full">
                    <canvas id="chart-afluencia-weekdays"></canvas>
                </div>
            </div>
        </div>

        <!-- Horas Pico Bar Chart -->
        <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-base font-black text-white uppercase tracking-tight">Horarios Más Solicitados (Distribución de Horas Pico)</h3>
                    <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Cantidad de Jugadores según la Franja Horaria de Salida</p>
                </div>
                <span class="material-icons text-purple-400">schedule</span>
            </div>
            <div class="relative h-72 w-full">
                <canvas id="chart-horas-pico"></canvas>
            </div>
        </div>

        <!-- Summary Table of Daily Activity -->
        <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-base font-black text-white uppercase tracking-tight">Desglose Detallado por Fecha</h3>
                    <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Resumen de Salidas, Jugadores y Recaudación</p>
                </div>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b border-slate-800 text-slate-400 font-black uppercase tracking-wider">
                            <th class="py-3 px-4">Fecha</th>
                            <th class="py-3 px-4 text-center">Salidas (Grupos)</th>
                            <th class="py-3 px-4 text-center">Total Jugadores</th>
                            <th class="py-3 px-4 text-center">Socios</th>
                            <th class="py-3 px-4 text-center">Invitados</th>
                            <th class="py-3 px-4 text-center">Carritos</th>
                            <th class="py-3 px-4 text-right">Recaudación</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800/60 font-bold" id="table-afluencia-body">
                        ${_()}
                    </tbody>
                </table>
            </div>
        </div>
    `,setTimeout(()=>{v()},50)}function _(){if(o.length===0)return`<tr><td colspan="7" class="py-8 text-center text-slate-500 font-bold">No hay registros en el periodo seleccionado</td></tr>`;let e={};return o.forEach(t=>{let n=t.booking_date;e[n]||(e[n]={count:0,players:0,members:0,guests:0,carts:0,total:0}),e[n].count++;let r=Array.isArray(t.players)?t.players:[],i=r.length>0?r.length:t.total_players||1;e[n].players+=i,r.forEach(t=>{t.is_member||t.isMember?e[n].members++:e[n].guests++}),e[n].carts+=Number(t.total_carts)||0,e[n].total+=Number(t.total_amount)||0}),Object.keys(e).sort().reverse().map(t=>{let n=e[t];return`
            <tr class="hover:bg-slate-800/40 transition-colors">
                <td class="py-3.5 px-4 text-white font-black">${t}</td>
                <td class="py-3.5 px-4 text-center text-slate-300">${n.count}</td>
                <td class="py-3.5 px-4 text-center text-emerald-400 font-black">${n.players}</td>
                <td class="py-3.5 px-4 text-center text-blue-400">${n.members}</td>
                <td class="py-3.5 px-4 text-center text-amber-400">${n.guests}</td>
                <td class="py-3.5 px-4 text-center text-teal-400">${n.carts}</td>
                <td class="py-3.5 px-4 text-right text-emerald-400 font-black">$${n.total.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</td>
            </tr>
        `}).join(``)}function v(){if(typeof Chart>`u`)return;let e={};o.forEach(t=>{let n=t.booking_date;e[n]||(e[n]={members:0,guests:0});let r=Array.isArray(t.players)?t.players:[];r.forEach(t=>{t.is_member||t.isMember?e[n].members++:e[n].guests++}),r.length===0&&(e[n].guests+=t.total_players||1)});let t=Object.keys(e).sort(),n=t.map(e=>e.substring(5)),r=t.map(t=>e[t].members),i=t.map(t=>e[t].guests);C(`chart-afluencia-timeline`,{type:`bar`,data:{labels:n.length>0?n:[`Sin datos`],datasets:[{label:`Socios`,data:r.length>0?r:[0],backgroundColor:`rgba(48, 161, 98, 0.85)`,borderColor:`#30A162`,borderWidth:1,borderRadius:6},{label:`Invitados`,data:i.length>0?i:[0],backgroundColor:`rgba(59, 130, 246, 0.85)`,borderColor:`#3B82F6`,borderWidth:1,borderRadius:6}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{labels:{color:`#94a3b8`,font:{weight:`bold`,size:11}}},tooltip:{padding:10,cornerRadius:8}},scales:{x:{stacked:!0,grid:{color:`rgba(51, 65, 85, 0.3)`},ticks:{color:`#94a3b8`,font:{weight:`bold`}}},y:{stacked:!0,grid:{color:`rgba(51, 65, 85, 0.3)`},ticks:{color:`#94a3b8`,stepSize:1}}}}});let a=[0,0,0,0,0,0,0];o.forEach(e=>{if(e.booking_date){let[t,n,r]=e.booking_date.split(`-`).map(Number),i=new Date(t,n-1,r),o=Array.isArray(e.players)&&e.players.length>0?e.players.length:e.total_players||1;a[i.getDay()]+=o}}),C(`chart-afluencia-weekdays`,{type:`bar`,data:{labels:[`Lunes`,`Martes`,`Miércoles`,`Jueves`,`Viernes`,`Sábado`,`Domingo`],datasets:[{label:`Jugadores`,data:[a[1],a[2],a[3],a[4],a[5],a[6],a[0]],backgroundColor:`rgba(168, 85, 247, 0.75)`,borderColor:`#A855F7`,borderWidth:1,borderRadius:8}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1},tooltip:{padding:10,cornerRadius:8}},scales:{x:{grid:{display:!1},ticks:{color:`#94a3b8`,font:{weight:`bold`,size:10}}},y:{grid:{color:`rgba(51, 65, 85, 0.3)`},ticks:{color:`#94a3b8`,stepSize:2}}}}});let s=`07:00.07:20.07:40.08:00.08:20.08:40.09:00.09:20.09:40.10:00.10:20.10:40.11:00.11:20.11:40.12:00.12:20.12:40.13:00.13:20.13:40.14:00.14:20.14:40.15:00.15:20.15:40.16:00.16:20.16:40.17:00`.split(`.`),c={};s.forEach(e=>c[e]=0),o.forEach(e=>{let t=(e.booking_time||`08:00`).substring(0,5),n=Array.isArray(e.players)&&e.players.length>0?e.players.length:e.total_players||1;c[t]===void 0?c[t]=n:c[t]+=n});let l=Object.keys(c),u=Object.values(c);C(`chart-horas-pico`,{type:`bar`,data:{labels:l,datasets:[{label:`Jugadores por Horario`,data:u,backgroundColor:u.map(e=>e===Math.max(...u)&&e>0?`rgba(239, 68, 68, 0.85)`:`rgba(56, 189, 248, 0.75)`),borderColor:u.map(e=>e===Math.max(...u)&&e>0?`#EF4444`:`#38BDF8`),borderWidth:1,borderRadius:6}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1},tooltip:{padding:10,cornerRadius:8,callbacks:{label:e=>` ${e.parsed.y} jugador(es) salieron a las ${e.label}`}}},scales:{x:{grid:{color:`rgba(51, 65, 85, 0.2)`},ticks:{color:`#94a3b8`,font:{weight:`bold`,size:9},maxRotation:45}},y:{grid:{color:`rgba(51, 65, 85, 0.3)`},ticks:{color:`#94a3b8`,stepSize:1}}}}})}function y(e){let t=0,n=0,r=0,i={};o.forEach(e=>{let a=e.booking_date,o=Number(e.total_carts)||0,s=Number(e.cart_fee_total)||0;t+=o,n+=s,o>0&&r++,i[a]||(i[a]={carts:0,income:0}),i[a].carts+=o,i[a].income+=s});let a=o.length>0?Math.round(r/o.length*100):0,s=o.length>0?(t/o.length).toFixed(1):0;e.innerHTML=`
        <!-- KPI Row -->
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Carritos Rentados</p>
                    <h3 class="text-3xl font-black text-teal-400 mt-1">${t}</h3>
                    <p class="text-[10px] font-bold text-slate-400 mt-1">En ${o.length} salidas registradas</p>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-teal-400">
                    <span class="material-icons">electric_rickshaw</span>
                </div>
            </div>

            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ingresos por Renta</p>
                    <h3 class="text-3xl font-black text-emerald-400 mt-1">$${n.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</h3>
                    <p class="text-[10px] font-bold text-slate-400 mt-1">Promedio por carrito: $${t>0?(n/t).toFixed(0):`0`}</p>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                    <span class="material-icons">paid</span>
                </div>
            </div>

            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Adopción de Carritos</p>
                    <h3 class="text-3xl font-black text-white mt-1">${a}%</h3>
                    <p class="text-[10px] font-bold text-purple-400 mt-1">Promedio: ${s} carritos / grupo</p>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                    <span class="material-icons">donut_large</span>
                </div>
            </div>
        </div>

        <!-- Carts Evolution Chart -->
        <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-base font-black text-white uppercase tracking-tight">Renta de Carritos por Fecha</h3>
                    <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Volumen Diario de Carritos e Ingresos Recaudados</p>
                </div>
                <span class="material-icons text-teal-400">trending_up</span>
            </div>
            <div class="relative h-72 w-full">
                <canvas id="chart-carritos-timeline"></canvas>
            </div>
        </div>

        <!-- Carts Table -->
        <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <h3 class="text-base font-black text-white uppercase tracking-tight">Registro de Renta por Fecha</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b border-slate-800 text-slate-400 font-black uppercase tracking-wider">
                            <th class="py-3 px-4">Fecha</th>
                            <th class="py-3 px-4 text-center">Carritos Rentados</th>
                            <th class="py-3 px-4 text-right">Ingreso por Carritos</th>
                            <th class="py-3 px-4 text-right">Ingreso Promedio</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800/60 font-bold">
                        ${Object.keys(i).sort().reverse().map(e=>`
                            <tr class="hover:bg-slate-800/40 transition-colors">
                                <td class="py-3.5 px-4 text-white font-black">${e}</td>
                                <td class="py-3.5 px-4 text-center text-teal-400 font-black">${i[e].carts}</td>
                                <td class="py-3.5 px-4 text-right text-emerald-400 font-black">$${i[e].income.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</td>
                                <td class="py-3.5 px-4 text-right text-slate-300">$${i[e].carts>0?(i[e].income/i[e].carts).toFixed(2):`0.00`}</td>
                            </tr>
                        `).join(``)||`<tr><td colspan="4" class="py-8 text-center text-slate-500 font-bold">Sin rentas de carritos en el periodo</td></tr>`}
                    </tbody>
                </table>
            </div>
        </div>
    `,setTimeout(()=>{if(typeof Chart>`u`)return;let e=Object.keys(i).sort(),t=e.map(e=>e.substring(5)),n=e.map(e=>i[e].carts),r=e.map(e=>i[e].income);C(`chart-carritos-timeline`,{type:`line`,data:{labels:t.length>0?t:[`Sin datos`],datasets:[{label:`Carritos Rentados`,data:n.length>0?n:[0],borderColor:`#2DD4BF`,backgroundColor:`rgba(45, 212, 191, 0.15)`,fill:!0,tension:.3,yAxisID:`y`},{label:`Ingresos ($)`,data:r.length>0?r:[0],borderColor:`#30A162`,backgroundColor:`transparent`,borderDash:[5,5],tension:.3,yAxisID:`y1`}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{labels:{color:`#94a3b8`,font:{weight:`bold`}}}},scales:{x:{grid:{color:`rgba(51, 65, 85, 0.3)`},ticks:{color:`#94a3b8`,font:{weight:`bold`}}},y:{type:`linear`,display:!0,position:`left`,grid:{color:`rgba(51, 65, 85, 0.3)`},ticks:{color:`#2DD4BF`,stepSize:1}},y1:{type:`linear`,display:!0,position:`right`,grid:{drawOnChartArea:!1},ticks:{color:`#30A162`}}}}})},50)}function b(e){let t={};o.forEach(e=>{let n=Array.isArray(e.players)?e.players:[],r=n.filter(e=>!e.is_member&&!e.isMember).length;n.forEach(i=>{if(i.is_member||i.isMember){let a=i.member_number||i.member_id||i.name;t[a]||(t[a]={name:i.name||`Socio`,number:i.member_number||`--`,gamesCount:0,lastDate:e.booking_date,guestsBrought:0}),t[a].gamesCount++,e.booking_date>t[a].lastDate&&(t[a].lastDate=e.booking_date),(i.name===e.contact_name||i===n[0])&&(t[a].guestsBrought+=r)}})});let n=Object.values(t).sort((e,t)=>t.gamesCount-e.gamesCount),r=n.slice(0,10),i=s.filter(e=>e.status===`ACTIVE`||!e.status),a=new Set(Object.values(t).map(e=>e.number)),c=i.filter(e=>!a.has(e.member_number));e.innerHTML=`
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Top 3 Podium Cards -->
            <div class="lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-4">
                ${x(r[0],1,`amber-400`,`🥇 1er Lugar`)}
                ${x(r[1],2,`slate-300`,`🥈 2do Lugar`)}
                ${x(r[2],3,`amber-600`,`🥉 3er Lugar`)}
            </div>

            <!-- Top 10 Ranking Table -->
            <div class="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-base font-black text-white uppercase tracking-tight">Ranking de Socios con Más Salidas</h3>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Socios más activos en el periodo seleccionado</p>
                    </div>
                    <span class="px-2.5 py-1 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-lg text-[10px] font-black uppercase">
                        ${n.length} Socios Activos
                    </span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs">
                        <thead>
                            <tr class="border-b border-slate-800 text-slate-400 font-black uppercase tracking-wider">
                                <th class="py-3 px-4 text-center">#</th>
                                <th class="py-3 px-4">Socio</th>
                                <th class="py-3 px-4 text-center">Núm. Socio</th>
                                <th class="py-3 px-4 text-center">Salidas / Juegos</th>
                                <th class="py-3 px-4 text-center">Invitados Traídos</th>
                                <th class="py-3 px-4 text-right">Última Salida</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-800/60 font-bold">
                            ${r.map((e,t)=>`
                                <tr class="hover:bg-slate-800/40 transition-colors">
                                    <td class="py-3.5 px-4 text-center font-black ${t===0?`text-amber-400 text-sm`:t===1?`text-slate-300`:t===2?`text-amber-600`:`text-slate-500`}">
                                        ${t+1}
                                    </td>
                                    <td class="py-3.5 px-4 text-white font-black flex items-center gap-2.5">
                                        <div class="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-primary font-bold text-xs">
                                            ${e.name.charAt(0)}
                                        </div>
                                        ${e.name}
                                    </td>
                                    <td class="py-3.5 px-4 text-center text-slate-300">${e.number}</td>
                                    <td class="py-3.5 px-4 text-center text-emerald-400 font-black text-sm">${e.gamesCount}</td>
                                    <td class="py-3.5 px-4 text-center text-blue-400 font-black">${e.guestsBrought}</td>
                                    <td class="py-3.5 px-4 text-right text-slate-400">${e.lastDate||`--`}</td>
                                </tr>
                            `).join(``)||`<tr><td colspan="6" class="py-8 text-center text-slate-500 font-bold">No hay registros de salidas de socios en el periodo</td></tr>`}
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Inactive Members Alert Panel -->
            <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <span class="material-icons text-rose-400 text-lg">warning_amber</span>
                            <h3 class="text-base font-black text-white uppercase tracking-tight">Socios Inactivos</h3>
                        </div>
                        <span class="px-2.5 py-0.5 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-full text-[10px] font-black">
                            ${c.length} Socios
                        </span>
                    </div>
                    <p class="text-xs font-bold text-slate-400 mt-1">
                        Socios activos en el padrón que no han salido al campo en el periodo seleccionado.
                    </p>

                    <div class="mt-4 space-y-2.5 max-h-96 overflow-y-auto pr-1 custom-scrollbar">
                        ${c.slice(0,15).map(e=>`
                            <div class="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl flex items-center justify-between hover:border-slate-700 transition-colors">
                                <div>
                                    <p class="text-xs font-black text-white">${e.name}</p>
                                    <p class="text-[10px] font-bold text-slate-500">#${e.member_number} · ${e.phone||`Sin tel.`}</p>
                                </div>
                                <span class="px-2 py-0.5 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-md text-[9px] font-black uppercase">
                                    Sin Salidas
                                </span>
                            </div>
                        `).join(``)||`<p class="py-6 text-center text-xs text-slate-500 font-bold">¡Excelente! Todos los socios han tenido actividad.</p>`}
                    </div>
                </div>

                ${c.length>15?`
                    <p class="text-[10px] text-center font-bold text-slate-500 pt-2 border-t border-slate-800">
                        +${c.length-15} socios adicionales sin salidas
                    </p>
                `:``}
            </div>
        </div>
    `}function x(e,t,n,r){return e?`
        <div class="bg-slate-900 border border-slate-800 rounded-3xl p-5 relative overflow-hidden shadow-xl hover:border-${n}/40 transition-all">
            <div class="flex items-center justify-between">
                <span class="px-3 py-1 bg-${n}/10 text-${n} border border-${n}/20 rounded-full text-[10px] font-black uppercase tracking-wider">
                    ${r}
                </span>
                <span class="material-icons text-${n}">workspace_premium</span>
            </div>
            <div class="mt-4">
                <h4 class="text-lg font-black text-white truncate">${e.name}</h4>
                <p class="text-xs font-bold text-slate-400 mt-0.5">Socio #${e.number}</p>
            </div>
            <div class="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-bold text-slate-500 uppercase">Salidas</p>
                    <p class="text-xl font-black text-emerald-400">${e.gamesCount} juegos</p>
                </div>
                <div class="text-right">
                    <p class="text-[10px] font-bold text-slate-500 uppercase">Invitados</p>
                    <p class="text-sm font-black text-blue-400">${e.guestsBrought} personas</p>
                </div>
            </div>
        </div>
    `:`
            <div class="bg-slate-900 border border-slate-800 rounded-3xl p-5 opacity-60">
                <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest">${r}</p>
                <h4 class="text-lg font-black text-slate-400 mt-2">Sin datos</h4>
            </div>
        `}function S(e){let t={EFECTIVO:{count:0,total:0,label:`Efectivo en Caja`,color:`#10B981`,icon:`payments`,isCourtesy:!1},TARJETA:{count:0,total:0,label:`Tarjeta Crédito/Débito`,color:`#3B82F6`,icon:`credit_card`,isCourtesy:!1},TRANSFERENCIA:{count:0,total:0,label:`Transferencia Bancaria (SPEI)`,color:`#8B5CF6`,icon:`account_balance`,isCourtesy:!1},CARGO_SOCIO:{count:0,total:0,label:`Cargo a Cuenta de Socio`,color:`#F59E0B`,icon:`badge`,isCourtesy:!1},CORTESIA:{count:0,total:0,label:`Cortesía de la Directiva`,color:`#A855F7`,icon:`flag`,isCourtesy:!0}},n=0,r=0,i=0,a=0,s=0,c=0,l=[];o.forEach(e=>{let o=Number(e.total_amount)||0;n+=o,r+=Number(e.green_fee_total)||0,i+=Number(e.cart_fee_total)||0,a+=Number(e.club_rental_total)||0,s+=Number(e.total_club_rentals)||0;let u=Array.isArray(e.players)?e.players:[],d=!1,f=[],p=[];if(u.length>0)u.forEach(n=>{let r=n.player_type||(n.is_member?`MEMBER`:n.convenio_id?`CONVENIO`:`GUEST`),i=(n.payment_method||(r===`CORTESIA`?`CORTESIA`:e.payment_method||`EFECTIVO`)).toUpperCase(),a=(Number(n.green_fee)||0)+(Number(n.cart_fee)||0)+(Number(n.club_fee)||0);i===`CORTESIA`||r===`CORTESIA`||e.payment_method===`CORTESIA`?(t.CORTESIA.count++,c++,d=!0,f.push(n.name||`Beneficiario`),n.authorized_by&&p.push(n.authorized_by)):t[i]?(t[i].count++,t[i].total+=a):(t.EFECTIVO.count++,t.EFECTIVO.total+=a)});else{let n=(e.payment_method||`EFECTIVO`).toUpperCase();if(n===`CORTESIA`||o===0){let n=e.total_players||1;t.CORTESIA.count+=n,c+=n,d=!0,f.push(e.contact_name||`Beneficiario`),e.authorized_by&&p.push(e.authorized_by)}else t[n]?(t[n].count++,t[n].total+=o):(t.EFECTIVO.count++,t.EFECTIVO.total+=o)}if(e.authorized_by&&!p.includes(e.authorized_by)&&p.push(e.authorized_by),d||e.payment_method===`CORTESIA`||o===0){let t=[...new Set(p.filter(Boolean))];l.push({...e,cortesiaBeneficiaries:f.length>0?f.join(`, `):e.contact_name||`Cortesía Directiva`,cortesiaAuthorizers:t.length>0?t.join(`, `):e.authorized_by||`Directiva`,cortesiaCount:f.length>0?f.length:e.total_players||1})}}),e.innerHTML=`
        <!-- Main Financial Summary Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Cobrado (Caja)</p>
                    <h3 class="text-2xl font-black text-emerald-400 mt-1">$${n.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</h3>
                    <p class="text-[10px] font-bold text-slate-400 mt-1">En ${o.length} folios procesados</p>
                </div>
                <div class="w-11 h-11 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                    <span class="material-icons">account_balance_wallet</span>
                </div>
            </div>

            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Green Fees Recaudados</p>
                    <h3 class="text-2xl font-black text-blue-400 mt-1">$${r.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</h3>
                    <p class="text-[10px] font-bold text-slate-400 mt-1">${n>0?Math.round(r/n*100):0}% del ingreso</p>
                </div>
                <div class="w-11 h-11 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
                    <span class="material-icons">sports_golf</span>
                </div>
            </div>

            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Renta de Carritos</p>
                    <h3 class="text-2xl font-black text-teal-400 mt-1">$${i.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</h3>
                    <p class="text-[10px] font-bold text-slate-400 mt-1">${n>0?Math.round(i/n*100):0}% del ingreso</p>
                </div>
                <div class="w-11 h-11 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-teal-400">
                    <span class="material-icons">electric_rickshaw</span>
                </div>
            </div>

            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Renta de Equipo (Palos)</p>
                    <h3 class="text-2xl font-black text-amber-400 mt-1">$${a.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</h3>
                    <p class="text-[10px] font-bold text-slate-400 mt-1">${s} equipos rentados</p>
                </div>
                <div class="w-11 h-11 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                    <span class="material-icons">golf_course</span>
                </div>
            </div>
        </div>

        <!-- Payment Methods Doughnut + Breakdown -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 flex flex-col justify-between">
                <div>
                    <h3 class="text-base font-black text-white uppercase tracking-tight">Distribución por Método de Pago</h3>
                    <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Participación en Ingresos de Caja</p>
                    <div class="relative h-60 w-full flex items-center justify-center mt-2">
                        <canvas id="chart-payment-methods"></canvas>
                    </div>
                </div>
                ${c>0?`
                    <div class="p-3 bg-purple-500/10 border border-purple-500/20 rounded-2xl text-center">
                        <p class="text-xs font-black text-purple-300">⛳ ${c} Cortesía${c===1?``:`s`} Autorizada${c===1?``:`s`}</p>
                        <p class="text-[10px] text-slate-400 font-bold mt-0.5">Exentas de cobro de Green Fee</p>
                    </div>
                `:``}
            </div>

            <div class="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-base font-black text-white uppercase tracking-tight">Desglose de Métodos de Pago & Cortesías</h3>
                            <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Montos en caja y volumen de cortesías por unidad</p>
                        </div>
                    </div>

                    <div class="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                        ${Object.keys(t).map(e=>{let r=t[e];if(r.isCourtesy)return`
                                    <div class="p-4 bg-purple-950/40 border-2 border-purple-500/40 rounded-2xl flex items-center justify-between shadow-lg shadow-purple-950/20">
                                        <div class="flex items-center gap-3">
                                            <div class="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
                                                <span class="material-icons text-base">flag</span>
                                            </div>
                                            <div>
                                                <p class="text-xs font-black text-white flex items-center gap-1.5">
                                                    ${r.label}
                                                    <span class="text-[9px] font-black uppercase px-1.5 py-0.5 bg-purple-500/30 text-purple-300 rounded">Sin Cobro</span>
                                                </p>
                                                <p class="text-[10px] font-bold text-slate-400">
                                                    ${r.count===0?`Sin cortesías registradas`:`${r.count} jugador${r.count===1?``:`es`} exento${r.count===1?``:`s`}`}
                                                </p>
                                            </div>
                                        </div>
                                        <div class="text-right">
                                            <span class="px-3 py-1 bg-purple-500/20 text-purple-300 border border-purple-500/40 rounded-xl text-base font-black inline-block">
                                                ${r.count} ${r.count===1?`Cortesía`:`Cortesías`}
                                            </span>
                                            <p class="text-[9px] font-bold text-slate-400 uppercase mt-0.5 tracking-wider">Unidades</p>
                                        </div>
                                    </div>
                                `;let i=n>0?Math.round(r.total/n*100):0;return`
                                <div class="p-4 bg-slate-950/60 border border-slate-800 rounded-2xl flex items-center justify-between">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center" style="color: ${r.color};">
                                            <span class="material-icons text-base">${r.icon}</span>
                                        </div>
                                        <div>
                                            <p class="text-xs font-black text-white">${r.label}</p>
                                            <p class="text-[10px] font-bold text-slate-500">${r.count} transacciones (${i}%)</p>
                                        </div>
                                    </div>
                                    <div class="text-right">
                                        <p class="text-sm font-black text-white">$${r.total.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</p>
                                        <p class="text-[9px] font-bold text-slate-500 uppercase">Recaudado</p>
                                    </div>
                                </div>
                            `}).join(``)}
                    </div>
                </div>
            </div>
        </div>

        <!-- Courtesy Bookings Table (Audit) -->
        <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-base font-black text-white uppercase tracking-tight flex items-center gap-2">
                        <span class="material-icons text-purple-400">flag</span> Auditoría de Cortesías y Salidas Exentas
                    </h3>
                    <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Registros y jugadores exentos con cortesía de la directiva</p>
                </div>
                <span class="px-3 py-1.5 bg-purple-500/20 text-purple-300 border border-purple-500/40 rounded-xl text-xs font-black uppercase">
                    ⛳ ${c} Cortesía${c===1?``:`s`} (${l.length} Folios)
                </span>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b border-slate-800 text-slate-400 font-black uppercase tracking-wider bg-slate-950/40">
                            <th class="py-3 px-4">Folio</th>
                            <th class="py-3 px-4">Fecha & Hora</th>
                            <th class="py-3 px-4">Titular del Grupo</th>
                            <th class="py-3 px-4">Beneficiario(s) Cortesía</th>
                            <th class="py-3 px-4 text-amber-400">Autorizado Por</th>
                            <th class="py-3 px-4 text-center">Cortesías</th>
                            <th class="py-3 px-4 text-center">Carritos</th>
                            <th class="py-3 px-4">Notas</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800/60 font-bold">
                        ${l.map(e=>`
                            <tr class="hover:bg-slate-800/40 transition-colors">
                                <td class="py-3.5 px-4 text-slate-300 font-mono font-black">#${e.folio||`--`}</td>
                                <td class="py-3.5 px-4 text-white font-black">${e.booking_date} · ${e.booking_time} hrs</td>
                                <td class="py-3.5 px-4 text-slate-300">${e.contact_name}</td>
                                <td class="py-3.5 px-4 text-purple-300 font-black flex items-center gap-1.5">
                                    <span class="material-icons text-purple-400 text-xs">verified</span> ${e.cortesiaBeneficiaries}
                                </td>
                                <td class="py-3.5 px-4 text-amber-300 font-black">
                                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-black">
                                        <span class="material-icons text-sm text-amber-400">how_to_reg</span>
                                        ${e.cortesiaAuthorizers||`Directiva`}
                                    </span>
                                </td>
                                <td class="py-3.5 px-4 text-center">
                                    <span class="px-2 py-0.5 bg-purple-500/20 text-purple-300 rounded-lg text-[11px] font-black border border-purple-500/30">
                                        ${e.cortesiaCount} cortesía${e.cortesiaCount===1?``:`s`}
                                    </span>
                                </td>
                                <td class="py-3.5 px-4 text-center text-teal-400">${e.total_carts>0?`🚗 ${e.total_carts}`:`—`}</td>
                                <td class="py-3.5 px-4 text-slate-400 italic">${e.notes||`Cortesía autorizada`}</td>
                            </tr>
                        `).join(``)||`<tr><td colspan="8" class="py-8 text-center text-slate-500 font-bold">No hay cortesías registradas en este periodo</td></tr>`}
                    </tbody>
                </table>
            </div>
        </div>
    `,setTimeout(()=>{if(typeof Chart>`u`)return;let e=Object.values(t).filter(e=>!e.isCourtesy),n=e.map(e=>e.label),r=e.map(e=>e.total),i=e.map(e=>e.color);C(`chart-payment-methods`,{type:`doughnut`,data:{labels:n,datasets:[{data:r.some(e=>e>0)?r:[1],backgroundColor:r.some(e=>e>0)?i:[`#334155`],borderWidth:2,borderColor:`#0f172a`}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{position:`bottom`,labels:{color:`#94a3b8`,font:{weight:`bold`,size:10}}}},cutout:`68%`}})},50)}function C(e,t){try{c[e]&&c[e].destroy();let n=document.getElementById(e);return n?(c[e]=new Chart(n,t),c[e]):null}catch(t){return console.warn(`Error creating chart on`,e,t),null}}function w(){if(o.length===0){alert(`No hay datos disponibles para exportar en este periodo.`);return}let e=[`Folio`,`Fecha`,`Hora`,`Contacto`,`Telefono`,`Tipo de Grupo`,`Total Jugadores`,`Socios`,`Invitados`,`Cortesias`,`Autorizado Por (Cortesias)`,`Total Carritos`,`Green Fee Total ($)`,`Renta Carritos ($)`,`Total Cobrado ($)`,`Metodo de Pago`,`Estatus`,`Notas`],t=o.map(e=>{let t=Array.isArray(e.players)?e.players:[],n=0,r=0,i=0,a=[];t.forEach(t=>{let o=t.player_type||(t.is_member||t.isMember?`MEMBER`:t.convenio_id?`CONVENIO`:`GUEST`);o===`MEMBER`||t.is_member||t.isMember?n++:o===`CORTESIA`||t.payment_method===`CORTESIA`||e.payment_method===`CORTESIA`?(i++,t.authorized_by&&a.push(t.authorized_by)):r++}),t.length===0&&(e.payment_method===`CORTESIA`?i=e.total_players||1:r=e.total_players||1),e.authorized_by&&a.push(e.authorized_by);let o=[...new Set(a.filter(Boolean))],s=o.length>0?o.join(`, `):i>0?`Directiva`:``;return[`"${e.folio||``}"`,`"${e.booking_date||``}"`,`"${e.booking_time||``}"`,`"${(e.contact_name||``).replace(/"/g,`""`)}"`,`"${e.contact_phone||``}"`,`"${e.group_type||``}"`,e.total_players||1,n,r,i,`"${s.replace(/"/g,`""`)}"`,e.total_carts||0,e.green_fee_total||0,e.cart_fee_total||0,e.total_amount||0,`"${e.payment_method||``}"`,`"${e.status||``}"`,`"${(e.notes||``).replace(/"/g,`""`)}"`].join(`,`)}),n=`﻿`+[e.join(`,`),...t].join(`\r
`),a=new Blob([n],{type:`text/csv;charset=utf-8;`}),s=URL.createObjectURL(a),c=document.createElement(`a`);c.setAttribute(`href`,s),c.setAttribute(`download`,`Reporte_ColimaGC_${r}_al_${i}.csv`),document.body.appendChild(c),c.click(),document.body.removeChild(c)}export{l as renderReportsModule};