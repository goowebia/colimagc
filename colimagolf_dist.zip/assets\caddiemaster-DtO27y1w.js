import{t as e}from"./dist-BN2bhVnw.js";var t=e(`https://tztolxgsaktqindoimtu.supabase.co`,`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR6dG9seGdzYWt0cWluZG9pbXR1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYyNzQ4ODAsImV4cCI6MjEwMTg1MDg4MH0.E2GABiOMXYb5hEwE9ErIcJa6_LHkj9lJUglQVoiLl0M`),n=t.schema(`colimaGC`),r=t.schema(`starter`);function i(e=new Date){return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}function a(e){return e==null?``:String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#039;`)}var o=[],s=[],c=[],l=[],u=[],d=null,f=`TEETIMES`,p=null,m=i(),h=[{hole:1,par:4,idx:3},{hole:2,par:3,idx:7},{hole:3,par:4,idx:15},{hole:4,par:4,idx:9},{hole:5,par:3,idx:17},{hole:6,par:5,idx:1},{hole:7,par:3,idx:5},{hole:8,par:4,idx:11},{hole:9,par:4,idx:13},{hole:10,par:4,idx:4},{hole:11,par:3,idx:10},{hole:12,par:4,idx:16},{hole:13,par:4,idx:14},{hole:14,par:3,idx:18},{hole:15,par:5,idx:2},{hole:16,par:3,idx:8},{hole:17,par:4,idx:6},{hole:18,par:4,idx:12}],g=68,_=67.5,v=114;async function y(e){e.innerHTML=`
        <div class="space-y-6">
            <!-- Header Banner -->
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
                <div class="flex items-center gap-4">
                    <div class="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                        <span class="material-icons" style="font-size:30px">golf_course</span>
                    </div>
                    <div>
                        <div class="flex items-center gap-2.5">
                            <h2 class="text-2xl font-black text-white uppercase tracking-tight">Portal Caddie Master</h2>
                            <span class="px-2.5 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-lg text-[10px] font-black uppercase">Operación en Campo</span>
                        </div>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Control de Salidas, Sincronización con Recepción & Scorecards</p>
                    </div>
                </div>

                <!-- Date Navigation Bar -->
                <div class="flex flex-wrap items-center gap-2 bg-slate-950/80 border border-slate-800 p-2 rounded-2xl shrink-0">
                    <button id="btn-caddie-date-prev" class="w-9 h-9 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl flex items-center justify-center transition-all" title="Día Anterior">
                        <span class="material-icons text-base">chevron_left</span>
                    </button>

                    <div class="flex items-center gap-2 px-3 py-1 bg-slate-900 border border-slate-700/80 rounded-xl">
                        <span class="material-icons text-primary text-base">calendar_today</span>
                        <input id="caddie-date-input" type="date" value="${m}" style="color-scheme: dark;"
                            class="bg-transparent text-white font-black text-xs uppercase focus:outline-none cursor-pointer">
                    </div>

                    <button id="btn-caddie-date-next" class="w-9 h-9 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl flex items-center justify-center transition-all" title="Día Siguiente">
                        <span class="material-icons text-base">chevron_right</span>
                    </button>

                    <button id="btn-caddie-date-today" class="px-3 py-2 bg-primary/20 hover:bg-primary/30 border border-primary/40 text-primary rounded-xl font-black text-xs uppercase tracking-wider transition-all">
                        Hoy
                    </button>

                    <button onclick="window.refreshCaddieData()" class="w-9 h-9 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl flex items-center justify-center transition-all border border-slate-700" title="Actualizar Datos">
                        <span class="material-icons text-base">refresh</span>
                    </button>
                </div>
            </div>

            <!-- Pending Paid Departures Alert Banner Container -->
            <div id="caddie-pending-alert-container"></div>

            <!-- Sub Navigation Tabs -->
            <div class="flex items-center gap-1.5 sm:gap-2 flex-wrap border-b border-slate-800 pb-3">
                <button id="tab-caddie-teetimes" class="px-3.5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 sm:gap-2 bg-primary text-slate-950 shadow-md shadow-primary/20 shrink-0">
                    <span class="material-icons" style="font-size:16px">point_of_sale</span> Salidas de Recepción
                    <span id="tab-caddie-teetimes-badge" class="px-2 py-0.5 bg-slate-900 text-slate-200 rounded-md text-[10px] font-black border border-slate-700">0</span>
                </button>
                <button id="tab-caddie-oncourse" class="px-3.5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 sm:gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white shrink-0">
                    <span class="material-icons" style="font-size:16px">sports_golf</span> Jugadores en Campo
                    <span id="tab-caddie-oncourse-badge" class="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded-md text-[10px] font-black border border-emerald-500/30">0</span>
                </button>
                <button id="tab-caddie-log" class="px-3.5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 sm:gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white shrink-0">
                    <span class="material-icons" style="font-size:16px">history</span> Bitácora de Hoy
                    <span id="tab-caddie-badge" class="px-2 py-0.5 bg-slate-800 text-emerald-400 rounded-md text-[10px] font-black border border-slate-700">0</span>
                </button>
                <button id="tab-caddie-practica" class="px-3.5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 sm:gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white shrink-0">
                    <span class="material-icons" style="font-size:16px">sports_baseball</span> Práctica & Pelotas
                    <span id="tab-caddie-practica-badge" class="px-2 py-0.5 bg-purple-500/20 text-purple-300 rounded-md text-[10px] font-black border border-purple-500/30">0</span>
                </button>
                <button id="btn-pending-nine-holes" onclick="window.openPendingNineHolesModal()" class="px-3.5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 sm:gap-2 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 shrink-0">
                    <span class="material-icons text-amber-400" style="font-size:16px">timer</span> Scores Pendientes (9H)
                    <span id="tab-caddie-p9-badge" class="px-2 py-0.5 bg-amber-500 text-slate-950 rounded-md text-[10px] font-black">0</span>
                </button>
            </div>

            <!-- Tab Content 1: Salidas & Tee Times de Recepción (Principal / Predeterminada) -->
            <div id="caddie-tab-teetimes" class="space-y-6">
                <!-- Summary KPI Cards -->
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                        <div>
                            <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest">Grupos Agendados</p>
                            <h4 id="kpi-caddie-total-groups" class="text-2xl font-black text-white mt-1">0</h4>
                            <p class="text-[10px] font-bold text-slate-400 mt-0.5">Total en recepción</p>
                        </div>
                        <div class="w-11 h-11 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
                            <span class="material-icons">groups</span>
                        </div>
                    </div>

                    <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                        <div>
                            <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest">Listos por Salir</p>
                            <h4 id="kpi-caddie-pending-groups" class="text-2xl font-black text-amber-400 mt-1">0</h4>
                            <p class="text-[10px] font-bold text-slate-400 mt-0.5">Pagados / En Tee</p>
                        </div>
                        <div class="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                            <span class="material-icons">pending_actions</span>
                        </div>
                    </div>

                    <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                        <div>
                            <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest">Grupos en Campo</p>
                            <h4 id="kpi-caddie-oncourse-groups" class="text-2xl font-black text-emerald-400 mt-1">0</h4>
                            <p class="text-[10px] font-bold text-slate-400 mt-0.5">Jugando actualmente</p>
                        </div>
                        <div class="w-11 h-11 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                            <span class="material-icons">sports_golf</span>
                        </div>
                    </div>

                    <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                        <div>
                            <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest">Carritos Asignados</p>
                            <h4 id="kpi-caddie-carts" class="text-2xl font-black text-primary mt-1">0</h4>
                            <p class="text-[10px] font-bold text-slate-400 mt-0.5">En operación</p>
                        </div>
                        <div class="w-11 h-11 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                            <span class="material-icons">electric_car</span>
                        </div>
                    </div>
                </div>

                <!-- Tee Times List Grid -->
                <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                        <div>
                            <h3 class="font-black text-white uppercase text-base tracking-tight flex items-center gap-2">
                                <span class="material-icons text-primary">receipt_long</span> Salidas Generadas en Recepción
                            </h3>
                            <p class="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                                Autoriza la salida, asigna caddies y carritos a los grupos registrados en Casa Club
                            </p>
                        </div>
                        <div class="relative w-full sm:w-72">
                            <span class="material-icons absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm">search</span>
                            <input id="teetimes-search-input" type="text" placeholder="Filtrar por nombre, folio o caddie..." class="w-full pl-9 pr-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white placeholder:text-slate-500 focus:outline-none focus:border-primary">
                        </div>
                    </div>

                    <div id="caddie-teetimes-container" class="space-y-3">
                        <div class="py-12 text-center">
                            <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tab Content 2.5: Jugadores en Campo Actualmente -->
            <div id="caddie-tab-oncourse" class="hidden space-y-4">
                <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
                        <div>
                            <div class="flex items-center gap-2.5">
                                <h3 class="font-black text-white uppercase text-base tracking-tight flex items-center gap-2">
                                    <span class="material-icons text-emerald-400">sports_golf</span> Jugadores en Campo Actualmente
                                </h3>
                                <span class="px-2.5 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-lg text-[10px] font-black uppercase">En Vivo</span>
                            </div>
                            <p class="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                                Golfistas jugando hoy con entrega de tarjeta pendiente. Al registrar su score o marcar no entregó, se retiran automáticamente de esta vista.
                            </p>
                        </div>
                        <div class="flex items-center gap-3">
                            <div class="relative w-64">
                                <span class="material-icons absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm">search</span>
                                <input id="oncourse-search-input" type="text" oninput="window.renderOnCoursePlayersList()" placeholder="Buscar jugador, caddie, carro..." class="w-full pl-9 pr-3 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white placeholder:text-slate-500 focus:outline-none focus:border-primary">
                            </div>
                            <div class="px-4 py-2.5 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-emerald-400 text-xs font-black uppercase shrink-0">
                                Jugando: <span id="oncourse-players-count">0</span>
                            </div>
                        </div>
                    </div>

                    <div id="oncourse-players-container" class="space-y-3">
                        <div class="py-12 text-center">
                            <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tab Content 3: Bitácora de Salidas Diarias -->
            <div id="caddie-tab-log" class="hidden space-y-4">
                <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div>
                            <h3 class="font-black text-white uppercase text-base tracking-tight flex items-center gap-2">
                                <span class="material-icons text-emerald-400">history</span> Bitácora de Salidas
                            </h3>
                            <p class="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">Captura de Scorecards 18 Hoyos y registro de jugadores en campo</p>
                        </div>
                        <div class="flex items-center gap-3">
                            <div class="relative w-64">
                                <span class="material-icons absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm">search</span>
                                <input id="log-search-input" type="text" placeholder="Filtrar bitácora..." class="w-full pl-9 pr-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white placeholder:text-slate-500 focus:outline-none focus:border-primary">
                            </div>
                            <div class="px-4 py-2 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400 text-xs font-black uppercase shrink-0">
                                Total Salidas: <span id="caddie-outputs-count">0</span>
                            </div>
                        </div>
                    </div>

                    <div id="caddie-outputs-table-container">
                        <div class="py-8 text-center">
                            <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tab Content 5: Práctica & Cubetas de Pelotas -->
            <div id="caddie-tab-practica" class="hidden space-y-4">
                <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                        <div>
                            <div class="flex items-center gap-2.5">
                                <span class="material-icons text-purple-400 text-2xl">sports_baseball</span>
                                <h3 class="font-black text-white uppercase text-base tracking-tight">Tee de Práctica & Entrega de Pelotas</h3>
                            </div>
                            <p class="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                                Control de cubetas cobradas en recepción y confirmación de entrega en el driving range
                            </p>
                        </div>
                        <div class="flex items-center gap-2">
                            <span id="caddie-practica-summary" class="px-3 py-1.5 bg-purple-500/10 text-purple-300 border border-purple-500/30 rounded-xl text-xs font-black uppercase">
                                0 Registros Hoy
                            </span>
                        </div>
                    </div>

                    <div id="caddie-practica-container" class="space-y-3">
                        <div class="py-8 text-center">
                            <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;let t=document.getElementById(`tab-caddie-teetimes`),n=document.getElementById(`tab-caddie-oncourse`),r=document.getElementById(`tab-caddie-log`),a=document.getElementById(`tab-caddie-practica`),o=document.getElementById(`caddie-tab-teetimes`),s=document.getElementById(`caddie-tab-oncourse`),c=document.getElementById(`caddie-tab-log`),l=document.getElementById(`caddie-tab-practica`),u=`px-3.5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 sm:gap-2 bg-primary text-slate-950 shadow-md shadow-primary/20 shrink-0`,d=`px-3.5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 sm:gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white shrink-0`,p=e=>{f=e,t&&(t.className=e===`TEETIMES`?u:d),n&&(n.className=e===`ONCOURSE`?u:d),r&&(r.className=e===`LOG`?u:d),a&&(a.className=e===`PRACTICA`?u:d),o&&o.classList.toggle(`hidden`,e!==`TEETIMES`),s&&s.classList.toggle(`hidden`,e!==`ONCOURSE`),c&&c.classList.toggle(`hidden`,e!==`LOG`),l&&l.classList.toggle(`hidden`,e!==`PRACTICA`)};t&&(t.onclick=()=>{p(`TEETIMES`),E()}),n&&(n.onclick=()=>{p(`ONCOURSE`),window.renderOnCoursePlayersList()}),r&&(r.onclick=()=>{p(`LOG`),O()}),a&&(a.onclick=()=>{p(`PRACTICA`),j()}),window.switchToReceptionTab=()=>{t&&t.click()},window.switchCaddieTab=e=>{e===`TEETIMES`&&t?t.click():e===`ONCOURSE`&&n?n.click():e===`LOG`&&r?r.click():e===`PRACTICA`&&a&&a.click()},document.getElementById(`caddie-date-input`).onchange=e=>{m=e.target.value,x()},document.getElementById(`btn-caddie-date-today`).onclick=()=>{m=i(),document.getElementById(`caddie-date-input`).value=m,x()},document.getElementById(`btn-caddie-date-prev`).onclick=()=>{let e=new Date(m+`T00:00:00`);e.setDate(e.getDate()-1),m=i(e),document.getElementById(`caddie-date-input`).value=m,x()},document.getElementById(`btn-caddie-date-next`).onclick=()=>{let e=new Date(m+`T00:00:00`);e.setDate(e.getDate()+1),m=i(e),document.getElementById(`caddie-date-input`).value=m,x()};let h=document.getElementById(`caddie-search-input`);h&&(h.oninput=e=>{w(e.target.value.toLowerCase().trim())}),document.getElementById(`teetimes-search-input`).oninput=()=>{E()},document.getElementById(`log-search-input`).oninput=()=>{O()},p(`TEETIMES`),await x(),b()}window.refreshCaddieData=async function(){await x(),window.showNotification?.(`Datos Actualizados`,`Información de salidas y socios sincronizada.`,`info`)};function b(){try{p&&t.removeChannel(p),p=t.channel(`caddie_master_realtime`).on(`postgres_changes`,{event:`*`,schema:`colimaGC`,table:`tee_times`},e=>{console.log(`Realtime tee_times change detected in caddie master:`,e),x()}).on(`postgres_changes`,{event:`*`,schema:`colimaGC`,table:`daily_outputs`},()=>{x()}).on(`postgres_changes`,{event:`*`,schema:`colimaGC`,table:`driving_range_sessions`},()=>{x()}).on(`postgres_changes`,{event:`*`,schema:`colimaGC`,table:`pending_nine_holes`},()=>{x()}).subscribe(),window.addEventListener(`storage`,e=>{(e.key===`cgc_caddie_alert_sync`||e.key?.startsWith(`cgc_tee_times_`)||e.key===`cgc_driving_range_sync`||e.key?.startsWith(`cgc_driving_range_`)||e.key===`cgc_pending_nine_holes_sync`)&&x()})}catch(e){console.warn(`Realtime subscription error in caddiemaster:`,e)}}async function x(){try{let e=m||i(),{data:t}=await n.from(`members`).select(`*`).order(`member_number`,{ascending:!0});o=t||[];let a=[];try{let{data:e,error:t}=await n.from(`daily_outputs`).select(`*`).order(`created_at`,{ascending:!1});if(!t&&e)a=e;else{let{data:e}=await r.from(`daily_outputs`).select(`*`).order(`created_at`,{ascending:!1});a=e||[]}}catch{let{data:e}=await r.from(`daily_outputs`).select(`*`).order(`created_at`,{ascending:!1});a=e||[]}s=(a||[]).filter(t=>t.created_at&&t.created_at.startsWith(e));try{let{data:t,error:r}=await n.from(`tee_times`).select(`*`).eq(`booking_date`,e).order(`booking_time`,{ascending:!0});if(!r&&t&&t.length>0)c=t,localStorage.setItem(`cgc_tee_times_${e}`,JSON.stringify(t));else{let n=localStorage.getItem(`cgc_tee_times_${e}`);c=n?JSON.parse(n):t||[]}}catch{let t=localStorage.getItem(`cgc_tee_times_${e}`);c=t?JSON.parse(t):[]}try{let{data:t,error:r}=await n.from(`driving_range_sessions`).select(`*`).eq(`session_date`,e).order(`created_at`,{ascending:!1});if(!r&&t)l=t,localStorage.setItem(`cgc_driving_range_${e}`,JSON.stringify(t));else{let n=localStorage.getItem(`cgc_driving_range_${e}`);l=n?JSON.parse(n):t||[]}}catch{let t=localStorage.getItem(`cgc_driving_range_${e}`);l=t?JSON.parse(t):[]}try{let e=i();try{await n.from(`pending_nine_holes`).update({status:`EXPIRED`}).eq(`status`,`PENDING`).lt(`expires_at`,e)}catch{}let{data:t,error:r}=await n.from(`pending_nine_holes`).select(`*`).eq(`status`,`PENDING`).gte(`expires_at`,e).order(`played_date`,{ascending:!1});if(!r&&t)u=t,localStorage.setItem(`cgc_pending_nine_holes`,JSON.stringify(t));else{let e=localStorage.getItem(`cgc_pending_nine_holes`);u=e?JSON.parse(e):[]}}catch{let e=localStorage.getItem(`cgc_pending_nine_holes`);u=e?JSON.parse(e):[]}let d=document.getElementById(`tab-caddie-p9-badge`);if(d&&(d.textContent=u.length),c.length===0){let t=localStorage.getItem(`cgc_tee_times_${e}`);if(t)try{let e=JSON.parse(t);Array.isArray(e)&&e.length>0&&(c=e)}catch{}}let f=document.getElementById(`caddie-date-input`);f&&(f.value=e);for(let e of c)if(e.status===`ON_COURSE`||e.status===`COMPLETED`){let t=Array.isArray(e.players)&&e.players.length>0?e.players:[{name:e.contact_name,is_member:!1,player_type:`GUEST`}];for(let i=0;i<t.length;i++){let a=t[i],o=a.name||e.contact_name||`Jugador #${i+1}`;if(!s.some(t=>(t.tee_time_id===e.id||t.folio===e.folio)&&(t.member_name===o||!a.name&&t.member_name===e.contact_name))){let t={tee_time_id:e.id,folio:e.folio,member_id:a.member_id||null,member_number:a.member_number||(a.is_member?`SOC`:`INV`),member_name:o,player_type:a.is_member?`MEMBER`:a.player_type||`GUEST`,starting_hole:e.starting_hole||1,caddie_name:e.caddie_assigned||``,cart_number:e.cart_numbers||``,score_status:`PENDING`};try{let{data:e,error:i}=await n.from(`daily_outputs`).insert([t]).select().single();if(!i&&e)s.push(e);else{let{data:e}=await r.from(`daily_outputs`).insert([t]).select().single();e&&s.push(e)}}catch{try{let{data:e}=await r.from(`daily_outputs`).insert([t]).select().single();e&&s.push(e)}catch{}}}}}S(),document.getElementById(`caddie-search-results`)&&w(document.getElementById(`caddie-search-input`)?.value.toLowerCase().trim()||``),E(),O(),window.renderOnCoursePlayersList(),j()}catch(e){console.error(`Error loading caddie master data:`,e)}}function S(){let e=document.getElementById(`tab-caddie-badge`),t=document.getElementById(`tab-caddie-teetimes-badge`),n=document.getElementById(`tab-caddie-oncourse-badge`),r=document.getElementById(`tab-caddie-practica-badge`),i=document.getElementById(`caddie-outputs-count`),a=document.getElementById(`kpi-caddie-total-groups`),o=document.getElementById(`kpi-caddie-pending-groups`),d=document.getElementById(`kpi-caddie-oncourse-groups`),f=document.getElementById(`kpi-caddie-carts`),p=c.filter(e=>e.status!==`CANCELLED`&&e.status!==`BLOCKED`),m=p.filter(e=>e.status===`PAID`||e.status===`RESERVED`).length,h=p.filter(e=>e.status===`ON_COURSE`||e.status===`COMPLETED`).length,g=0;p.forEach(e=>{g+=parseInt(e.total_carts||0)});let _=0;c.filter(e=>e.status===`ON_COURSE`).forEach(e=>{(Array.isArray(e.players)&&e.players.length>0?e.players:[{name:e.contact_name}]).forEach(t=>{let n=t.name||e.contact_name,r=s.find(r=>(r.tee_time_id===e.id||r.folio===e.folio)&&(r.member_name===n||!t.name&&r.member_name===e.contact_name)),i=r&&r.score_status||`PENDING`;i!==`CAPTURED`&&i!==`NO_CARD`&&i!==`PARTIAL_9`&&_++})});let v=l.filter(e=>!e.balls_delivered&&e.status!==`CANCELLED`),y=u.filter(e=>e.status===`PENDING`).length;e&&(e.textContent=s.length),t&&(t.textContent=m),n&&(n.textContent=_),r&&(r.textContent=v.length);let b=document.getElementById(`tab-caddie-p9-badge`);b&&(b.textContent=y),i&&(i.textContent=s.length),a&&(a.textContent=p.length),o&&(o.textContent=m),d&&(d.textContent=h),f&&(f.textContent=g),C()}function C(){let e=document.getElementById(`caddie-pending-alert-container`);if(!e)return;let t=c.filter(e=>e.status===`PAID`),n=l.filter(e=>!e.balls_delivered&&e.status!==`CANCELLED`);if(t.length===0&&n.length===0){e.innerHTML=``;return}e.innerHTML=`
        <div class="space-y-3">
            ${n.length>0?`
                <div class="relative overflow-hidden bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 border-2 border-purple-500/80 rounded-3xl p-5 shadow-2xl shadow-purple-500/20 animate-fade-in">
                    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        <div class="flex items-center gap-4 min-w-0">
                            <div class="w-12 h-12 rounded-2xl bg-purple-500 text-slate-950 flex items-center justify-center shrink-0 shadow-lg shadow-purple-500/40">
                                <span class="material-icons animate-pulse text-2xl">sports_baseball</span>
                            </div>
                            <div class="min-w-0">
                                <div class="flex items-center gap-2 flex-wrap">
                                    <span class="px-2.5 py-0.5 bg-purple-400 text-slate-950 rounded-lg text-[10px] font-black uppercase tracking-wider">
                                        🏌️ Entrega(s) de Pelotas de Práctica (${n.length})
                                    </span>
                                    <span class="text-xs text-purple-300 font-bold">Listas para entregar en Tee de Práctica</span>
                                </div>
                                <div class="mt-2 flex flex-wrap items-center gap-2">
                                    ${n.map(e=>`
                                        <div class="flex items-center gap-2 bg-slate-900/90 px-3 py-1.5 rounded-xl border border-purple-500/40 text-xs shadow-md">
                                            <span class="font-black text-purple-300">#${e.folio||`—`}</span>
                                            <span class="font-black text-white uppercase truncate max-w-[150px] sm:max-w-none">${a(e.customer_name)}</span>
                                            <span class="text-[10px] text-teal-300 font-bold">(${e.buckets_count} cubeta${e.buckets_count>1?`s`:``} · ${e.buckets_count*100} pelotas)</span>
                                            <button type="button" onclick="window.deliverDrivingRangeBalls('${e.id}')"
                                                class="ml-1 px-3 py-1 bg-purple-500 hover:bg-purple-400 text-slate-950 rounded-lg font-black text-[10px] uppercase transition-all shadow-md flex items-center gap-1">
                                                <span class="material-icons text-xs">check</span> Entregar
                                            </button>
                                        </div>
                                    `).join(``)}
                                </div>
                            </div>
                        </div>
                        <button type="button" onclick="window.switchCaddieTab('PRACTICA')"
                            class="px-5 py-3 bg-purple-500 hover:bg-purple-400 text-slate-950 rounded-2xl font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-purple-500/20 shrink-0 flex items-center justify-center gap-2">
                            <span class="material-icons text-base">sports_baseball</span> Ver Práctica (${n.length})
                        </button>
                    </div>
                </div>
            `:``}

            ${t.length>0?`
                <div class="relative overflow-hidden bg-gradient-to-r from-blue-950 via-slate-900 to-emerald-950 border-2 border-emerald-500/80 rounded-3xl p-5 shadow-2xl shadow-emerald-500/20 animate-fade-in">
                    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        <div class="flex items-center gap-4 min-w-0">
                            <div class="w-12 h-12 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center shrink-0 shadow-lg shadow-emerald-500/40">
                                <span class="material-icons animate-pulse text-2xl">notifications_active</span>
                            </div>
                            <div class="min-w-0">
                                <div class="flex items-center gap-2 flex-wrap">
                                    <span class="px-2.5 py-0.5 bg-emerald-400 text-slate-950 rounded-lg text-[10px] font-black uppercase tracking-wider">
                                        🔔 Salida(s) Pagada(s) en Recepción (${t.length})
                                    </span>
                                    <span class="text-xs text-emerald-300 font-bold">Listos en Tee para autorizar salida</span>
                                </div>
                                <div class="mt-2 flex flex-wrap items-center gap-2">
                                    ${t.map(e=>`
                                        <div class="flex items-center gap-2 bg-slate-900/90 px-3 py-1.5 rounded-xl border border-emerald-500/40 text-xs shadow-md">
                                            <span class="font-black text-emerald-400">${e.booking_time} hrs</span>
                                            <span class="font-black text-white uppercase truncate max-w-[150px] sm:max-w-none">${e.contact_name||`Grupo`}</span>
                                            <span class="text-[10px] text-slate-400 font-bold">(Folio ${e.folio||`—`} · ${e.total_players} jug · Hoyo #${e.starting_hole||1})</span>
                                            <button type="button" onclick="window.openAuthorizeModal('${e.id}')"
                                                class="ml-1 px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-lg font-black text-[10px] uppercase transition-all shadow-md flex items-center gap-1">
                                                <span class="material-icons text-xs">play_arrow</span> Dar Salida
                                            </button>
                                        </div>
                                    `).join(``)}
                                </div>
                            </div>
                        </div>
                        <button type="button" onclick="window.switchToReceptionTab()"
                            class="px-5 py-3 bg-blue-500 hover:bg-blue-400 text-slate-950 rounded-2xl font-black text-xs uppercase tracking-wider transition-all shadow-lg shadow-blue-500/20 shrink-0 flex items-center justify-center gap-2">
                            <span class="material-icons text-base">point_of_sale</span> Ver Salidas de Recepción (${t.length})
                        </button>
                    </div>
                </div>
            `:``}
        </div>
    `}function w(e){let t=document.getElementById(`caddie-search-results`);if(!t)return;let n=m||i(),r=o.filter(t=>!e||`${t.name} ${t.member_number} ${t.category}`.toLowerCase().includes(e)),a=c.filter(t=>{if(!e||t.status===`CANCELLED`)return!1;let n=Array.isArray(t.players)?t.players.map(e=>e.name).join(` `):``;return`${t.folio||``} ${t.contact_name||``} ${n}`.toLowerCase().includes(e)});if(r.length===0&&a.length===0){t.innerHTML=`<p class="text-xs text-slate-500 font-bold uppercase text-center py-6">No se encontraron socios ni pases con ese término.</p>`;return}let s=``;a.length>0&&(s+=`<div class="text-[10px] font-black text-blue-400 uppercase tracking-widest px-2 py-1">Pases de Recepción (${a.length})</div>`,s+=a.map(e=>{let t=d&&d.type===`TEETIME`&&String(d.data.id)===String(e.id),n=e.status===`PAID`||e.status===`ON_COURSE`;return`
                <div onclick="window.selectCaddieTeeTime('${e.id}')"
                    class="p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3
                    ${t?`bg-blue-500/20 border-blue-500 shadow-lg`:`bg-slate-800/90 border-blue-500/30 hover:bg-slate-800 hover:border-blue-400`}">
                    <div class="flex items-center gap-3 min-w-0">
                        <div class="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400 font-black text-xs shrink-0">
                            ${e.booking_time}
                        </div>
                        <div class="min-w-0">
                            <div class="flex items-center gap-2">
                                <p class="font-black text-white text-xs uppercase truncate">${e.contact_name||`Grupo`}</p>
                                <span class="px-2 py-0.5 bg-blue-500/10 text-blue-400 rounded text-[9px] font-black border border-blue-500/20">PASE</span>
                            </div>
                            <p class="text-[10px] text-slate-400 font-bold uppercase truncate mt-0.5">Folio: ${e.folio} · ${e.total_players} jug · Hoyo #${e.starting_hole||1}</p>
                        </div>
                    </div>
                    <span class="px-2.5 py-1 rounded-lg text-[9px] font-black uppercase shrink-0 ${n?`bg-emerald-500/20 text-emerald-400 border border-emerald-500/30`:`bg-amber-500/20 text-amber-400 border border-amber-500/30`}">
                        ${e.status===`PAID`?`🔵 PAGADO`:e.status===`ON_COURSE`?`⛳ EN CAMPO`:`🟡 RESERVA`}
                    </span>
                </div>`}).join(``)),r.length>0&&(a.length>0&&(s+=`<div class="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2 pt-2">Socios del Club (${r.length})</div>`),s+=r.map(e=>{let t=e.paid_until&&e.paid_until>=n&&e.status===`ACTIVE`,r=d&&d.type===`MEMBER`&&String(d.data.id)===String(e.id);return`
                <div onclick="window.selectCaddieMember('${e.id}')"
                    class="p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3
                    ${r?`bg-primary/20 border-primary shadow-lg`:`bg-slate-800/80 border-slate-700/80 hover:bg-slate-800 hover:border-slate-600`}">
                    <div class="flex items-center gap-3 min-w-0">
                        <div class="w-9 h-9 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center font-black text-white text-xs shrink-0">
                            ${(e.member_number||``).replace(`SOC-`,``)}
                        </div>
                        <div class="min-w-0">
                            <p class="font-black text-white text-xs uppercase truncate">${e.name}</p>
                            <p class="text-[10px] text-slate-400 font-bold uppercase">${e.category||`TITULAR`}</p>
                        </div>
                    </div>
                    <span class="w-3 h-3 rounded-full shrink-0 ${t?`bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]`:`bg-rose-400 shadow-[0_0_8px_rgba(251,113,133,0.8)]`}"></span>
                </div>`}).join(``)),t.innerHTML=s}window.selectCaddieMember=function(e){let t=o.find(t=>String(t.id)===String(e));t&&(d={type:`MEMBER`,data:t},w(document.getElementById(`caddie-search-input`)?.value.toLowerCase().trim()||``),T())},window.selectCaddieTeeTime=function(e){let t=c.find(t=>String(t.id)===String(e));t&&(d={type:`TEETIME`,data:t},w(document.getElementById(`caddie-search-input`)?.value.toLowerCase().trim()||``),T())};function T(){let e=document.getElementById(`caddie-verification-card`);if(!e||!d)return;let t=m||i();if(d.type===`TEETIME`){let t=d.data,n=t.status===`PAID`||t.status===`ON_COURSE`,r=t.status===`ON_COURSE`,i=[];playersList.forEach(e=>{let t=(e.name||``).trim().toLowerCase(),n=u.find(n=>e.member_id&&String(n.member_id)===String(e.member_id)||t&&(n.member_name||``).trim().toLowerCase()===t);n&&i.push({player:e,pending:n})});let a=parseInt(t.starting_hole)||1;i.length>0&&(a=i[0].pending.round_type===`FRONT_9`?10:1);let o=i.length>0?`
            <div class="bg-amber-500/15 border-2 border-amber-500/60 rounded-2xl p-4 space-y-2 animate-fade-in shadow-lg shadow-amber-500/10">
                <div class="flex items-center justify-between gap-2">
                    <span class="flex items-center gap-1.5 text-amber-400 font-black text-xs uppercase tracking-wider">
                        <span class="material-icons text-base">notification_important</span> ¡Scorecard Incompleto de 9 Hoyos Detectado!
                    </span>
                    <span class="px-2 py-0.5 bg-amber-500/30 text-amber-200 rounded text-[9px] font-black uppercase">Vigencia 6 Días</span>
                </div>
                ${i.map(e=>{let t=e.pending.round_type===`FRONT_9`?`1ra Vuelta (Hoyos 1-9 · Blancas)`:`2da Vuelta (Hoyos 10-18 · Azules)`,n=e.pending.round_type===`FRONT_9`?10:1,r=e.pending.round_type===`FRONT_9`?`2da Vuelta (Hoyo 10 · Marcas Azules)`:`1ra Vuelta (Hoyo 1 · Marcas Blancas)`;return`
                        <div class="bg-slate-900/90 border border-amber-500/40 rounded-xl p-3 space-y-1 text-xs">
                            <p class="font-black text-white text-sm uppercase">${e.pending.member_name}</p>
                            <p class="text-slate-300 font-bold">
                                Jugó ${t} el día <strong>${e.pending.played_date}</strong> (${e.pending.partial_gross} golpes).
                            </p>
                            <p class="text-amber-300 font-black flex items-center gap-1">
                                <span class="material-icons text-sm">arrow_forward</span> Le corresponde salir por: <strong>Hoyo #${n} (${r})</strong> para completar su tarjeta oficial de 18 hoyos.
                            </p>
                        </div>
                    `}).join(``)}
            </div>
        `:``;e.className=`bg-slate-900 border-2 border-blue-500/60 rounded-3xl p-8 shadow-2xl space-y-6 animate-fade-in text-left`,e.innerHTML=`
            <div class="flex items-center justify-between gap-4 bg-blue-500/10 border border-blue-500/30 p-5 rounded-2xl">
                <div class="flex items-center gap-4">
                    <div class="w-14 h-14 rounded-2xl bg-blue-500 text-slate-950 flex items-center justify-center shrink-0 shadow-lg shadow-blue-500/30">
                        <span class="material-icons" style="font-size:32px">receipt_long</span>
                    </div>
                    <div>
                        <span class="px-3 py-1 bg-blue-500 text-slate-950 font-black text-[10px] uppercase rounded-full tracking-wider">
                            ${r?`⛳ EN CAMPO`:n?`🟢 AUTORIZADO (PAGADO EN RECEPCIÓN)`:`🟡 RESERVA TELEFÓNICA`}
                        </span>
                        <h3 class="font-black text-white text-xl uppercase mt-1">GRUPO: ${t.contact_name}</h3>
                    </div>
                </div>
            </div>

            ${o}

            <div class="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 space-y-3">
                <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-400 font-bold">Folio de Recepción:</span>
                    <span class="font-black text-white text-sm bg-slate-900 px-3 py-1 rounded-lg border border-slate-700">${t.folio}</span>
                </div>
                <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-400 font-bold">Horario de Salida:</span>
                    <span class="font-black text-primary uppercase text-base">${t.booking_time} hrs · Hoyo #${t.starting_hole||1}</span>
                </div>
                <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-400 font-bold">Total Jugadores & Carritos:</span>
                    <span class="font-black text-emerald-400 uppercase">${t.total_players} Jugadores · ${t.total_carts||0} Carrito(s)${t.total_club_rentals?` · ${t.total_club_rentals} Equipo(s)`:``}</span>
                </div>
                <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-400 font-bold">Total Pagado:</span>
                    <span class="font-black text-white uppercase text-sm">$${parseFloat(t.total_amount||0).toLocaleString(`es-MX`,{minimumFractionDigits:2})} (${t.payment_method})</span>
                </div>
                
                <div class="pt-2 border-t border-slate-700/80">
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Integrantes del Grupo:</p>
                    <div class="space-y-1.5">
                        ${playersList.map((e,t)=>`
                            <div class="flex items-center justify-between px-3 py-2 bg-slate-900/90 rounded-xl border border-slate-700 text-xs">
                                <div class="flex items-center gap-2">
                                    <span class="font-black text-primary">#${t+1}</span>
                                    <span class="font-black text-white uppercase">${e.name||`Sin Nombre`}</span>
                                    <span class="px-2 py-0.5 bg-slate-800 text-slate-400 rounded text-[9px] font-black">${e.player_type||`INVITADO`}</span>
                                </div>
                                <span class="text-slate-400 font-bold">${e.holes||18} Hoyos ${e.has_cart?`· 🚗 Carro`:``} ${e.has_clubs?`· 🏌️ Palos`:``}</span>
                            </div>
                        `).join(``)}
                    </div>
                </div>
            </div>

            <form id="form-register-teetime-output" class="space-y-4 pt-2 border-t border-slate-800">
                <h4 class="font-black uppercase text-xs text-white tracking-wider">Asignar Recursos y Dar Salida</h4>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Hoyo de Salida</label>
                        <select id="tt-out-hole" class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-xs font-black text-white focus:outline-none focus:border-primary">
                            ${Array.from({length:18},(e,t)=>t+1).map(e=>`
                                <option value="${e}" ${a===e?`selected`:``}>HOYO ${e}${e===1?` (Tee Inicial)`:e===10?` (Vuelta 2)`:``}</option>
                            `).join(``)}
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Carrito(s) Asignados (#)</label>
                        <input id="tt-out-carts" type="text" value="${t.cart_numbers||``}" placeholder="Ej. Carro #4, #12" class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-xs font-black text-white focus:outline-none focus:border-primary">
                    </div>
                </div>

                <div>
                    <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Caddie(s) Asignados</label>
                    <input id="tt-out-caddie" type="text" value="${t.caddie_assigned||``}" placeholder="Ej. Caddie Pedro y Luis" class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:border-primary">
                </div>

                <button type="submit"
                    class="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-xl shadow-emerald-500/20">
                    <span class="material-icons">play_circle_filled</span> ${r?`Actualizar Salida en Campo`:`⛳ Autorizar Salida al Campo`}
                </button>
            </form>
        `,document.getElementById(`form-register-teetime-output`).onsubmit=async e=>{e.preventDefault();let n=parseInt(document.getElementById(`tt-out-hole`).value)||1,r=document.getElementById(`tt-out-carts`).value.trim(),i=document.getElementById(`tt-out-caddie`).value.trim();await D(t.id,n,r,i)};return}let a=d.data,o=a.paid_until&&a.paid_until>=t&&a.status===`ACTIVE`,s=a.paid_until?new Date(a.paid_until+`T00:00:00`).toLocaleDateString(`es-MX`,{day:`2-digit`,month:`long`,year:`numeric`}):`Sin Fecha`;if(o){let t=u.find(e=>String(e.member_id)===String(a.id)||(e.member_name||``).trim().toLowerCase()===(a.name||``).trim().toLowerCase()),i=1,o=``;if(t){i=t.round_type===`FRONT_9`?10:1;let e=t.round_type===`FRONT_9`?`1ra Vuelta (Hoyos 1-9 · Blancas)`:`2da Vuelta (Hoyos 10-18 · Azules)`,n=t.round_type===`FRONT_9`?`2da Vuelta (Hoyo 10 · Marcas Azules)`:`1ra Vuelta (Hoyo 1 · Marcas Blancas)`;o=`
                <div class="bg-amber-500/15 border-2 border-amber-500/60 rounded-2xl p-4 space-y-2 animate-fade-in shadow-lg shadow-amber-500/10">
                    <div class="flex items-center justify-between gap-2">
                        <span class="flex items-center gap-1.5 text-amber-400 font-black text-xs uppercase tracking-wider">
                            <span class="material-icons text-base">notification_important</span> ¡Scorecard Incompleto de 9 Hoyos!
                        </span>
                        <span class="px-2 py-0.5 bg-amber-500/30 text-amber-200 rounded text-[9px] font-black uppercase">Vigencia 6 Días</span>
                    </div>
                    <div class="bg-slate-900/90 border border-amber-500/40 rounded-xl p-3 space-y-1 text-xs">
                        <p class="font-black text-white text-sm uppercase">${t.member_name}</p>
                        <p class="text-slate-300 font-bold">
                            Jugó ${e} el día <strong>${t.played_date}</strong> (${t.partial_gross} golpes).
                        </p>
                        <p class="text-amber-300 font-black flex items-center gap-1">
                            <span class="material-icons text-sm">arrow_forward</span> Le corresponde salir por: <strong>Hoyo #${i} (${n})</strong> para completar su tarjeta oficial de 18 hoyos.
                        </p>
                    </div>
                </div>
            `}e.className=`bg-slate-900 border-2 border-emerald-500/60 rounded-3xl p-8 shadow-2xl space-y-6 animate-fade-in text-left`,e.innerHTML=`
            <div class="flex items-center justify-between gap-4 bg-emerald-500/10 border border-emerald-500/30 p-5 rounded-2xl">
                <div class="flex items-center gap-4">
                    <div class="w-14 h-14 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center shrink-0 shadow-lg shadow-emerald-500/30">
                        <span class="material-icons" style="font-size:32px">check_circle</span>
                    </div>
                    <div>
                        <span class="px-3 py-1 bg-emerald-500 text-slate-950 font-black text-[10px] uppercase rounded-full tracking-wider">🟢 AUTORIZADO</span>
                        <h3 class="font-black text-white text-xl uppercase mt-1">SOCIO AL CORRIENTE</h3>
                    </div>
                </div>
            </div>

            ${o}

            <div class="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 space-y-3">
                <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-400 font-bold"># Socio / Expediente:</span>
                    <span class="font-black text-white text-sm bg-slate-900 px-3 py-1 rounded-lg border border-slate-700">#${a.member_number}</span>
                </div>
                <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-400 font-bold">Nombre del Socio:</span>
                    <span class="font-black text-white uppercase text-base">${a.name}</span>
                </div>
                <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-400 font-bold">Categoría:</span>
                    <span class="font-black text-slate-300 uppercase">${a.category||`TITULAR`}</span>
                </div>
                <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-400 font-bold">Cuota Vigente Hasta:</span>
                    <span class="font-black text-emerald-400 uppercase">${s}</span>
                </div>
                <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-400 font-bold">Handicap Index:</span>
                    <span class="font-black text-amber-400 text-base">${a.current_handicap===void 0?`0.0`:a.current_handicap}</span>
                </div>
            </div>

            <form id="form-register-output" class="space-y-4 pt-2 border-t border-slate-800">
                <h4 class="font-black uppercase text-xs text-white tracking-wider">Registrar Salida al Campo Hoy</h4>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Hoyo de Salida</label>
                        <select id="out-hole" class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-xs font-black text-white focus:outline-none focus:border-primary">
                            ${Array.from({length:18},(e,t)=>t+1).map(e=>`
                                <option value="${e}" ${e===i?`selected`:``}>HOYO ${e}${e===1?` (Tee Inicial)`:e===10?` (Vuelta 2)`:``}</option>
                            `).join(``)}
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Invitados / Acompañantes</label>
                        <input id="out-guests" type="number" min="0" max="4" value="0" class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-xs font-black text-white focus:outline-none focus:border-primary">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Caddie Asignado</label>
                        <input id="out-caddie" type="text" placeholder="Ej. Caddie Pedro" class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:border-primary">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Carrito #</label>
                        <input id="out-cart" type="text" placeholder="Ej. Carro #12" class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:border-primary">
                    </div>
                </div>

                <button type="submit"
                    class="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-xl shadow-emerald-500/20">
                    <span class="material-icons">play_circle_filled</span> Registrar Salida al Campo
                </button>
            </form>
        `,document.getElementById(`form-register-output`).onsubmit=async e=>{e.preventDefault();let t=parseInt(document.getElementById(`out-hole`).value)||1,i=parseInt(document.getElementById(`out-guests`).value)||0,o=document.getElementById(`out-caddie`).value.trim(),s=document.getElementById(`out-cart`).value.trim(),c={member_id:a.id,member_number:a.member_number,member_name:a.name,player_type:`MEMBER`,starting_hole:t,guests_count:i,caddie_name:o,cart_number:s,notes:`Salida individual socio ${a.name}`,score_status:`PENDING`};try{let{error:e}=await n.from(`daily_outputs`).insert([c]);e&&await r.from(`daily_outputs`).insert([c])}catch{await r.from(`daily_outputs`).insert([c])}window.showNotification?.(`¡Salida Registrada!`,`Salida autorizada para ${a.name} por el Hoyo #${t}.`,`success`),await x()}}else e.className=`bg-slate-900 border-2 border-rose-500/60 rounded-3xl p-8 shadow-2xl space-y-6 animate-fade-in text-left`,e.innerHTML=`
            <div class="flex items-center justify-between gap-4 bg-rose-500/10 border border-rose-500/30 p-5 rounded-2xl">
                <div class="flex items-center gap-4">
                    <div class="w-14 h-14 rounded-2xl bg-rose-500 text-white flex items-center justify-center shrink-0 shadow-lg shadow-rose-500/30">
                        <span class="material-icons" style="font-size:32px">warning</span>
                    </div>
                    <div>
                        <span class="px-3 py-1 bg-rose-500 text-white font-black text-[10px] uppercase rounded-full tracking-wider">🔴 NO AUTORIZADO</span>
                        <h3 class="font-black text-white text-xl uppercase mt-1">PAGO PENDIENTE / INACTIVO</h3>
                    </div>
                </div>
            </div>

            <div class="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 space-y-3">
                <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-400 font-bold"># Socio / Expediente:</span>
                    <span class="font-black text-white text-sm bg-slate-900 px-3 py-1 rounded-lg border border-slate-700">#${a.member_number}</span>
                </div>
                <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-400 font-bold">Nombre del Socio:</span>
                    <span class="font-black text-white uppercase text-base">${a.name}</span>
                </div>
                <div class="flex justify-between items-center text-xs">
                    <span class="text-slate-400 font-bold">Cuota Vencida Desde:</span>
                    <span class="font-black text-rose-400 uppercase text-sm">${s}</span>
                </div>
            </div>

            <div class="p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-xs text-rose-300 font-bold leading-relaxed">
                ⚠️ Este socio cuenta con adeudo o suspensión de membresía. Por favor solícitale acudir a Recepción / Casa Club para regularizar su cuota antes de salir a jugar.
            </div>
        `}function E(){let e=document.getElementById(`caddie-teetimes-container`),t=document.getElementById(`teetimes-search-input`),n=t?t.value.toLowerCase().trim():``;if(!e)return;let r=c.filter(e=>{if(e.status===`CANCELLED`)return!1;if(!n)return!0;let t=Array.isArray(e.players)?e.players.map(e=>e.name).join(` `):``;return`${e.folio||``} ${e.contact_name||``} ${t} ${e.caddie_assigned||``} ${e.cart_numbers||``}`.toLowerCase().includes(n)});if(r.length===0){e.innerHTML=`
            <div class="py-12 text-center bg-slate-950/40 border border-slate-800 rounded-2xl">
                <span class="material-icons text-slate-600 text-4xl mb-2">sports_golf</span>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-wider">No hay salidas de recepción registradas para hoy con ese término.</p>
            </div>`;return}e.innerHTML=r.map(e=>{let t=e.status===`PAID`,n=e.status===`ON_COURSE`;e.status;let r=Array.isArray(e.players)?e.players:[],i=``;return i=n?`<span class="px-3 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-xl text-xs font-black uppercase flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-emerald-400"></span> ⛳ En Campo</span>`:t?`<span class="px-3 py-1 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded-xl text-xs font-black uppercase flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-blue-400"></span> 🔵 Pagado / En Tee</span>`:`<span class="px-3 py-1 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-xl text-xs font-black uppercase flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-amber-400"></span> 🟡 Reserva</span>`,`
            <div class="bg-slate-950/80 border ${n?`border-emerald-500/40`:t?`border-blue-500/40`:`border-slate-800`} rounded-2xl p-5 shadow-lg space-y-4 hover:border-slate-700 transition-all">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
                    <div class="flex items-center gap-3">
                        <span class="px-3.5 py-1.5 bg-slate-900 border border-slate-700 rounded-xl font-black text-sm text-white">
                            ${e.booking_time} hrs
                        </span>
                        <div>
                            <div class="flex items-center gap-2">
                                <h4 class="font-black text-white uppercase text-sm">${e.contact_name||`Grupo`}</h4>
                                <span class="px-2 py-0.5 bg-slate-900 border border-slate-700 rounded-lg text-[10px] font-black text-slate-400">${e.folio}</span>
                            </div>
                            <p class="text-[10px] text-slate-400 font-bold uppercase mt-0.5">Tee Inicial: <span class="text-white font-black">Hoyo #${e.starting_hole||1}</span> · ${e.total_players} Jugadores · ${e.total_carts||0} Carrito(s)</p>
                        </div>
                    </div>

                    <div class="flex items-center gap-3 shrink-0">
                        ${i}
                        <button onclick="window.openAuthorizeModal('${e.id}')"
                            class="px-4 py-2 ${n?`bg-slate-800 hover:bg-slate-700 text-slate-300`:`bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20`} rounded-xl font-black text-xs uppercase flex items-center gap-1.5 transition-all">
                            <span class="material-icons text-sm">${n?`edit`:`play_arrow`}</span>
                            ${n?`Modificar Salida`:`⛳ Dar Salida`}
                        </button>
                    </div>
                </div>

                <!-- Players & Score Capture Section -->
                ${n||e.status===`COMPLETED`?`
                    <div class="pt-2 border-t border-slate-800/80 space-y-3">
                        <div class="flex items-center justify-between">
                            <h5 class="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                                <span class="material-icons text-sm text-primary">edit_note</span> Captura de Scores / Entrega de Tarjeta
                            </h5>
                            <span class="text-[10px] font-bold text-slate-400 uppercase">
                                ${n?`🏌️ En Campo`:`🏁 Concluido`}
                            </span>
                        </div>

                        <div class="space-y-2.5">
                            ${r.map((t,n)=>{let r=t.name||e.contact_name||`Jugador #${n+1}`,i=s.find(n=>(n.tee_time_id===e.id||n.folio===e.folio)&&(n.member_name===r||!t.name&&n.member_name===e.contact_name));i?i.id:`${e.id}${n}`;let a=i&&i.score_status||`PENDING`,o=i?i.gross_score:null;return`
                                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 bg-slate-900/90 rounded-2xl border ${a===`CAPTURED`?`border-emerald-500/40 shadow-emerald-500/5`:a===`NO_CARD`?`border-amber-500/40 shadow-amber-500/5`:`border-slate-800`} shadow-sm hover:border-slate-700 transition-all">
                                        <div class="flex items-center gap-3 min-w-0">
                                            <span class="w-7 h-7 rounded-xl bg-primary/20 text-primary border border-primary/30 flex items-center justify-center font-black text-xs shrink-0">#${n+1}</span>
                                            <div class="min-w-0">
                                                <div class="flex items-center gap-2 flex-wrap">
                                                    <span class="font-black text-white text-xs sm:text-sm uppercase truncate">${r}</span>
                                                    <span class="text-[9px] px-2 py-0.5 rounded-lg ${t.is_member?`bg-emerald-500/10 text-emerald-400 border border-emerald-500/20`:`bg-blue-500/10 text-blue-400 border border-blue-500/20`} font-black shrink-0">
                                                        ${t.is_member?`SOCIO`:t.player_type||`INVITADO`}
                                                    </span>
                                                    ${t.has_cart?`<span class="text-amber-400 text-xs material-icons" title="Renta Carrito">electric_car</span>`:``}
                                                </div>
                                                <div class="mt-0.5 flex items-center gap-2">
                                                    ${a===`CAPTURED`?`
                                                        <span class="px-2.5 py-0.5 bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 rounded-lg text-[10px] font-black flex items-center gap-1">
                                                            <span class="material-icons text-xs">check_circle</span> Gross: ${o} golpes
                                                        </span>
                                                    `:a===`NO_CARD`?`
                                                        <span class="px-2.5 py-0.5 bg-amber-500/15 text-amber-400 border border-amber-500/30 rounded-lg text-[10px] font-black flex items-center gap-1">
                                                            <span class="material-icons text-xs">block</span> No entregó tarjeta (Par ${g} archivado)
                                                        </span>
                                                    `:`
                                                        <span class="text-[10px] font-bold text-amber-400/90 flex items-center gap-1">
                                                            <span class="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span> Pendiente de entrega
                                                        </span>
                                                    `}
                                                </div>
                                            </div>
                                        </div>

                                        <!-- 2 Buttons: Agregar Score & No entregó tarjeta -->
                                        <div class="flex items-center gap-2 shrink-0">
                                            <button type="button" onclick="window.openScoreCaptureForPlayer('${e.id}', '${r.replace(/'/g,`\\'`)}', '${t.member_id||``}')"
                                                class="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase rounded-xl transition-all shadow-md flex items-center gap-1.5 active:scale-95">
                                                <span class="material-icons text-sm">${a===`CAPTURED`?`edit`:`add_chart`}</span>
                                                ${a===`CAPTURED`?`Editar Score`:`Agregar Score`}
                                            </button>

                                            <button type="button" onclick="window.submitQuickNoScore('${e.id}', '${r.replace(/'/g,`\\'`)}', '${t.member_id||``}')"
                                                title="Asignar automáticamente Par de Campo (${g}) y archivar tarjeta"
                                                class="px-3.5 py-2 ${a===`NO_CARD`?`bg-slate-800 text-slate-400 border border-slate-700`:`bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 border border-amber-500/40`} font-black text-xs uppercase rounded-xl transition-all flex items-center gap-1.5 active:scale-95">
                                                <span class="material-icons text-sm">block</span> No entregó tarjeta
                                            </button>
                                        </div>
                                    </div>
                                `}).join(``)}
                        </div>
                    </div>
                `:`
                    <!-- Players Badges -->
                    <div class="flex flex-wrap items-center gap-2">
                        ${r.map((e,t)=>`
                            <div class="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/90 rounded-xl border border-slate-800 text-xs font-black">
                                <span class="text-primary text-[10px]">#${t+1}</span>
                                <span class="text-white uppercase">${e.name||`Sin Nombre`}</span>
                                <span class="text-[9px] px-1.5 py-0.5 rounded ${e.is_member?`bg-emerald-500/10 text-emerald-400`:`bg-blue-500/10 text-blue-400`} font-bold">
                                    ${e.is_member?`SOCIO`:e.player_type||`INVITADO`}
                                </span>
                                ${e.has_cart?`<span class="text-amber-400 text-[10px] material-icons" title="Renta Carrito">electric_car</span>`:``}
                                ${e.has_clubs?`<span class="text-blue-400 text-[10px] material-icons" title="Renta de Equipo (Palos)">sports_golf</span>`:``}
                            </div>
                        `).join(``)}
                    </div>
                `}

                ${e.caddie_assigned||e.cart_numbers?`
                    <div class="flex items-center gap-4 text-xs font-bold text-slate-400 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800/80">
                        ${e.caddie_assigned?`<span class="flex items-center gap-1 text-emerald-400"><span class="material-icons text-sm">sports_golf</span> Caddie: <strong>${e.caddie_assigned}</strong></span>`:``}
                        ${e.cart_numbers?`<span class="flex items-center gap-1 text-amber-400"><span class="material-icons text-sm">electric_car</span> Carrito(s): <strong>${e.cart_numbers}</strong></span>`:``}
                        ${e.departure_time?`<span class="text-slate-500 text-[10px]">Salida: ${new Date(e.departure_time).toLocaleTimeString(`es-MX`,{hour:`2-digit`,minute:`2-digit`})}</span>`:``}
                    </div>
                `:``}
            </div>`}).join(``)}window.renderOnCoursePlayersList=function(){let e=document.getElementById(`oncourse-players-container`),t=document.getElementById(`tab-caddie-oncourse-badge`),n=document.getElementById(`oncourse-players-count`);if(!e)return;let r=(document.getElementById(`oncourse-search-input`)?.value||``).trim().toLowerCase(),i=c.filter(e=>e.status===`ON_COURSE`),a=[];if(i.forEach(e=>{(Array.isArray(e.players)&&e.players.length>0?e.players:[{name:e.contact_name,is_member:!0,player_type:`SOCIO`}]).forEach((t,n)=>{let i=t.name||e.contact_name||`Jugador #${n+1}`,o=s.find(n=>(n.tee_time_id===e.id||n.folio===e.folio)&&(n.member_name===i||!t.name&&n.member_name===e.contact_name)),c=o&&o.score_status||`PENDING`;if(c!==`CAPTURED`&&c!==`NO_CARD`&&c!==`PARTIAL_9`){if(r){let t=i.toLowerCase().includes(r),n=(e.caddie_assigned||``).toLowerCase().includes(r),a=(e.cart_numbers||``).toLowerCase().includes(r),o=(e.folio||``).toLowerCase().includes(r);if(!t&&!n&&!a&&!o)return}a.push({booking:e,player:t,playerIndex:n,name:i,output:o,status:c})}})}),t&&(t.textContent=a.length),n&&(n.textContent=a.length),a.length===0){e.innerHTML=`
            <div class="py-12 px-4 text-center bg-slate-950/40 border border-slate-800/80 rounded-2xl">
                <div class="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto mb-3">
                    <span class="material-icons text-3xl">sports_golf</span>
                </div>
                <h4 class="text-white font-black uppercase text-sm">No hay jugadores pendientes en campo</h4>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-wider mt-1 max-w-md mx-auto">
                    Todos los jugadores de las salidas en campo ya entregaron su tarjeta o tienen su score registrado.
                </p>
            </div>
        `;return}e.innerHTML=`
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            ${a.map(e=>{let{booking:t,player:n,playerIndex:r,name:i}=e;return`
                    <div class="p-4 bg-slate-950/80 border border-slate-800 hover:border-slate-700 rounded-2xl space-y-3 transition-all shadow-md">
                        <div class="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                            <div class="flex items-center gap-2">
                                <span class="px-2.5 py-1 bg-emerald-500/15 border border-emerald-500/30 rounded-xl font-black text-xs text-emerald-400">
                                    ⛳ Hoyo #${t.starting_hole||1}
                                </span>
                                <span class="px-2 py-0.5 bg-slate-800 text-slate-300 rounded-lg text-[10px] font-black uppercase">
                                    ${t.booking_time} hrs
                                </span>
                            </div>
                            <span class="text-[10px] font-bold text-slate-500 uppercase">Folio: ${t.folio}</span>
                        </div>

                        <div class="flex items-center justify-between gap-3">
                            <div class="min-w-0">
                                <div class="flex items-center gap-2">
                                    <h4 class="font-black text-white text-sm uppercase truncate">${i}</h4>
                                    <span class="text-[9px] px-2 py-0.5 rounded-lg ${n.is_member?`bg-emerald-500/10 text-emerald-400 border border-emerald-500/20`:`bg-blue-500/10 text-blue-400 border border-blue-500/20`} font-black">
                                        ${n.is_member?`SOCIO`:n.player_type||`INVITADO`}
                                    </span>
                                </div>
                                <div class="flex items-center gap-3 text-[11px] text-slate-400 font-bold mt-1 flex-wrap">
                                    ${t.caddie_assigned?`<span class="flex items-center gap-1 text-slate-300"><span class="material-icons text-xs text-primary">sports_golf</span> ${t.caddie_assigned}</span>`:``}
                                    ${t.cart_numbers?`<span class="flex items-center gap-1 text-amber-400"><span class="material-icons text-xs">electric_car</span> ${t.cart_numbers}</span>`:`<span class="text-slate-500 text-[10px]">A pie</span>`}
                                    ${n.has_clubs?`<span class="flex items-center gap-1 text-blue-400"><span class="material-icons text-xs">sports_golf</span> Renta Palos</span>`:``}
                                </div>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="pt-2 border-t border-slate-800/60 flex items-center gap-2 justify-end">
                            <button type="button" onclick="window.openScoreCaptureForPlayer('${t.id}', '${i.replace(/'/g,`\\'`)}', '${n.member_id||``}')"
                                class="px-3.5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase rounded-xl transition-all shadow-md flex items-center gap-1.5 active:scale-95">
                                <span class="material-icons text-sm">add_chart</span> Agregar Score
                            </button>

                            <button type="button" onclick="window.submitQuickNoScore('${t.id}', '${i.replace(/'/g,`\\'`)}', '${n.member_id||``}')"
                                title="Asignar automáticamente Par de Campo (${g}) y archivar tarjeta"
                                class="px-3 py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 border border-amber-500/40 font-black text-xs uppercase rounded-xl transition-all flex items-center gap-1.5 active:scale-95">
                                <span class="material-icons text-sm">block</span> No entregó tarjeta
                            </button>
                        </div>
                    </div>
                `}).join(``)}
        </div>
    `},window.openAuthorizeModal=function(e){let t=c.find(t=>String(t.id)===String(e));if(!t)return;let n=document.getElementById(`modal-member-crud`);n||(n=document.createElement(`div`),n.id=`modal-member-crud`,n.className=`fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in`,document.body.appendChild(n));let r=Array.isArray(t.players)?t.players:[];n.innerHTML=`
        <div class="w-full max-w-xl bg-slate-950/95 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col" onclick="event.stopPropagation()">
            <div class="p-5 border-b border-slate-800 flex justify-between items-center bg-slate-900/80">
                <div class="flex items-center gap-3">
                    <div class="w-11 h-11 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
                        <span class="material-icons">sports_golf</span>
                    </div>
                    <div>
                        <h3 class="font-black uppercase text-white text-base leading-none">Autorizar Salida al Campo</h3>
                        <p class="text-xs text-slate-400 font-bold uppercase mt-1">Folio: ${t.folio} · ${t.booking_time} hrs</p>
                    </div>
                </div>
                <button type="button" onclick="window.closeCaddieModal()" class="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all" title="Cerrar">
                    <span class="material-icons" style="font-size:18px">close</span>
                </button>
            </div>

            <div class="p-6 space-y-5">
                <div class="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
                    <div class="flex justify-between items-center text-xs">
                        <span class="text-slate-400 font-bold">Contacto / Responsable:</span>
                        <span class="font-black text-white uppercase">${t.contact_name}</span>
                    </div>
                    <div class="flex justify-between items-center text-xs">
                        <span class="text-slate-400 font-bold">Jugadores en el Grupo:</span>
                        <span class="font-black text-emerald-400">${t.total_players} (${r.map(e=>e.name).filter(Boolean).join(`, `)||`Nombres pendientes`})</span>
                    </div>
                    <div class="flex justify-between items-center text-xs">
                        <span class="text-slate-400 font-bold">Carritos Pagados en Recepción:</span>
                        <span class="font-black text-amber-400">${t.total_carts||0} Carrito(s)</span>
                    </div>
                </div>

                <form id="form-modal-authorize-departure" class="space-y-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Hoyo de Salida *</label>
                            <select id="modal-out-hole" class="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-xs font-black text-white focus:outline-none focus:border-primary">
                                ${Array.from({length:18},(e,t)=>t+1).map(e=>`
                                    <option value="${e}" ${(parseInt(t.starting_hole)||1)===e?`selected`:``}>Hoyo ${e}${e===1?` (Tee Principal)`:e===10?` (Vuelta 2)`:``}</option>
                                `).join(``)}
                            </select>
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Número de Carrito(s)</label>
                            <input id="modal-out-cart" type="text" value="${t.cart_numbers||``}" placeholder="Ej. Carro #3, #7" class="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-xs font-black text-white focus:outline-none focus:border-primary">
                        </div>
                    </div>

                    <div>
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Caddie(s) Asignado(s)</label>
                        <input id="modal-out-caddie" type="text" value="${t.caddie_assigned||``}" placeholder="Ej. Caddie Juan Pérez" class="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:border-primary">
                    </div>

                    <div class="pt-3 border-t border-slate-800 flex justify-end gap-3">
                        <button type="button" onclick="window.closeCaddieModal()" class="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-black text-xs uppercase transition-all">
                            Cancelar
                        </button>
                        <button type="submit" class="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl font-black text-xs uppercase transition-all shadow-lg shadow-emerald-500/20 flex items-center gap-1.5">
                            <span class="material-icons text-sm">check_circle</span> Confirmar Salida
                        </button>
                    </div>
                </form>
            </div>
        </div>
    `,n.className=`fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in`,n.style.display=`flex`,n.classList.remove(`hidden`),n.onclick=e=>{e.target===n&&window.closeCaddieModal()},document.getElementById(`form-modal-authorize-departure`).onsubmit=async e=>{e.preventDefault();let n=parseInt(document.getElementById(`modal-out-hole`).value)||1,r=document.getElementById(`modal-out-cart`).value.trim(),i=document.getElementById(`modal-out-caddie`).value.trim();await D(t.id,n,r,i),window.closeCaddieModal()}};async function D(e,t,i,a){let o=c.find(t=>String(t.id)===String(e));if(o)try{let e=new Date().toISOString();await n.from(`tee_times`).update({status:`ON_COURSE`,departure_time:e,starting_hole:t,cart_numbers:i,caddie_assigned:a}).eq(`id`,o.id);let s=Array.isArray(o.players)&&o.players.length>0?o.players:[{name:o.contact_name,is_member:!1,player_type:`GUEST`}];for(let e of s){let s={tee_time_id:o.id,folio:o.folio,member_id:e.member_id||null,member_number:e.member_number||`INV`,member_name:e.name||o.contact_name,player_type:e.is_member?`MEMBER`:e.player_type||`GUEST`,starting_hole:t,caddie_name:a,cart_number:i,score_status:`PENDING`};try{let{error:e}=await n.from(`daily_outputs`).insert([s]);e&&await r.from(`daily_outputs`).insert([s])}catch{await r.from(`daily_outputs`).insert([s])}}window.showNotification?.(`¡Salida Autorizada!`,`Grupo ${o.contact_name} en campo por el Hoyo #${t}.`,`success`),await x()}catch(e){console.error(`Error authorizing departure:`,e),window.showNotification?.(`Error`,`No se pudo actualizar la salida: `+e.message,`error`)}}function O(){let e=document.getElementById(`caddie-outputs-table-container`),t=document.getElementById(`log-search-input`),n=t?t.value.toLowerCase().trim():``;if(!e)return;let r=s.filter(e=>!n||`${e.member_name} ${e.member_number} ${e.caddie_name||``} ${e.cart_number||``} ${e.notes||``}`.toLowerCase().includes(n));if(r.length===0){e.innerHTML=`
            <div class="py-12 text-center bg-slate-950/40 border border-slate-800 rounded-2xl">
                <span class="material-icons text-slate-600 text-4xl mb-2">sports_golf</span>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-wider">Aún no hay salidas registradas con ese término el día de hoy.</p>
            </div>`;return}e.innerHTML=`
        <div class="bg-slate-950/60 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="bg-slate-900 border-b border-slate-800 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                        <th class="px-5 py-3.5">Hora</th>
                        <th class="px-5 py-3.5"># Socio / ID</th>
                        <th class="px-5 py-3.5">Jugador</th>
                        <th class="px-5 py-3.5 text-center">Hoyo Salida</th>
                        <th class="px-5 py-3.5">Caddie / Carro</th>
                        <th class="px-5 py-3.5 text-center">Score / Estatus</th>
                        <th class="px-5 py-3.5 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/60">
                    ${r.map(e=>{let t=new Date(e.created_at).toLocaleTimeString(`es-MX`,{hour:`2-digit`,minute:`2-digit`}),n=e.score_status||`PENDING`,r=e.gross_score!==null&&e.gross_score!==void 0?e.gross_score:null,i=``;return i=n===`CAPTURED`?`<span class="px-3 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-full font-black text-xs">🟢 Gross: ${r}</span>`:n===`PARTIAL_9`?`<span class="px-3 py-1 bg-amber-500/15 text-amber-300 border border-amber-500/40 rounded-full font-black text-xs">⏱️ 9 Hoyos (${r} g)</span>`:n===`NO_CARD`?`<span class="px-3 py-1 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded-full font-black text-xs">🟡 No Entregó (Par ${g})</span>`:`<span class="px-3 py-1 bg-slate-800 text-slate-400 border border-slate-700 rounded-full font-black text-[10px]">⏳ En Juego</span>`,`
                            <tr class="hover:bg-slate-800/40 transition-colors">
                                <td class="px-5 py-3.5 font-black text-emerald-400 text-sm">${t}</td>
                                <td class="px-5 py-3.5"><span class="font-black text-slate-300 bg-slate-800 px-2.5 py-1 rounded-md text-[11px]">#${e.member_number||`INV`}</span></td>
                                <td class="px-5 py-3.5 font-black text-white uppercase text-sm">${e.member_name}</td>
                                <td class="px-5 py-3.5 text-center font-black text-blue-400">Hoyo #${e.starting_hole||1}</td>
                                <td class="px-5 py-3.5 text-slate-400 font-bold">
                                    ${e.caddie_name?`<span class="text-slate-300">🏌️ ${e.caddie_name}</span>`:`S/C`}
                                    ${e.cart_number?`<span class="text-amber-400 ml-1.5">🚗 ${e.cart_number}</span>`:``}
                                </td>
                                <td class="px-5 py-3.5 text-center font-bold">${i}</td>
                                <td class="px-5 py-3.5 text-right">
                                    <div class="flex items-center justify-end gap-2">
                                        <button onclick="window.openScoreCaptureModal('${e.id}')"
                                            class="px-3.5 py-2 bg-primary/20 hover:bg-primary/30 border border-primary/40 text-primary rounded-xl font-black text-xs uppercase flex items-center gap-1.5 transition-all shadow-md">
                                            <span class="material-icons" style="font-size:16px">edit_note</span> ${n===`PENDING`?`Capturar Scorecard`:n===`PARTIAL_9`?`Completar 18H`:`Editar Scorecard`}
                                        </button>
                                        <button onclick="window.setNoScorePar('${e.id}')"
                                            title="Marcar No Entregó Tarjeta (Asigna Par de Campo ${g})"
                                            class="px-3.5 py-2 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-400 rounded-xl font-black text-xs uppercase flex items-center gap-1.5 transition-all shadow-md">
                                            <span class="material-icons" style="font-size:16px">block</span> No Entregó (Par ${g})
                                        </button>
                                    </div>
                                </td>
                            </tr>`}).join(``)}
                </tbody>
            </table>
        </div>`}window.setNoScorePar=async function(e){let t=s.find(t=>String(t.id)===String(e));t&&window.showNotification?.(`No Entregó Tarjeta`,`¿Confirmas marcar que el jugador ${t.member_name} no entregó tarjeta? Se le asignará automáticamente Par de Campo (${g}).`,`confirm`,async()=>{try{await n.from(`daily_outputs`).update({score_status:`NO_CARD`,gross_score:g}).eq(`id`,t.id)}catch{await r.from(`daily_outputs`).update({score_status:`NO_CARD`,gross_score:g}).eq(`id`,t.id)}let e={};if(h.forEach(t=>{e[`h${t.hole}`]=t.par}),t.member_id){let a=parseFloat((113/v*.5).toFixed(1)),o={member_id:t.member_id,output_id:t.id,date_played:m||i(),gross_score:g,course_rating:_,slope_rating:v,differential:a,hole_scores:e,delivered:!1,notes:`No entregó tarjeta (Par de Campo ${g})`};try{await n.from(`member_scores`).insert([o])}catch{await r.from(`member_scores`).insert([o])}await A(t.member_id)}window.showNotification?.(`Score Registrado`,`Se asignó Par de Campo (${g}) a ${t.member_name}.`,`success`),await x(),f===`ONCOURSE`&&window.renderOnCoursePlayersList()})},window.calcQuickGross=function(e){let t=document.getElementById(`quick-ida-${e}`),n=document.getElementById(`quick-vuelta-${e}`),r=document.getElementById(`quick-gross-val-${e}`);if(!r)return;let i=parseInt(t?.value)||0,a=parseInt(n?.value)||0;r.textContent=i>0||a>0?`${i+a} golpes`:`—`},window.submitQuickScore=async function(e,t,a){let o=c.find(t=>String(t.id)===String(e));if(!o)return;let l=t||o.contact_name,u=s.find(e=>(e.tee_time_id===o.id||e.folio===o.folio)&&(e.member_name===l||!t&&e.member_name===o.contact_name)),d=u?u.id:`tmp_${o.id}_${l}`,f=document.getElementById(`quick-ida-${d}`),p=document.getElementById(`quick-vuelta-${d}`),g=parseInt(f?.value)||0,y=parseInt(p?.value)||0,b=g+y;if(b<=0){window.showNotification?.(`Score Inválido`,`Por favor ingresa los golpes de Ida y/o Vuelta.`,`error`);return}try{if(!u||String(u.id).startsWith(`tmp_`)){let e={tee_time_id:o.id,folio:o.folio,member_id:a||null,member_number:a?`SOC`:`INV`,member_name:l,player_type:a?`MEMBER`:`GUEST`,starting_hole:o.starting_hole||1,caddie_name:o.caddie_assigned||``,cart_number:o.cart_numbers||``,score_status:`CAPTURED`,gross_score:b};try{let{data:t}=await n.from(`daily_outputs`).insert([e]).select().single();u=t}catch{try{let{data:t}=await r.from(`daily_outputs`).insert([e]).select().single();u=t}catch{}}}else try{await n.from(`daily_outputs`).update({score_status:`CAPTURED`,gross_score:b}).eq(`id`,u.id)}catch{await r.from(`daily_outputs`).update({score_status:`CAPTURED`,gross_score:b}).eq(`id`,u.id)}let e=a||u&&u.member_id;if(e&&e!==`null`&&e!==`undefined`&&e!==``){let t=parseFloat((113/v*(b-_)).toFixed(1)),a={};h.slice(0,9).forEach(e=>{a[`h${e.hole}`]=Math.round(g/9)||e.par}),h.slice(9,18).forEach(e=>{a[`h${e.hole}`]=Math.round(y/9)||e.par});let o={member_id:e,output_id:u?u.id:null,date_played:m||i(),gross_score:b,course_rating:_,slope_rating:v,differential:t,hole_scores:a,delivered:!0,notes:`Captura rápida Caddie Master (Ida: ${g}, Vuelta: ${y})`};try{await n.from(`member_scores`).insert([o])}catch{await r.from(`member_scores`).insert([o])}await A(e)}window.showNotification?.(`¡Score Guardado!`,`Score Gross de ${b} guardado para ${l}.`,`success`),await x()}catch(e){console.error(`Error in submitQuickScore:`,e),window.showNotification?.(`Error`,`No se pudo guardar el score: `+e.message,`error`)}},window.submitQuickNoScore=async function(e,t,i){let a=c.find(t=>String(t.id)===String(e));if(!a)return;let o=t||a.contact_name,l=s.find(e=>(e.tee_time_id===a.id||e.folio===a.folio)&&(e.member_name===o||!t&&e.member_name===a.contact_name));if(!l||String(l.id).startsWith(`tmp_`)){let e={tee_time_id:a.id,folio:a.folio,member_id:i||null,member_number:i?`SOC`:`INV`,member_name:o,player_type:i?`MEMBER`:`GUEST`,starting_hole:a.starting_hole||1,caddie_name:a.caddie_assigned||``,cart_number:a.cart_numbers||``,score_status:`NO_CARD`,gross_score:g};try{let{data:t}=await n.from(`daily_outputs`).insert([e]).select().single();t&&(l=t)}catch{try{let{data:t}=await r.from(`daily_outputs`).insert([e]).select().single();t&&(l=t)}catch{}}l||={id:`tmp_${a.id}_${encodeURIComponent(o)}`,...e},s.find(e=>e.id===l.id)||s.push(l)}await window.setNoScorePar(l.id,l)},window.openScoreCaptureForPlayer=async function(e,t,i){let a=c.find(t=>String(t.id)===String(e));if(!a){console.warn(`Booking not found for teeTimeId:`,e);return}let o=t||a.contact_name,l=s.find(e=>(e.tee_time_id===a.id||e.folio===a.folio)&&(e.member_name===o||!t&&e.member_name===a.contact_name));if(!l){l={id:`tmp_${a.id}_${encodeURIComponent(o).replace(/[^a-zA-Z0-9]/g,``)}`,tee_time_id:a.id,folio:a.folio,member_id:i||null,member_number:i?`SOC`:`INV`,member_name:o,player_type:i?`MEMBER`:`GUEST`,starting_hole:a.starting_hole||1,caddie_name:a.caddie_assigned||``,cart_number:a.cart_numbers||``,score_status:`PENDING`,gross_score:null,hole_scores:{}},s.push(l);let e={tee_time_id:a.id,folio:a.folio,member_id:i||null,member_number:i?`SOC`:`INV`,member_name:o,player_type:i?`MEMBER`:`GUEST`,starting_hole:a.starting_hole||1,caddie_name:a.caddie_assigned||``,cart_number:a.cart_numbers||``,score_status:`PENDING`};n.from(`daily_outputs`).insert([e]).select().single().then(e=>{e.data&&(l.id=e.data.id)}).catch(()=>{r.from(`daily_outputs`).insert([e]).select().single().then(e=>{e.data&&(l.id=e.data.id)}).catch(()=>{})})}window.openScoreCaptureModal(l.id,l)},window.openPlayerDetailScoreModal=window.openScoreCaptureForPlayer,window.togglePlayerScorecardCollapse=function(e){let t=document.getElementById(`scorecard-panel-${e}`);t&&t.classList.toggle(`hidden`)},window.handleCaddieHoleKeyDown=function(e,t,n){if(e.key===`Enter`||e.key===`ArrowRight`){e.preventDefault();let r=document.getElementById(`caddie-score-${t}-h${n+1}`);r&&(r.focus(),r.select())}else if(e.key===`ArrowLeft`){e.preventDefault();let r=document.getElementById(`caddie-score-${t}-h${n-1}`);r&&(r.focus(),r.select())}},window.onCaddiePlayerHoleInput=function(e,t,n){let r=parseInt(n.value);window._playerHoleScores=window._playerHoleScores||{},window._playerHoleScores[e]=window._playerHoleScores[e]||{};let i=document.getElementById(`caddie-card-${e}-h${t}`);!isNaN(r)&&r>0?(window._playerHoleScores[e][`h${t}`]=r,i&&(i.className=`flex flex-col items-center justify-between p-2 rounded-2xl border transition-all bg-emerald-500/20 border-emerald-500/60 shadow-md shadow-emerald-500/10`,n.className=`w-full text-center py-2 sm:py-1.5 my-1 bg-emerald-950/90 border-2 border-emerald-500/60 text-emerald-300 rounded-xl font-black text-lg focus:outline-none focus:border-primary transition-all`)):(window._playerHoleScores[e][`h${t}`]=``,i&&(i.className=`flex flex-col items-center justify-between p-2 rounded-2xl border transition-all bg-slate-900/90 border-slate-800/90 hover:border-slate-700`,n.className=`w-full text-center py-2 sm:py-1.5 my-1 bg-slate-950 border-2 border-slate-700/80 text-white rounded-xl font-black text-lg focus:outline-none focus:border-primary transition-all`)),window.recalcPlayerScorecardTotals(e)},window.recalcPlayerScorecardTotals=function(e){let t=window._playerHoleScores?.[e]||{},n=0;for(let e=1;e<=9;e++){let r=parseInt(t[`h${e}`]);!isNaN(r)&&r>0&&(n+=r)}let r=0;for(let e=10;e<=18;e++){let n=parseInt(t[`h${e}`]);!isNaN(n)&&n>0&&(r+=n)}let i=n+r,a=document.getElementById(`caddie-in-${e}`),o=document.getElementById(`caddie-out-${e}`),s=document.getElementById(`caddie-gross-${e}`),c=document.getElementById(`caddie-net-${e}`);if(a&&(a.textContent=n),o&&(o.textContent=r),s&&(s.textContent=i),c){let e=parseFloat(c.getAttribute(`data-hcp`)||0);c.textContent=i>0?Math.max(0,Math.round(i-e)):0}},window.fillPlayerPar=function(e){window._playerHoleScores=window._playerHoleScores||{},window._playerHoleScores[e]={},h.forEach(t=>{window._playerHoleScores[e][`h${t.hole}`]=t.par;let n=document.getElementById(`caddie-score-${e}-h${t.hole}`),r=document.getElementById(`caddie-card-${e}-h${t.hole}`);n&&(n.value=t.par,n.className=`w-full text-center py-2 sm:py-1.5 my-1 bg-emerald-950/90 border-2 border-emerald-500/60 text-emerald-300 rounded-xl font-black text-lg focus:outline-none focus:border-primary transition-all`),r&&(r.className=`flex flex-col items-center justify-between p-2 rounded-2xl border transition-all bg-emerald-500/20 border-emerald-500/60 shadow-md shadow-emerald-500/10`)}),window.recalcPlayerScorecardTotals(e)},window.clearPlayerScorecard=function(e){window._playerHoleScores=window._playerHoleScores||{},window._playerHoleScores[e]={},h.forEach(t=>{let n=document.getElementById(`caddie-score-${e}-h${t.hole}`),r=document.getElementById(`caddie-card-${e}-h${t.hole}`);n&&(n.value=``,n.className=`w-full text-center py-2 sm:py-1.5 my-1 bg-slate-950 border-2 border-slate-700/80 text-white rounded-xl font-black text-lg focus:outline-none focus:border-primary transition-all`),r&&(r.className=`flex flex-col items-center justify-between p-2 rounded-2xl border transition-all bg-slate-900/90 border-slate-800/90 hover:border-slate-700`)}),window.recalcPlayerScorecardTotals(e)},window.savePlayerDetailedScorecard=async function(e,t,a,o){let l=c.find(t=>String(t.id)===String(e));if(!l)return;let u=t||l.contact_name,d=s.find(e=>(e.tee_time_id===l.id||e.folio===l.folio)&&(e.member_name===u||!t&&e.member_name===l.contact_name)),f=window._playerHoleScores?.[o]||{},p=0;for(let e=1;e<=18;e++){let t=parseInt(f[`h${e}`]);!isNaN(t)&&t>0&&(p+=t)}if(p===0){window.showNotification?.(`Score Vacío`,`Por favor ingresa los golpes de los hoyos o presiona "Llenar Par".`,`error`);return}try{if(!d||String(d.id).startsWith(`tmp_`)){let e={tee_time_id:l.id,folio:l.folio,member_id:a||null,member_number:a?`SOC`:`INV`,member_name:u,player_type:a?`MEMBER`:`GUEST`,starting_hole:l.starting_hole||1,caddie_name:l.caddie_assigned||``,cart_number:l.cart_numbers||``,score_status:`CAPTURED`,gross_score:p,hole_scores:f};try{let{data:t}=await n.from(`daily_outputs`).insert([e]).select().single();d=t}catch{try{let{data:t}=await r.from(`daily_outputs`).insert([e]).select().single();d=t}catch{}}}else try{await n.from(`daily_outputs`).update({score_status:`CAPTURED`,gross_score:p,hole_scores:f}).eq(`id`,d.id)}catch{await r.from(`daily_outputs`).update({score_status:`CAPTURED`,gross_score:p,hole_scores:f}).eq(`id`,d.id)}let e=a||d&&d.member_id;if(e&&e!==`null`&&e!==`undefined`&&e!==``){let t=parseFloat(((p-_)*113/v).toFixed(1)),a={member_id:e,output_id:d?d.id:null,date_played:m||i(),gross_score:p,course_rating:_,slope_rating:v,differential:t,hole_scores:f,delivered:!0,course_name:`CLUB DE GOLF COLIMA`,notes:`Scorecard 18 Hoyos Caddie Master (Gross: ${p})`};try{await n.from(`member_scores`).insert([a])}catch{await r.from(`member_scores`).insert([a])}await A(e)}window.showNotification?.(`¡Scorecard Guardado!`,`Scorecard de 18 hoyos (Gross: ${p}) guardado para ${u}.`,`success`),await x()}catch(e){console.error(`Error saving player scorecard:`,e),window.showNotification?.(`Error`,`No se pudo guardar el scorecard: `+e.message,`error`)}},window.closeCaddieModal=function(){let e=document.getElementById(`modal-member-crud`);e&&(e.classList.add(`hidden`),e.style.display=`none`,e.innerHTML=``)},window.setCaddieScoreMode=function(e,t,n=!1){window._caddieScoreMode=e,n&&(window._caddiePendingRecord=null,window._completingPendingRecord=null),window.openScoreCaptureModal(t)},window.setCaddieNineRound=function(e,t){window._caddieNineHolesRound=e,window.openScoreCaptureModal(t)},window.openScoreCaptureModal=function(e,t=null){let n=s.find(t=>String(t.id)===String(e))||t;n||={id:e,member_name:`Jugador`,member_number:`INV`,player_type:`GUEST`,starting_hole:1,score_status:`PENDING`,hole_scores:{}};let r=o.find(e=>String(e.id)===String(n.member_id)),i=r&&r.current_handicap||0,a=window._completingPendingRecord||(window._caddiePendingRecord===void 0?u.find(e=>e.status===`PENDING`&&(n.member_id&&String(e.member_id)===String(n.member_id)||(e.member_name||``).trim().toLowerCase()===(n.member_name||``).trim().toLowerCase())):window._caddiePendingRecord);a?(window._caddieScoreMode=`COMPLETING_18`,window._caddiePendingRecord=a):(!window._caddieScoreMode||window._caddieScoreMode===`COMPLETING_18`)&&(window._caddieScoreMode=`18_HOLES`,window._caddiePendingRecord=null),window._caddieNineHolesRound||(window._caddieNineHolesRound=n.starting_hole&&parseInt(n.starting_hole)>=10?`BACK_9`:`FRONT_9`);let c=document.getElementById(`modal-member-crud`);c||(c=document.createElement(`div`),c.id=`modal-member-crud`,document.body.appendChild(c)),c.className=`fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in`,c.style.display=`flex`,c.classList.remove(`hidden`),c.onclick=e=>{e.target===c&&window.closeCaddieModal()},window._caddieHoleScores={},h.forEach(e=>{a&&a.hole_scores&&a.hole_scores[`h${e.hole}`]!==void 0&&a.hole_scores[`h${e.hole}`]!==``?window._caddieHoleScores[`h${e.hole}`]=a.hole_scores[`h${e.hole}`]:window._caddieHoleScores[`h${e.hole}`]=n.hole_scores&&n.hole_scores[`h${e.hole}`]||``});let l=window._caddieScoreMode===`9_HOLES`,d=window._caddieScoreMode===`COMPLETING_18`,f=h.slice(0,9),p=h.slice(9,18);c.innerHTML=`
        <div class="w-full max-w-4xl bg-slate-950/95 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[95vh]" onclick="event.stopPropagation()">
            <!-- Header -->
            <div class="p-5 border-b border-slate-800 flex justify-between items-center bg-slate-900/80">
                <div class="flex items-center gap-3">
                    <div class="w-11 h-11 rounded-2xl ${l?`bg-amber-500/20 border-amber-500/40 text-amber-400`:`bg-emerald-500/20 border-emerald-500/40 text-emerald-400`} border flex items-center justify-center shrink-0">
                        <span class="material-icons">${l?`timer`:d?`workspace_premium`:`edit_note`}</span>
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <h3 class="font-black uppercase text-white text-lg leading-none">${n.member_name}</h3>
                            <span class="px-2.5 py-0.5 bg-slate-800 text-slate-300 font-black text-[10px] rounded-md border border-slate-700">#${n.member_number||`INV`}</span>
                        </div>
                        <p class="text-xs text-slate-400 font-bold uppercase mt-1">Handicap Index: <span class="text-amber-400 font-black">${i}</span> · Campo: Club de Golf Colima</p>
                    </div>
                </div>

                <div class="flex items-center gap-3">
                    <!-- Totals Bar -->
                    <div class="flex items-center gap-2 bg-slate-900 p-1.5 border border-slate-800 rounded-2xl">
                        <div class="px-3 py-1.5 bg-slate-800 rounded-xl text-center">
                            <p class="text-[8px] font-black text-slate-400 uppercase tracking-wider">IN (1-9)</p>
                            <p id="caddie-sc-in" class="text-sm font-black text-white">0</p>
                        </div>
                        <div class="px-3 py-1.5 bg-slate-800 rounded-xl text-center">
                            <p class="text-[8px] font-black text-slate-400 uppercase tracking-wider">OUT (10-18)</p>
                            <p id="caddie-sc-out" class="text-sm font-black text-white">0</p>
                        </div>
                        <div class="px-4 py-1.5 ${l?`bg-amber-500/20 border-amber-500/40`:`bg-emerald-500/20 border-emerald-500/40`} border rounded-xl text-center">
                            <p id="caddie-sc-gross-label" class="text-[8px] font-black ${l?`text-amber-400`:`text-emerald-400`} uppercase tracking-wider">
                                ${l?`GROSS 9 HOYOS`:`GROSS TOTAL`}
                            </p>
                            <p id="caddie-sc-gross" class="text-xl font-black ${l?`text-amber-400`:`text-emerald-400`} leading-none">0</p>
                        </div>
                    </div>

                    <button type="button" onclick="window.closeCaddieModal()" class="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all" title="Cerrar">
                        <span class="material-icons" style="font-size:18px">close</span>
                    </button>
                </div>
            </div>

            <!-- Body Scorecard -->
            <div class="p-6 overflow-y-auto custom-scrollbar space-y-5 flex-1">
                ${d?`
                    <!-- Banner de Tarjeta Incompleta Encontrada -->
                    <div class="bg-blue-500/15 border-2 border-blue-500/50 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-fade-in">
                        <div class="space-y-1">
                            <div class="flex items-center gap-2">
                                <span class="px-2.5 py-0.5 bg-blue-500 text-slate-950 rounded-md text-[10px] font-black uppercase tracking-wider">
                                    ⛳ Completando 18 Hoyos
                                </span>
                                <span class="text-[10px] text-blue-300 font-bold uppercase">
                                    Vigente hasta ${a.expires_at}
                                </span>
                            </div>
                            <p class="text-xs font-bold text-white">
                                Este jugador jugó ${a.round_type===`FRONT_9`?`1ra Vuelta (Hoyos 1 al 9 · Marcas Blancas)`:`2da Vuelta (Hoyos 10 al 18 · Marcas Azules)`} el día <strong>${a.played_date}</strong> con <strong>${a.partial_gross} golpes</strong>.
                            </p>
                            <p class="text-[11px] text-slate-400 font-medium">
                                Los 9 hoyos jugados están cargados y bloqueados. Ahora captura la vuelta restante para consolidar los 18 hoyos y enviarlos a Handicap Index WHS.
                            </p>
                        </div>
                        <button type="button" onclick="window.setCaddieScoreMode('18_HOLES', '${n.id}', true)"
                            class="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-xl text-[10px] font-black uppercase shrink-0 transition-all">
                            Capturar 18 Nuevos
                        </button>
                    </div>
                `:`
                    <!-- Selector de Modalidad: 18 Hoyos vs 9 Hoyos -->
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-2xl p-3 px-4">
                        <div class="flex items-center gap-2 flex-wrap">
                            <span class="text-xs font-black text-slate-400 uppercase tracking-wider">Modalidad:</span>
                            <div class="inline-flex bg-slate-950 p-1 rounded-xl border border-slate-800">
                                <button type="button" onclick="window.setCaddieScoreMode('18_HOLES', '${n.id}')"
                                    class="px-3.5 py-1.5 rounded-lg text-xs font-black uppercase transition-all flex items-center gap-1.5 ${l?`text-slate-400 hover:text-white`:`bg-primary text-slate-950 shadow-md shadow-primary/20`}">
                                    <span class="material-icons text-sm">flag</span> 18 Hoyos Completo
                                </button>
                                <button type="button" onclick="window.setCaddieScoreMode('9_HOLES', '${n.id}')"
                                    class="px-3.5 py-1.5 rounded-lg text-xs font-black uppercase transition-all flex items-center gap-1.5 ${l?`bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20`:`text-slate-400 hover:text-white`}">
                                    <span class="material-icons text-sm">timer</span> 9 Hoyos (Media Ronda)
                                </button>
                            </div>
                        </div>

                        ${l?`
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="text-[10px] font-black text-slate-400 uppercase tracking-wider">Vuelta jugada hoy:</span>
                                <div class="inline-flex bg-slate-950 p-1 rounded-xl border border-slate-800">
                                    <button type="button" onclick="window.setCaddieNineRound('FRONT_9', '${n.id}')"
                                        class="px-3 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${window._caddieNineHolesRound===`FRONT_9`?`bg-slate-200 text-slate-950 shadow-md`:`text-slate-400 hover:text-white`}">
                                        ⚪ 1ra Vuelta (1-9 · Blancas)
                                    </button>
                                    <button type="button" onclick="window.setCaddieNineRound('BACK_9', '${n.id}')"
                                        class="px-3 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${window._caddieNineHolesRound===`BACK_9`?`bg-blue-500 text-white shadow-md`:`text-slate-400 hover:text-white`}">
                                        🔵 2da Vuelta (10-18 · Azules)
                                    </button>
                                </div>
                            </div>
                        `:``}
                    </div>
                `}

                <!-- Presets Rápidos -->
                <div class="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-2xl p-3 px-4">
                    <span class="text-xs font-black text-slate-300 uppercase tracking-wider flex items-center gap-2">
                        <span class="material-icons text-primary text-sm">tune</span> Presets Rápidos
                    </span>
                    <div class="flex items-center gap-2">
                        <button type="button" onclick="window.caddieFillPar()" class="px-3 py-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-400 rounded-xl font-black text-[10px] uppercase transition-all">
                            ⚡ Auto-llenar Par ${l?`(Par 34)`:`(${g})`}
                        </button>
                        <button type="button" onclick="window.caddieClearScores()" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-xl font-black text-[10px] uppercase transition-all">
                            Limpiar
                        </button>
                    </div>
                </div>

                <!-- VUELTA 1-9 (IN) - Marcas Blancas -->
                <div class="bg-slate-900 border ${l&&window._caddieNineHolesRound===`FRONT_9`?`border-amber-500/50 shadow-lg shadow-amber-950/20`:`border-slate-800`} rounded-2xl p-4 space-y-3 transition-all">
                    <div class="flex items-center justify-between text-xs font-black uppercase tracking-widest border-b border-slate-800 pb-2">
                        <span class="flex items-center gap-2 ${l&&window._caddieNineHolesRound!==`FRONT_9`?`text-slate-500`:`text-slate-200`}">
                            <span class="w-2.5 h-2.5 rounded-full bg-slate-200 border border-slate-400"></span>
                            VUELTA 1-9 (IN) · TEES BLANCAS
                            ${d&&a.round_type===`FRONT_9`?`<span class="px-2 py-0.5 bg-blue-500/20 text-blue-300 rounded text-[9px] font-black border border-blue-500/30">JUGADO PREVIAMENTE</span>`:``}
                        </span>
                        <span class="text-[10px] ${l&&window._caddieNineHolesRound!==`FRONT_9`?`text-slate-600`:`text-slate-400`}">PAR 34</span>
                    </div>
                    <div class="grid grid-cols-9 gap-2">
                        ${f.map(e=>k(e)).join(``)}
                    </div>
                </div>

                <!-- VUELTA 10-18 (OUT) - Marcas Azules -->
                <div class="bg-slate-900 border ${l&&window._caddieNineHolesRound===`BACK_9`?`border-amber-500/50 shadow-lg shadow-amber-950/20`:`border-slate-800`} rounded-2xl p-4 space-y-3 transition-all">
                    <div class="flex items-center justify-between text-xs font-black uppercase tracking-widest border-b border-slate-800 pb-2">
                        <span class="flex items-center gap-2 ${l&&window._caddieNineHolesRound!==`BACK_9`?`text-slate-500`:`text-slate-200`}">
                            <span class="w-2.5 h-2.5 rounded-full bg-blue-500 border border-blue-400"></span>
                            VUELTA 10-18 (OUT) · TEES AZULES
                            ${d&&a.round_type===`BACK_9`?`<span class="px-2 py-0.5 bg-blue-500/20 text-blue-300 rounded text-[9px] font-black border border-blue-500/30">JUGADO PREVIAMENTE</span>`:``}
                        </span>
                        <span class="text-[10px] ${l&&window._caddieNineHolesRound!==`BACK_9`?`text-slate-600`:`text-slate-400`}">PAR 34</span>
                    </div>
                    <div class="grid grid-cols-9 gap-2">
                        ${p.map(e=>k(e)).join(``)}
                    </div>
                </div>

                <div>
                    <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Notas del Caddie Master</label>
                    <input id="score-modal-notes" type="text" placeholder="${l?`Ej. Jugó solo 9 hoyos por lluvia / tiempo`:`Ej. Tarjeta entregada en caseta`}" class="w-full px-4 py-3 bg-slate-900 border border-slate-800 rounded-xl text-xs font-bold text-white focus:outline-none focus:border-primary">
                </div>
            </div>

            <!-- Footer -->
            <div class="p-4 border-t border-slate-800 bg-slate-900 flex items-center justify-between gap-3">
                <button type="button" onclick="window.setNoScorePar('${n.id}'); window.closeCaddieModal();"
                    class="px-4 py-3 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 border border-amber-500/40 rounded-xl font-black text-xs uppercase flex items-center gap-1.5 transition-all">
                    <span class="material-icons" style="font-size:16px">block</span> No Entregó Tarjeta (Par ${g})
                </button>
                <div class="flex gap-2">
                    <button type="button" onclick="window.closeCaddieModal()" class="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-black text-xs uppercase transition-all">Cancelar</button>
                    <button type="button" onclick="window.saveCaddieScorecard('${n.id}', '${n.member_id||``}', '${n.member_name.replace(/'/g,`\\'`)}')"
                        class="px-7 py-3 ${l?`bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20`:`bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20`} rounded-xl font-black text-xs uppercase transition-all shadow-lg flex items-center gap-1.5 active:scale-95">
                        <span class="material-icons" style="font-size:16px">${l?`timer`:d?`workspace_premium`:`save`}</span>
                        ${l?`Guardar 9 Hoyos (Pendiente 6 Días)`:d?`Completar 18 Hoyos (Enviar a Handicap)`:`Guardar Scorecard`}
                    </button>
                </div>
            </div>
        </div>
    `,c.classList.remove(`hidden`),window.recalcCaddieScorecardTotals(),setTimeout(()=>{let e=1;l&&window._caddieNineHolesRound===`BACK_9`?e=10:d&&a&&(e=a.round_type===`FRONT_9`?10:1),document.getElementById(`caddie-score-h${e}`)?.focus()},100)};function k(e){let t=window._caddieHoleScores?.[`h${e.hole}`]??``,n=t!==``&&!isNaN(t)&&parseInt(t)>0,r=window._caddieScoreMode===`9_HOLES`,i=window._caddieScoreMode===`COMPLETING_18`,a=window._caddiePendingRecord,o=!1,s=!1;return r?(window._caddieNineHolesRound===`FRONT_9`&&e.hole>9&&(o=!0),window._caddieNineHolesRound===`BACK_9`&&e.hole<=9&&(o=!0)):i&&a&&(a.round_type===`FRONT_9`&&e.hole<=9&&(s=!0),a.round_type===`BACK_9`&&e.hole>9&&(s=!0)),o?`
        <div id="caddie-hole-card-${e.hole}"
            class="flex flex-col items-center justify-between p-2 rounded-2xl border border-slate-800 bg-slate-950/40 opacity-30 select-none">
            <div class="text-center">
                <p class="text-[10px] font-black text-slate-500">#${e.hole}</p>
                <p class="text-[8px] font-bold text-slate-600 uppercase">PAR ${e.par}</p>
            </div>
            <div class="w-full text-center py-2 my-1 bg-slate-900/50 border border-slate-800 rounded-xl font-black text-sm text-slate-600">
                —
            </div>
            <div class="text-[7px] font-bold uppercase text-slate-600">
                2da Fecha
            </div>
        </div>`:s?`
        <div id="caddie-hole-card-${e.hole}"
            class="flex flex-col items-center justify-between p-2 rounded-2xl border border-blue-500/40 bg-blue-950/20 shadow-sm shadow-blue-500/5">
            <div class="text-center">
                <p class="text-[10px] font-black text-blue-300">#${e.hole}</p>
                <p class="text-[8px] font-bold text-slate-400 uppercase">PAR ${e.par}</p>
            </div>
            <input id="caddie-score-h${e.hole}" type="text" readonly value="${t}"
                class="w-full text-center py-2 my-1 bg-blue-900/40 border border-blue-500/50 text-blue-200 rounded-xl font-black text-base cursor-not-allowed select-none">
            <div class="text-[7px] font-black uppercase text-blue-300 tracking-wider">
                ✓ Jugado
            </div>
        </div>`:`
    <div id="caddie-hole-card-${e.hole}"
        class="flex flex-col items-center justify-between p-2 rounded-2xl border transition-all ${n?`bg-emerald-500/20 border-emerald-500/50 shadow-md shadow-emerald-500/10`:`bg-slate-800 border-slate-700`}">
        <div class="text-center">
            <p class="text-[10px] font-black text-slate-300">#${e.hole}</p>
            <p class="text-[8px] font-bold text-slate-500 uppercase">PAR ${e.par}</p>
        </div>
        <input id="caddie-score-h${e.hole}" type="text" inputmode="numeric" pattern="[0-9]*" maxlength="2" value="${t}" placeholder="" autocomplete="off"
            oninput="window.onCaddieHoleInput(${e.hole}, this)"
            onkeydown="window.onCaddieHoleKeyDown(event, ${e.hole})"
            onfocus="this.select()"
            class="w-full text-center py-2 my-1 bg-slate-900 border ${n?`border-emerald-500/60 text-emerald-300`:`border-slate-700 text-white`} rounded-xl font-black text-base focus:outline-none focus:border-primary transition-all">
        <div class="text-[8px] font-black uppercase text-amber-400 tracking-wider">
            IDX ${e.idx}
        </div>
    </div>`}window.onCaddieHoleKeyDown=function(e,t){let n=window._caddieScoreMode===`9_HOLES`,r=window._caddieScoreMode===`COMPLETING_18`,i=window._caddiePendingRecord,a=(e,t)=>{let a=e+(t?1:-1);for(;a>=1&&a<=18;){let e=!1;if(n?(window._caddieNineHolesRound===`FRONT_9`&&a>9&&(e=!0),window._caddieNineHolesRound===`BACK_9`&&a<=9&&(e=!0)):r&&i&&(i.round_type===`FRONT_9`&&a<=9&&(e=!0),i.round_type===`BACK_9`&&a>9&&(e=!0)),!e)return a;a+=t?1:-1}return null};if(e.key===`Enter`||e.key===`ArrowRight`){e.preventDefault();let n=a(t,!0);if(n){let e=document.getElementById(`caddie-score-h${n}`);e&&(e.focus(),e.select())}}else if(e.key===`ArrowLeft`){e.preventDefault();let n=a(t,!1);if(n){let e=document.getElementById(`caddie-score-h${n}`);e&&(e.focus(),e.select())}}else if(e.key===`Backspace`&&(!e.target.value||e.target.value===``)){let e=a(t,!1);if(e){let t=document.getElementById(`caddie-score-h${e}`);t&&(t.focus(),t.select())}}},window.onCaddieHoleInput=function(e,t){let n=t.value.replace(/[^0-9]/g,``);t.value=n;let r=parseInt(n),i=document.getElementById(`caddie-hole-card-${e}`);if(!isNaN(r)&&r>0){window._caddieHoleScores[`h${e}`]=r,i&&(i.className=`flex flex-col items-center justify-between p-2 rounded-2xl border transition-all bg-emerald-500/20 border-emerald-500/50 shadow-md shadow-emerald-500/10`),t.className=`w-full text-center py-2 my-1 bg-slate-900 border border-emerald-500/60 text-emerald-300 rounded-xl font-black text-base focus:outline-none focus:border-primary transition-all`;let n=window._caddieScoreMode===`9_HOLES`,a=window._caddieScoreMode===`COMPLETING_18`,o=window._caddiePendingRecord,s=e+1;for(;s<=18;){let e=!1;if(n?(window._caddieNineHolesRound===`FRONT_9`&&s>9&&(e=!0),window._caddieNineHolesRound===`BACK_9`&&s<=9&&(e=!0)):a&&o&&(o.round_type===`FRONT_9`&&s<=9&&(e=!0),o.round_type===`BACK_9`&&s>9&&(e=!0)),!e)break;s++}s<=18&&setTimeout(()=>{let e=document.getElementById(`caddie-score-h${s}`);e&&(e.focus(),e.select())},10)}else window._caddieHoleScores[`h${e}`]=``,i&&(i.className=`flex flex-col items-center justify-between p-2 rounded-2xl border transition-all bg-slate-800 border-slate-700`),t.className=`w-full text-center py-2 my-1 bg-slate-900 border border-slate-700 text-white rounded-xl font-black text-base focus:outline-none focus:border-primary transition-all`;window.recalcCaddieScorecardTotals()},window.caddieFillPar=function(){let e=window._caddieScoreMode===`9_HOLES`,t=window._caddieScoreMode===`COMPLETING_18`,n=window._caddiePendingRecord;h.forEach(r=>{let i=!0;if(e?(window._caddieNineHolesRound===`FRONT_9`&&r.hole>9&&(i=!1),window._caddieNineHolesRound===`BACK_9`&&r.hole<=9&&(i=!1)):t&&n&&(n.round_type===`FRONT_9`&&r.hole<=9&&(i=!1),n.round_type===`BACK_9`&&r.hole>9&&(i=!1)),i){window._caddieHoleScores[`h${r.hole}`]=r.par;let e=document.getElementById(`caddie-score-h${r.hole}`),t=document.getElementById(`caddie-hole-card-${r.hole}`);e&&(e.value=r.par,e.className=`w-full text-center py-2 my-1 bg-slate-900 border border-emerald-500/60 text-emerald-300 rounded-xl font-black text-base focus:outline-none focus:border-primary transition-all`),t&&(t.className=`flex flex-col items-center justify-between p-2 rounded-2xl border transition-all bg-emerald-500/20 border-emerald-500/50 shadow-md shadow-emerald-500/10`)}}),window.recalcCaddieScorecardTotals()},window.caddieClearScores=function(){window._caddieScoreMode;let e=window._caddieScoreMode===`COMPLETING_18`,t=window._caddiePendingRecord;h.forEach(n=>{let r=!0;if(e&&t&&(t.round_type===`FRONT_9`&&n.hole<=9&&(r=!1),t.round_type===`BACK_9`&&n.hole>9&&(r=!1)),r){window._caddieHoleScores[`h${n.hole}`]=``;let e=document.getElementById(`caddie-score-h${n.hole}`),t=document.getElementById(`caddie-hole-card-${n.hole}`);e&&(e.value=``,e.className=`w-full text-center py-2 my-1 bg-slate-900 border border-slate-700 text-white rounded-xl font-black text-base focus:outline-none focus:border-primary transition-all`),t&&(t.className=`flex flex-col items-center justify-between p-2 rounded-2xl border transition-all bg-slate-800 border-slate-700`)}}),window.recalcCaddieScorecardTotals()},window.recalcCaddieScorecardTotals=function(){let e=window._caddieHoleScores||{},t=window._caddieScoreMode===`9_HOLES`,n=0;for(let t=1;t<=9;t++){let r=parseInt(e[`h${t}`]);!isNaN(r)&&r>0&&(n+=r)}let r=0;for(let t=10;t<=18;t++){let n=parseInt(e[`h${t}`]);!isNaN(n)&&n>0&&(r+=n)}let i=t?window._caddieNineHolesRound===`FRONT_9`?n:r:n+r,a=document.getElementById(`caddie-sc-in`),o=document.getElementById(`caddie-sc-out`),s=document.getElementById(`caddie-sc-gross`),c=document.getElementById(`caddie-sc-gross-label`);a&&(a.textContent=n),o&&(o.textContent=r),s&&(s.textContent=i),c&&(c.textContent=t?`GROSS 9 HOYOS`:`GROSS TOTAL`)},window.saveCaddieScorecard=async function(e,t,a){let c=window._caddieHoleScores||{},l=window._caddieScoreMode===`9_HOLES`,d=window._caddieScoreMode===`COMPLETING_18`,p=window._caddiePendingRecord,h=s.find(t=>String(t.id)===String(e)),g=t&&t!==`null`&&t!==`undefined`&&t!==``?t:h?h.member_id:null,y=a||(h?h.member_name:`Jugador`),b=o.find(e=>String(e.id)===String(g)),S=h?.member_number||(b?b.member_number:`INV`),C=document.getElementById(`score-modal-notes`)?.value.trim()||``;if(l){let e=window._caddieNineHolesRound||`FRONT_9`,t=e===`FRONT_9`?1:10,a=e===`FRONT_9`?9:18,o=0,s=0;for(let e=t;e<=a;e++){let t=parseInt(c[`h${e}`]);!isNaN(t)&&t>0&&(o+=t,s++)}if(o===0||s===0){window.showNotification?.(`Ingresa Scores`,`Por favor ingresa los golpes de la vuelta de 9 hoyos.`,`error`);return}let l=m||i(),[d,p,_]=l.split(`-`).map(Number),v=new Date(d,p-1,_+6),b=`${v.getFullYear()}-${String(v.getMonth()+1).padStart(2,`0`)}-${String(v.getDate()).padStart(2,`0`)}`,w={member_id:g,member_number:S,member_name:y,player_type:g?`MEMBER`:`GUEST`,tee_time_id:h?.tee_time_id||null,folio:h?.folio||null,round_type:e,starting_hole:t,played_date:l,expires_at:b,status:`PENDING`,hole_scores:c,partial_gross:o,caddie_name:h?.caddie_name||``,notes:C||`Media ronda 9 hoyos (${e===`FRONT_9`?`1-9 Blancas`:`10-18 Azules`})`};try{let{data:e,error:t}=await n.from(`pending_nine_holes`).insert([w]).select().single();!t&&e?u.unshift(e):(w.id=`p9_`+Date.now(),u.unshift(w))}catch{w.id=`p9_`+Date.now(),u.unshift(w)}try{localStorage.setItem(`cgc_pending_nine_holes`,JSON.stringify(u)),localStorage.setItem(`cgc_pending_nine_holes_sync`,String(Date.now()))}catch{}let T=`PARTIAL_9`;if(h&&h.id&&!String(h.id).startsWith(`tmp_`)){try{await n.from(`daily_outputs`).update({score_status:T,gross_score:o,hole_scores:c}).eq(`id`,h.id)}catch{try{await r.from(`daily_outputs`).update({score_status:T,gross_score:o,hole_scores:c}).eq(`id`,h.id)}catch{}}h.score_status=T,h.gross_score=o,h.hole_scores=c}window.showNotification?.(`¡9 Hoyos Registrados!`,`Tarjeta de 9 hoyos (${o} golpes) guardada para ${y}. Tiene 6 días para completar los 18 hoyos.`,`success`),window.closeCaddieModal(),await x(),f===`ONCOURSE`&&window.renderOnCoursePlayersList();return}let w=0;for(let e=1;e<=18;e++){let t=parseInt(c[`h${e}`]);!isNaN(t)&&t>0&&(w+=t)}if(w===0){window.showNotification?.(`Ingresa Scores`,`Por favor ingresa los golpes de los hoyos.`,`error`);return}if(String(e).startsWith(`tmp_`)||!h||!h.id||String(h.id).startsWith(`tmp_`)){let t={tee_time_id:h?h.tee_time_id:null,folio:h?h.folio:null,member_id:g,member_name:y,player_type:g?`MEMBER`:`GUEST`,starting_hole:h&&h.starting_hole||1,caddie_name:h&&h.caddie_name||``,cart_number:h&&h.cart_number||``,score_status:`CAPTURED`,gross_score:w,hole_scores:c};try{let{data:r}=await n.from(`daily_outputs`).insert([t]).select().single();r&&r.id&&(e=r.id)}catch{try{let{data:n}=await r.from(`daily_outputs`).insert([t]).select().single();n&&n.id&&(e=n.id)}catch{}}}else try{await n.from(`daily_outputs`).update({score_status:`CAPTURED`,gross_score:w,hole_scores:c}).eq(`id`,e)}catch{try{await r.from(`daily_outputs`).update({score_status:`CAPTURED`,gross_score:w,hole_scores:c}).eq(`id`,e)}catch{}}if(h&&(h.score_status=`CAPTURED`,h.gross_score=w,h.hole_scores=c),p||d){let e=p?.id;if(e){try{await n.from(`pending_nine_holes`).update({status:`COMPLETED`,completed_at:new Date().toISOString(),completed_by:`Caddie Master`}).eq(`id`,e)}catch{}let t=u.findIndex(t=>String(t.id)===String(e));t>=0&&(u[t].status=`COMPLETED`);try{localStorage.setItem(`cgc_pending_nine_holes`,JSON.stringify(u)),localStorage.setItem(`cgc_pending_nine_holes_sync`,String(Date.now()))}catch{}}}if(g){let t=parseFloat((113/v*(w-_)).toFixed(1)),a={member_id:g,output_id:e&&!String(e).startsWith(`tmp_`)?e:null,date_played:m||i(),gross_score:w,course_rating:_,slope_rating:v,differential:t,hole_scores:c,delivered:!0,notes:C||(d?`Scorecard 18 Hoyos Consolidado (2 vueltas de 9 hoyos combinadas)`:`Scorecard 18 Hoyos Caddie Master`)};try{await n.from(`member_scores`).insert([a])}catch{try{await r.from(`member_scores`).insert([a])}catch{}}await A(g)}window._completingPendingRecord=null,window._caddiePendingRecord=null,window._caddieScoreMode=`18_HOLES`;let T=d?`¡Tarjeta de 18 hoyos consolidada y completada (Gross: ${w})! Se envió al cálculo de Handicap Index.`:`Scorecard de 18 hoyos (Gross: ${w}) guardado para ${y}.`;window.showNotification?.(`¡Scorecard Guardado!`,T,`success`),window.closeCaddieModal(),await x(),f===`ONCOURSE`&&window.renderOnCoursePlayersList()};async function A(e){try{let t=[];try{let{data:r}=await n.from(`member_scores`).select(`*`).eq(`member_id`,e).order(`date_played`,{ascending:!1}).limit(20);t=r||[]}catch{let{data:n}=await r.from(`member_scores`).select(`*`).eq(`member_id`,e).order(`date_played`,{ascending:!1}).limit(20);t=n||[]}if(!t||t.length===0)return;let i=t.map(e=>parseFloat(e.differential)||0).sort((e,t)=>e-t),a=i.length,o=1;o=a>=20?8:a>=19?7:a>=17?6:a>=15?5:a>=12?4:a>=9?3:a>=6?2:1;let s=i.slice(0,o).reduce((e,t)=>e+t,0)/o,c=parseFloat(s.toFixed(1));await n.from(`members`).update({current_handicap:c}).eq(`id`,e)}catch(e){console.error(`Error recalculating handicap:`,e)}}function j(){let e=document.getElementById(`caddie-practica-container`),t=document.getElementById(`caddie-practica-summary`);if(e){if(t){let e=0;l.forEach(t=>{e+=parseInt(t.buckets_count||0)}),t.textContent=`${l.length} Registro(s) · ${e} Cubetas (${e*100} Pelotas)`}if(!l||l.length===0){e.innerHTML=`
            <div class="py-12 text-center bg-slate-950/40 border border-slate-800/80 rounded-3xl p-8">
                <div class="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 mx-auto mb-3">
                    <span class="material-icons text-3xl">sports_baseball</span>
                </div>
                <h4 class="text-white font-black text-sm uppercase">Sin Registros de Práctica Hoy</h4>
                <p class="text-xs text-slate-400 font-bold mt-1">Los cobros de cubetas y tee de práctica registrados en Recepción aparecerán aquí para entrega.</p>
            </div>
        `;return}e.innerHTML=`
        <div class="space-y-3">
            ${l.map(e=>{let t=!!e.balls_delivered,n=e.created_at?new Date(e.created_at).toLocaleTimeString(`es-MX`,{hour:`2-digit`,minute:`2-digit`}):`--:--`,r=e.delivered_at?new Date(e.delivered_at).toLocaleTimeString(`es-MX`,{hour:`2-digit`,minute:`2-digit`}):``;return`
                    <div class="p-4 bg-slate-950/60 border ${t?`border-slate-800`:`border-purple-500/40 shadow-lg shadow-purple-950/20`} rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all">
                        <div class="flex items-start gap-3">
                            <div class="w-12 h-12 rounded-2xl ${t?`bg-slate-800 text-slate-400`:`bg-purple-500/20 text-purple-400 border border-purple-500/30`} flex items-center justify-center shrink-0">
                                <span class="material-icons text-2xl">${t?`check_circle`:`sports_baseball`}</span>
                            </div>
                            <div class="space-y-1">
                                <div class="flex items-center gap-2 flex-wrap">
                                    <span class="text-xs font-mono font-black text-slate-400">#${e.folio||`—`}</span>
                                    <span class="text-sm font-black text-white uppercase">${a(e.customer_name)}</span>
                                    <span class="px-2 py-0.5 ${e.is_member?`bg-emerald-500/20 text-emerald-300 border-emerald-500/30`:`bg-slate-800 text-slate-300 border-slate-700`} border rounded-md text-[9px] font-black uppercase">
                                        ${e.is_member?`Socio`:`Visitante`}
                                    </span>
                                    <span class="text-[10px] text-slate-500 font-bold">Hora: ${n} hrs</span>
                                </div>
                                <div class="flex items-center gap-3 text-xs text-slate-400 font-bold flex-wrap">
                                    <span class="flex items-center gap-1 text-teal-400 font-black">
                                        <span class="material-icons text-sm">inventory_2</span>
                                        ${e.buckets_count} Cubeta${e.buckets_count>1?`s`:``} (${e.buckets_count*100} Pelotas)
                                    </span>
                                    ${e.has_tee_practice?`
                                        <span class="flex items-center gap-1 text-purple-300">
                                            <span class="material-icons text-sm">golf_course</span> Incluye Renta de Tee
                                        </span>
                                    `:``}
                                    ${e.has_club_rental?`
                                        <span class="flex items-center gap-1 text-amber-300">
                                            <span class="material-icons text-sm">sports_golf</span> Renta de Equipo (Palos)
                                        </span>
                                    `:``}
                                    <span class="text-slate-400">
                                        Total: <strong>$${Number(e.total_amount||0).toLocaleString(`es-MX`,{minimumFractionDigits:2})}</strong> (${e.payment_method})
                                    </span>
                                    ${e.authorized_by?`
                                        <span class="text-amber-400 italic">Autorizó: ${a(e.authorized_by)}</span>
                                    `:``}
                                </div>
                                ${e.notes?`<p class="text-[11px] text-slate-500 italic">Nota: ${a(e.notes)}</p>`:``}
                            </div>
                        </div>

                        <div class="flex items-center gap-3 self-end md:self-center shrink-0">
                            ${t?`
                                <div class="text-right">
                                    <span class="inline-flex items-center gap-1 px-3 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-xl text-xs font-black uppercase">
                                        <span class="material-icons text-sm">done_all</span> ${e.has_club_rental?`Pelotas y Equipo Entregados`:`Pelotas Entregadas`}
                                    </span>
                                    <p class="text-[10px] text-slate-500 font-bold mt-0.5">${r?`A las ${r} hrs`:``} (${e.delivered_by||`Caddie Master`})</p>
                                </div>
                            `:`
                                <button type="button" onclick="window.deliverDrivingRangeBalls('${e.id}')"
                                    class="px-5 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all">
                                    <span class="material-icons text-base">check_circle</span> Entregar ${e.buckets_count} Cubeta${e.buckets_count>1?`s`:``}${e.has_club_rental?` + Equipo`:``}
                                </button>
                            `}
                        </div>
                    </div>
                `}).join(``)}
        </div>
    `}}window.deliverDrivingRangeBalls=async function(e){let t=l.find(t=>String(t.id)===String(e));if(t||=l.find(t=>t.id===e||t.folio===e),t){t.balls_delivered=!0,t.delivered_at=new Date().toISOString(),t.delivered_by=`Caddie Master`;try{await n.from(`driving_range_sessions`).update({balls_delivered:!0,delivered_at:t.delivered_at,delivered_by:`Caddie Master`}).eq(`id`,t.id)}catch(e){console.warn(`Supabase update driving_range_sessions error:`,e)}try{let e=`cgc_driving_range_${m}`;localStorage.setItem(e,JSON.stringify(l)),localStorage.setItem(`cgc_driving_range_sync`,String(Date.now()))}catch{}S(),j(),window.showNotification?.(`Pelotas Entregadas`,`Se confirmó la entrega de ${t.buckets_count} cubeta(s) a ${t.customer_name}.`,`success`)}},window.openPendingNineHolesModal=function(){let e=document.getElementById(`modal-member-crud`);if(e||(e=document.createElement(`div`),e.id=`modal-member-crud`,document.body.appendChild(e)),e.className=`fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in`,e.style.display=`flex`,e.classList.remove(`hidden`),e.onclick=t=>{t.target===e&&window.closeCaddieModal()},!u||u.length===0)try{let e=localStorage.getItem(`cgc_pending_nine_holes`);if(e){let t=JSON.parse(e);Array.isArray(t)&&(u=t)}}catch{}let t=i(),n=(u||[]).filter(e=>e.status===`PENDING`&&(!e.expires_at||e.expires_at>=t)),r=e=>!e||e.length===0?`
                <div class="py-16 text-center bg-slate-950/50 border border-slate-800 rounded-3xl p-8 space-y-3">
                    <div class="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 mx-auto mb-2">
                        <span class="material-icons text-3xl">done_all</span>
                    </div>
                    <h4 class="text-white font-black text-sm uppercase">Sin Scores Pendientes</h4>
                    <p class="text-xs text-slate-400 font-bold max-w-md mx-auto">
                        No hay tarjetas de 9 hoyos esperando ser completadas. Cuando un jugador entregue solo media ronda, aparecerá aquí por 6 días.
                    </p>
                </div>
            `:`
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                ${e.map(e=>{let n=e.played_date||`Hoy`,r=6;if(e.played_date)try{let[n,i,a]=e.played_date.split(`-`).map(Number),[o,s,c]=t.split(`-`).map(Number),l=new Date(n,i-1,a),u=new Date(o,s-1,c),d=Math.round((u-l)/864e5);r=Math.max(0,Math.min(6,6-d))}catch{}else if(e.expires_at)try{let[n,i,a]=e.expires_at.split(`-`).map(Number),[o,s,c]=t.split(`-`).map(Number),l=new Date(n,i-1,a),u=new Date(o,s-1,c),d=Math.round((l-u)/864e5);r=Math.max(0,Math.min(6,d))}catch{}let i=e.round_type===`FRONT_9`,o=i?`1ra Vuelta (Hoyos 1 al 9)`:`2da Vuelta (Hoyos 10 al 18)`,s=i?`Marcas Blancas`:`Marcas Azules`,c=i?`2da Vuelta (Hoyos 10 al 18 · Azules)`:`1ra Vuelta (Hoyos 1 al 9 · Blancas)`,l=i?10:1,u=`bg-emerald-500/20 text-emerald-300 border-emerald-500/40`;r<=1?u=`bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse`:r<=3&&(u=`bg-amber-500/20 text-amber-300 border-amber-500/40`);let d=r===0?`¡Vence hoy!`:`Quedan ${r} día${r===1?``:`s`}`;return`
                        <div class="p-5 bg-slate-900 border border-slate-800 hover:border-amber-500/40 rounded-3xl space-y-4 shadow-xl transition-all flex flex-col justify-between">
                            <div class="space-y-3">
                                <div class="flex items-start justify-between gap-2">
                                    <div class="space-y-0.5">
                                        <div class="flex items-center gap-2 flex-wrap">
                                            <h4 class="font-black text-white text-base uppercase">${a(e.member_name)}</h4>
                                            <span class="px-2 py-0.5 bg-slate-800 text-slate-300 border border-slate-700 rounded-md text-[10px] font-black">
                                                #${e.member_number||`SOC`}
                                            </span>
                                        </div>
                                        <p class="text-[11px] text-slate-400 font-bold">Jugó el <strong>${n}</strong></p>
                                    </div>

                                    <span class="px-2.5 py-1 ${u} border rounded-xl text-[10px] font-black uppercase shrink-0 flex items-center gap-1">
                                        <span class="material-icons text-xs">${r===0?`warning`:`schedule`}</span> ${d}
                                    </span>
                                </div>

                                <div class="p-3 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-2">
                                    <div class="flex items-center justify-between text-xs">
                                        <span class="text-slate-400 font-bold flex items-center gap-1.5">
                                            <span class="w-2.5 h-2.5 rounded-full ${i?`bg-slate-200`:`bg-blue-500`}"></span>
                                            ${o} (${s})
                                        </span>
                                        <span class="px-2.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-lg font-black text-xs">
                                            ${e.partial_gross} golpes
                                        </span>
                                    </div>
                                    <div class="text-[11px] text-emerald-400 font-black flex items-center gap-1">
                                        <span class="material-icons text-sm">arrow_forward</span> Le falta: ${c} (Hoyo #${l})
                                    </div>
                                </div>

                                ${e.notes?`<p class="text-[11px] text-slate-500 italic">Nota: ${a(e.notes)}</p>`:``}
                            </div>

                            <div class="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                                <button type="button" onclick="window.cancelPendingNineHoles('${e.id}')"
                                    class="px-3.5 py-2.5 bg-slate-800/80 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 border border-slate-700/80 hover:border-rose-500/40 rounded-xl text-[10px] font-black uppercase transition-all"
                                    title="Descartar esta tarjeta sin penalizar">
                                    Descartar
                                </button>
                                <button type="button" onclick="window.startCompletingPendingScore('${e.id}')"
                                    class="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-lg shadow-emerald-500/20 flex items-center gap-1.5 active:scale-95">
                                    <span class="material-icons text-sm">sports_golf</span> Completar 18 Hoyos
                                </button>
                            </div>
                        </div>
                    `}).join(``)}
            </div>
        `;e.innerHTML=`
        <div class="w-full max-w-4xl bg-slate-950/95 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]" onclick="event.stopPropagation()">
            <!-- Header -->
            <div class="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/80">
                <div class="flex items-center gap-3.5">
                    <div class="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                        <span class="material-icons text-2xl">timer</span>
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <h3 class="font-black uppercase text-white text-lg leading-none">Scores Pendientes de 9 Hoyos</h3>
                            <span class="px-2.5 py-0.5 bg-amber-500 text-slate-950 rounded-lg text-xs font-black">
                                ${n.length}
                            </span>
                        </div>
                        <p class="text-xs text-slate-400 font-bold uppercase mt-1">Vigencia de 6 días naturales antes de ser descartados sin penalizar</p>
                    </div>
                </div>

                <button type="button" onclick="window.closeCaddieModal()" class="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all" title="Cerrar">
                    <span class="material-icons" style="font-size:18px">close</span>
                </button>
            </div>

            <!-- Filter -->
            <div class="p-4 border-b border-slate-800/80 bg-slate-900/40 flex items-center gap-3">
                <div class="relative flex-1">
                    <span class="material-icons absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm">search</span>
                    <input id="pending-9h-filter" type="text" placeholder="Buscar socio por nombre o número..."
                        oninput="window.filterPendingNineHolesList(this.value)"
                        class="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs font-bold text-white placeholder:text-slate-500 focus:outline-none focus:border-primary">
                </div>
            </div>

            <!-- Content List -->
            <div id="pending-9h-cards-container" class="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-4">
                ${r(n)}
            </div>

            <!-- Footer -->
            <div class="p-4 border-t border-slate-800 bg-slate-900 flex justify-end">
                <button type="button" onclick="window.closeCaddieModal()" class="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-black text-xs uppercase transition-all">
                    Cerrar
                </button>
            </div>
        </div>
    `,window.filterPendingNineHolesList=function(e){let t=document.getElementById(`pending-9h-cards-container`);if(!t)return;let i=(e||``).trim().toLowerCase(),a=n.filter(e=>!i||(e.member_name||``).toLowerCase().includes(i)||(e.member_number||``).toLowerCase().includes(i));t.innerHTML=r(a)}},window.startCompletingPendingScore=function(e){let t=(u||[]).find(t=>String(t.id)===String(e));if(!t)return;window.closeCaddieModal();let n=s.find(e=>t.member_id&&String(e.member_id)===String(t.member_id)||(e.member_name||``).trim().toLowerCase()===(t.member_name||``).trim().toLowerCase());n||(n={id:`tmp_comp_`+Date.now(),member_id:t.member_id,member_number:t.member_number,member_name:t.member_name,player_type:t.player_type||`MEMBER`,starting_hole:t.round_type===`FRONT_9`?10:1,score_status:`PENDING`,hole_scores:{}},s.unshift(n)),window._completingPendingRecord=t,window._caddiePendingRecord=t,window._caddieScoreMode=`COMPLETING_18`,setTimeout(()=>{window.openScoreCaptureModal(n.id,n)},150)},window.cancelPendingNineHoles=function(e){let t=(u||[]).find(t=>String(t.id)===String(e));t&&window.showNotification?.(`Descartar Tarjeta de 9 Hoyos`,`¿Deseas cancelar y descartar la tarjeta incompleta de ${t.member_name}? Esta tarjeta no penalizará ni afectará su hándicap.`,`confirm`,async()=>{t.status=`CANCELLED`;try{await n.from(`pending_nine_holes`).update({status:`CANCELLED`}).eq(`id`,t.id)}catch{}try{localStorage.setItem(`cgc_pending_nine_holes`,JSON.stringify(u)),localStorage.setItem(`cgc_pending_nine_holes_sync`,String(Date.now()))}catch{}S(),window.openPendingNineHolesModal(),window.showNotification?.(`Tarjeta Descartada`,`La tarjeta de 9 hoyos de ${t.member_name} ha sido descartada sin penalización.`,`success`)})};export{y as renderCaddieMasterModule};