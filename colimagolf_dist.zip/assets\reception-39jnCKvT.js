import{t as e}from"./dist-BN2bhVnw.js";function t(){try{let e=sessionStorage.getItem(`cgc_user_data`);if(e){let t=JSON.parse(e);return t.role===`admin`||t.username===`colimagc`}let t=sessionStorage.getItem(`cgc_auth`);return t===`admin`||t===`1`}catch{return!1}}var n=e(`https://tztolxgsaktqindoimtu.supabase.co`,`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR6dG9seGdzYWt0cWluZG9pbXR1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYyNzQ4ODAsImV4cCI6MjEwMTg1MDg4MH0.E2GABiOMXYb5hEwE9ErIcJa6_LHkj9lJUglQVoiLl0M`).schema(`colimaGC`),r=`07:00.07:20.07:40.08:00.08:20.08:40.09:00.09:20.09:40.10:00.10:20.10:40.11:00.11:20.11:40.12:00.12:20.12:40.13:00.13:20.13:40.14:00.14:20.14:40.15:00.15:20.15:40.16:00.16:20.16:40.17:00`.split(`.`),i={greenFee18Guest:1200,greenFee9Guest:1200,greenFee18Member:0,greenFee9Member:0,cart18:500,cart9:500,clubRentalFee:400,practiceTeeFee:150,bucket100Fee:120},a=[{id:`manzanillo`,name:`Manzanillo Golf`,green_fee_18:800,green_fee_9:800,cart_fee_18:500,cart_fee_9:500,is_active:!0}],o={...i};try{let e=localStorage.getItem(`cgc_reception_prices`);e&&(o={...i,...JSON.parse(e)},o.clubRentalFee||(o.clubRentalFee=400),o.greenFee9Guest=o.greenFee18Guest,o.cart9=o.cart18)}catch(e){console.warn(`Error reading price config:`,e)}var s=[...a];try{let e=localStorage.getItem(`cgc_convenios`);e&&(s=JSON.parse(e))}catch(e){console.warn(`Error reading convenios config:`,e)}function c(e=new Date){return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}var l=c(),u=`SLOTS`,d=[],f=[],p=null,m=[];async function h(e){g(e),await _()}function g(e){let n=F(l);e.innerHTML=`
        <div class="space-y-6">
            <!-- Header Banner -->
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl">
                <div class="flex items-center gap-4">
                    <div class="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/30 flex items-center justify-center text-primary shrink-0 shadow-lg shadow-primary/10">
                        <span class="material-icons" style="font-size:32px">point_of_sale</span>
                    </div>
                    <div>
                        <div class="flex items-center gap-2.5">
                            <h2 class="text-2xl font-black text-white uppercase tracking-tight">Recepción & Tee Times</h2>
                            <span class="px-2.5 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-lg text-[10px] font-black uppercase">Casa Club</span>
                        </div>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Control de Reservas, Cobro de Green Fees & Pase Express a Caddie Master</p>
                    </div>
                </div>

                <!-- Date Navigation Bar -->
                <div class="flex flex-wrap items-center gap-2 bg-slate-950/80 border border-slate-800 p-2 rounded-2xl shrink-0">
                    <button id="btn-date-prev" class="w-9 h-9 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl flex items-center justify-center transition-all" title="Día Anterior">
                        <span class="material-icons text-base">chevron_left</span>
                    </button>

                    <div class="flex items-center gap-2 px-3 py-1 bg-slate-900 border border-slate-700/80 rounded-xl">
                        <span class="material-icons text-primary text-base">calendar_today</span>
                        <input id="reception-date-input" type="date" value="${l}" style="color-scheme: dark;"
                            class="bg-transparent text-white font-black text-xs uppercase focus:outline-none cursor-pointer">
                    </div>

                    <button id="btn-date-next" class="w-9 h-9 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl flex items-center justify-center transition-all" title="Día Siguiente">
                        <span class="material-icons text-base">chevron_right</span>
                    </button>

                    <button id="btn-date-today" class="px-3 py-2 bg-primary/20 hover:bg-primary/30 border border-primary/40 text-primary rounded-xl font-black text-xs uppercase tracking-wider transition-all">
                        Hoy
                    </button>
                </div>
            </div>

            <!-- Summary KPI Cards -->
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                    <div>
                        <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest">Tee Times Agendados</p>
                        <h4 id="kpi-slots-count" class="text-2xl font-black text-white mt-1">0</h4>
                        <p class="text-[10px] font-bold text-slate-400 mt-0.5">Slots ocupados</p>
                    </div>
                    <div class="w-11 h-11 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
                        <span class="material-icons">schedule</span>
                    </div>
                </div>

                <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                    <div>
                        <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest">Total Jugadores</p>
                        <h4 id="kpi-players-count" class="text-2xl font-black text-emerald-400 mt-1">0</h4>
                        <p class="text-[10px] font-bold text-slate-400 mt-0.5">Socios + Invitados</p>
                    </div>
                    <div class="w-11 h-11 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                        <span class="material-icons">groups</span>
                    </div>
                </div>

                <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                    <div>
                        <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest">Ingresos del Día</p>
                        <h4 id="kpi-revenue-total" class="text-2xl font-black text-primary mt-1">$0</h4>
                        <p class="text-[10px] font-bold text-slate-400 mt-0.5">Green Fees + Carros</p>
                    </div>
                    <div class="w-11 h-11 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                        <span class="material-icons">payments</span>
                    </div>
                </div>

                <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
                    <div>
                        <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest">Carritos Rentados</p>
                        <h4 id="kpi-carts-count" class="text-2xl font-black text-amber-400 mt-1">0</h4>
                        <p class="text-[10px] font-bold text-slate-400 mt-0.5">Carros en campo</p>
                    </div>
                    <div class="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                        <span class="material-icons">electric_car</span>
                    </div>
                </div>
            </div>

            <!-- Navigation Sub-tabs -->
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-2">
                <div class="flex items-center gap-2 flex-wrap">
                    <button id="tab-reception-slots" class="px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-primary text-slate-950 shadow-lg shadow-primary/20">
                        <span class="material-icons" style="font-size:18px">grid_view</span> Parrilla de Salidas & Cobro
                    </button>
                    <button id="tab-reception-reservas" class="px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white">
                        <span class="material-icons" style="font-size:18px">event_note</span> Reservas
                        <span id="tab-reservas-badge" class="px-2 py-0.5 bg-slate-800 text-amber-400 rounded-lg text-[10px] font-black border border-slate-700">0</span>
                    </button>
                    <button id="tab-reception-corte" class="px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white">
                        <span class="material-icons" style="font-size:18px">receipt_long</span> Corte de Caja & Recibos
                    </button>
                </div>

                <div class="flex items-center gap-2 flex-wrap">
                    <button onclick="window.openDrivingRangeModal()" class="px-4 py-2.5 rounded-xl font-black text-[11px] uppercase tracking-wider transition-all flex items-center gap-1.5 bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-600/20 active:scale-95">
                        <span class="material-icons text-sm">sports_golf</span> 🏌️ Cobro Práctica / Pelotas
                    </button>
                    ${t()?`<button onclick="window.openReceptionPriceConfigModal()" class="px-4 py-2.5 rounded-xl font-black text-[11px] uppercase tracking-wider transition-all flex items-center gap-1.5 bg-slate-900 text-slate-300 border border-slate-800 hover:text-white hover:border-slate-700">
                            <span class="material-icons text-sm text-amber-400">tune</span> Configurar Tarifas
                        </button>`:`<button disabled title="Solo el Administrador puede modificar tarifas" class="px-4 py-2.5 rounded-xl font-black text-[11px] uppercase tracking-wider flex items-center gap-1.5 bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed opacity-50">
                            <span class="material-icons text-sm text-slate-600">lock</span> Configurar Tarifas
                        </button>`}
                    <button onclick="window.startNewBookingFromScratch()" class="px-5 py-2.5 rounded-xl font-black text-[11px] uppercase tracking-wider transition-all flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20">
                        <span class="material-icons text-sm">add_circle</span> + Nueva Salida / Cobro
                    </button>
                </div>
            </div>

            <!-- Tab 1: Slots Grid + Point of Sale Terminal -->
            <div id="reception-view-slots" class="space-y-6">
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    
                    <!-- Left: 20-min Slot Agenda Grid (col-span-5) -->
                    <div class="lg:col-span-5 space-y-4">
                        <div class="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
                            <div class="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-3 gap-2">
                                <div>
                                    <h3 class="font-black text-white uppercase text-xs tracking-wider flex items-center gap-2">
                                        <span class="material-icons text-primary text-base">alarm</span> Salidas cada 20 Minutos
                                    </h3>
                                    <div class="flex items-center gap-1.5 mt-1">
                                        <span class="material-icons text-xs text-primary">event</span>
                                        <span id="reception-slots-date-label" class="text-xs font-black text-emerald-400 uppercase">${n}</span>
                                    </div>
                                </div>
                                <div class="flex items-center gap-1 bg-slate-950 px-2.5 py-1.5 rounded-xl border border-slate-800 shrink-0">
                                    <button type="button" onclick="window.stepReceptionDate(-1)" class="w-6 h-6 flex items-center justify-center hover:bg-slate-800 rounded text-slate-400 hover:text-white" title="Día Anterior">
                                        <span class="material-icons text-sm">chevron_left</span>
                                    </button>
                                    <input type="date" id="reception-slots-quick-date" value="${l}" onchange="window.setReceptionDate(this.value)" style="color-scheme: dark;"
                                        class="bg-transparent text-white font-black text-[11px] uppercase focus:outline-none cursor-pointer">
                                    <button type="button" onclick="window.stepReceptionDate(1)" class="w-6 h-6 flex items-center justify-center hover:bg-slate-800 rounded text-slate-400 hover:text-white" title="Día Siguiente">
                                        <span class="material-icons text-sm">chevron_right</span>
                                    </button>
                                </div>
                            </div>

                            <!-- Mini Metrics Quick Strip -->
                            <div class="grid grid-cols-4 gap-2 bg-slate-950/90 border border-slate-800/80 p-2 rounded-2xl text-center">
                                <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-1.5">
                                    <p class="text-[8px] font-black text-slate-400 uppercase">Tee Times</p>
                                    <p id="mini-kpi-slots" class="text-sm font-black text-white leading-tight mt-0.5">0</p>
                                </div>
                                <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-1.5">
                                    <p class="text-[8px] font-black text-slate-400 uppercase">Jugadores</p>
                                    <p id="mini-kpi-players" class="text-sm font-black text-emerald-400 leading-tight mt-0.5">0</p>
                                </div>
                                <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-1.5">
                                    <p class="text-[8px] font-black text-slate-400 uppercase">Carritos</p>
                                    <p id="mini-kpi-carts" class="text-sm font-black text-amber-400 leading-tight mt-0.5">0</p>
                                </div>
                                <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-1.5">
                                    <p class="text-[8px] font-black text-slate-400 uppercase">Total Hoy</p>
                                    <p id="mini-kpi-revenue" class="text-xs font-black text-primary leading-tight mt-1">$0</p>
                                </div>
                            </div>

                            <!-- Legend -->
                            <div class="flex flex-wrap items-center gap-3 text-[10px] font-bold uppercase pb-1">
                                <span class="flex items-center gap-1 text-slate-400"><span class="w-2.5 h-2.5 rounded-full bg-slate-700"></span> Libre</span>
                                <span class="flex items-center gap-1 text-amber-400"><span class="w-2.5 h-2.5 rounded-full bg-amber-400"></span> Reserva Tel.</span>
                                <span class="flex items-center gap-1 text-blue-400"><span class="w-2.5 h-2.5 rounded-full bg-blue-400"></span> Pagado / En Tee</span>
                                <span class="flex items-center gap-1 text-emerald-400"><span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> En Campo</span>
                            </div>

                            <!-- Slots Scrollable List -->
                            <div id="reception-slots-container" class="space-y-2.5 max-h-[620px] overflow-y-auto custom-scrollbar pr-1">
                                <div class="py-12 text-center">
                                    <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right: Point of Sale Terminal & Foursome Register (col-span-7) -->
                    <div class="lg:col-span-7 space-y-4">
                        <div id="reception-pos-card" class="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl space-y-6">
                            <!-- POS Header & Form will be dynamically injected here -->
                        </div>
                    </div>

                </div>
            </div>

            <!-- Tab 2: Corte de Caja & Historial de Recibos -->
            <div id="reception-view-corte" class="hidden space-y-6">
                <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
                        <div>
                            <h3 class="font-black text-white uppercase text-lg tracking-tight flex items-center gap-2">
                                <span class="material-icons text-primary">receipt_long</span> Corte de Caja & Recibos Emitidos
                            </h3>
                            <p class="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                                Fecha: <span id="reception-corte-date-label" class="text-emerald-400 font-black">${n}</span>
                            </p>
                        </div>
                        <div class="flex items-center gap-3">
                            <button onclick="window.printDailyCorte()" class="px-5 py-3 bg-primary/20 hover:bg-primary/30 border border-primary/40 text-primary rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2">
                                <span class="material-icons text-base">print</span> Imprimir Corte de Turno
                            </button>
                        </div>
                    </div>

                    <!-- Financial Summary Breakdown -->
                    <div id="corte-financial-summary" class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <!-- Populated dynamically -->
                    </div>

                    <!-- Transactions Table -->
                    <div id="corte-table-container">
                        <!-- Populated dynamically -->
                    </div>
                </div>
            </div>

            <!-- Tab 3: Reservas Agrupadas por Fecha -->
            <div id="reception-view-reservas" class="hidden space-y-5">
                <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-5">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
                        <div>
                            <h3 class="font-black text-white uppercase text-lg tracking-tight flex items-center gap-2">
                                <span class="material-icons text-amber-400">event_note</span> Reservas Pendientes & Confirmadas
                            </h3>
                            <p class="text-xs text-slate-400 font-bold uppercase tracking-widest mt-0.5">
                                Grupos agrupados por fecha y horario de salida
                            </p>
                        </div>
                        <button onclick="window.refreshReservasView()" class="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all border border-slate-700">
                            <span class="material-icons text-sm text-primary">refresh</span> Actualizar
                        </button>
                    </div>
                    <div id="reservas-list-container" class="space-y-4">
                        <div class="py-12 text-center">
                            <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;let r=document.getElementById(`tab-reception-slots`),i=document.getElementById(`tab-reception-corte`),a=document.getElementById(`tab-reception-reservas`),o=document.getElementById(`reception-view-slots`),s=document.getElementById(`reception-view-corte`),d=document.getElementById(`reception-view-reservas`),f=`px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-primary text-slate-950 shadow-lg shadow-primary/20`,p=`px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white`;r.onclick=()=>{u=`SLOTS`,r.className=f,i.className=p,a.className=`px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white gap-2`,o.classList.remove(`hidden`),s.classList.add(`hidden`),d.classList.add(`hidden`)},i.onclick=()=>{u=`CORTE`,i.className=f,r.className=p,a.className=`px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white gap-2`,s.classList.remove(`hidden`),o.classList.add(`hidden`),d.classList.add(`hidden`),k()},a.onclick=()=>{u=`RESERVAS`,a.className=`px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-primary text-slate-950 shadow-lg shadow-primary/20 gap-2`,r.className=p,i.className=p,d.classList.remove(`hidden`),o.classList.add(`hidden`),s.classList.add(`hidden`),H()},document.getElementById(`reception-date-input`).onchange=e=>{l=e.target.value,b()},document.getElementById(`btn-date-today`).onclick=()=>{l=c(),document.getElementById(`reception-date-input`).value=l,b()},document.getElementById(`btn-date-prev`).onclick=()=>{let e=new Date(l+`T00:00:00`);e.setDate(e.getDate()-1),l=c(e),document.getElementById(`reception-date-input`).value=l,b()},document.getElementById(`btn-date-next`).onclick=()=>{let e=new Date(l+`T00:00:00`);e.setDate(e.getDate()+1),l=c(e),document.getElementById(`reception-date-input`).value=l,b()}}async function _(){await Promise.all([v(),y()]),await b()}async function v(){try{let{data:e}=await n.from(`members`).select(`*`).order(`member_number`,{ascending:!0});d=e||[]}catch(e){console.warn(`Error loading members in reception:`,e),d=[]}}async function y(){try{let{data:e,error:t}=await n.from(`convenios`).select(`*`).order(`name`,{ascending:!0});!t&&e&&e.length>0&&(s=e,localStorage.setItem(`cgc_convenios`,JSON.stringify(e)))}catch(e){console.warn(`Error loading convenios from Supabase:`,e)}}async function b(){try{let{data:e,error:t}=await n.from(`tee_times`).select(`*`).eq(`booking_date`,l).order(`booking_time`,{ascending:!0});!t&&e?(f=e,R(l,e)):f=L(l)}catch(e){console.warn(`Supabase tee_times fetch fallback:`,e),f=L(l)}x(),C();let e=document.getElementById(`reception-slots-date-label`),t=document.getElementById(`reception-corte-date-label`),r=document.getElementById(`reception-date-input`),i=document.getElementById(`reception-slots-quick-date`),a=document.getElementById(`pos-date`),o=F(l);e&&(e.textContent=o),t&&(t.textContent=o),r&&(r.value=l),i&&(i.value=l),a&&(a.value=l);let s=S(l);if(!p)w(s);else{let e=f.find(e=>e.id===p.id);e?(p=e,E()):w(s)}u===`CORTE`&&k()}function x(){let e=document.getElementById(`kpi-slots-count`),t=document.getElementById(`kpi-players-count`),n=document.getElementById(`kpi-revenue-total`),r=document.getElementById(`kpi-carts-count`),i=document.getElementById(`mini-kpi-slots`),a=document.getElementById(`mini-kpi-players`),o=document.getElementById(`mini-kpi-carts`),s=document.getElementById(`mini-kpi-revenue`),c=0,l=0,u=0,d=0;f.forEach(e=>{e.status!==`CANCELLED`&&e.status!==`BLOCKED`&&(d++,c+=parseInt(e.total_players||0),u+=parseInt(e.total_carts||0),(e.status===`PAID`||e.status===`ON_COURSE`||e.status===`COMPLETED`)&&(l+=parseFloat(e.total_amount||0)))});let p=`$${l.toLocaleString(`es-MX`,{minimumFractionDigits:2})}`;e&&(e.textContent=d),t&&(t.textContent=c),n&&(n.textContent=p),r&&(r.textContent=u),i&&(i.textContent=d),a&&(a.textContent=c),s&&(s.textContent=p),o&&(o.textContent=u)}function S(e=l){if(e!==c())return r[0]||`07:00`;let t=new Date,n=t.getHours()*60+t.getMinutes();return r.find(e=>{let[t,r]=e.split(`:`).map(Number);return t*60+r>=n})||r[r.length-1]||`17:00`}window.togglePastReceptionSlots=function(){window._showPastReceptionSlots=!window._showPastReceptionSlots,C()};function C(){let e=document.getElementById(`reception-slots-container`);if(!e)return;let t=c(),n=l===t,i=n?new Date().getHours()*60+new Date().getMinutes():0,a=r,o=``;if(n){let e=r.filter(e=>{let[t,n]=e.split(`:`).map(Number),r=t*60+n<i,a=f.find(t=>t.booking_time===e&&t.status!==`CANCELLED`);return r&&!a});window._showPastReceptionSlots?o=`
                <div class="flex items-center justify-between p-2.5 px-3 bg-slate-950/60 border border-slate-800 rounded-xl mb-2 text-xs">
                    <span class="text-slate-300 font-bold text-[11px] flex items-center gap-1.5">
                        <span class="material-icons text-xs text-primary">schedule</span>
                        Mostrando todos los horarios (incluyendo pasados)
                    </span>
                    <button type="button" onclick="window.togglePastReceptionSlots()" class="text-primary hover:underline text-[10px] font-black uppercase">
                        Ocultar Pasados
                    </button>
                </div>`:(a=r.filter(e=>{let[t,n]=e.split(`:`).map(Number),r=t*60+n<i,a=f.find(t=>t.booking_time===e&&t.status!==`CANCELLED`);return!r||a}),e.length>0&&(o=`
                    <div class="flex items-center justify-between p-2.5 px-3 bg-slate-950/60 border border-slate-800 rounded-xl mb-2 text-xs">
                        <span class="text-slate-400 font-bold text-[11px] flex items-center gap-1.5">
                            <span class="material-icons text-xs text-slate-500">history</span>
                            ${e.length} horarios matutinos pasados ocultos
                        </span>
                        <button type="button" onclick="window.togglePastReceptionSlots()" class="text-primary hover:underline text-[10px] font-black uppercase">
                            Ver Anteriores
                        </button>
                    </div>`))}e.innerHTML=o+a.map(e=>{let t=f.find(t=>t.booking_time===e&&t.status!==`CANCELLED`),r=p&&p.booking_time===e||!p&&window._formTime===e,[a,o]=e.split(`:`).map(Number),s=n&&a*60+o<i;if(!t)return`
                <div onclick="window.selectSlotForBooking('${e}', null)"
                    class="p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 group
                    ${r?`bg-primary/20 border-primary shadow-lg ring-2 ring-primary/40`:s?`bg-slate-950/40 border-slate-800/60 hover:bg-slate-900/90 hover:border-slate-700`:`bg-slate-950/60 border-slate-800/80 hover:bg-slate-800/80 hover:border-slate-700`}">
                    <div class="flex items-center gap-3">
                        <span class="w-16 text-center font-black text-sm ${s?`text-slate-400 bg-slate-900/70`:`text-slate-300 bg-slate-900`} border border-slate-800 px-2 py-1 rounded-xl group-hover:text-primary transition-colors">
                            ${e}
                        </span>
                        <div>
                            <p class="font-black text-xs ${s?`text-slate-400`:`text-slate-300`} uppercase flex items-center gap-1.5">
                                <span class="w-2 h-2 rounded-full ${s?`bg-slate-600`:`bg-emerald-400`}"></span> ${s?`Horario Pasado`:`Horario Libre`}
                            </p>
                            <p class="text-[10px] text-slate-500 font-bold">${s?`Disponible para registro o walk-in`:`Disponible para reservar o cobrar`}</p>
                        </div>
                    </div>
                    <button class="px-3 py-1.5 bg-slate-800 group-hover:bg-primary group-hover:text-slate-950 text-slate-400 rounded-xl text-[10px] font-black uppercase transition-all flex items-center gap-1">
                        <span class="material-icons text-xs">add</span> Ocupar
                    </button>
                </div>`;let c=``,l=`border-slate-700`,u=`bg-slate-800/90`;t.status===`RESERVED`?(l=`border-amber-500/50 hover:border-amber-400`,u=`bg-amber-500/10`,c=`<span class="px-2.5 py-0.5 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-lg text-[9px] font-black uppercase">🟡 Reserva Tel.</span>`):t.status===`PAID`?(l=`border-blue-500/50 hover:border-blue-400`,u=`bg-blue-500/10`,c=`<span class="px-2.5 py-0.5 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded-lg text-[9px] font-black uppercase">🔵 Pagado / En Tee</span>`):t.status===`ON_COURSE`||t.status===`COMPLETED`?(l=`border-emerald-500/50 hover:border-emerald-400`,u=`bg-emerald-500/10`,c=`<span class="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-lg text-[9px] font-black uppercase">⛳ En Campo</span>`):t.status===`BLOCKED`&&(l=`border-rose-500/40`,u=`bg-rose-500/10`,c=`<span class="px-2.5 py-0.5 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-lg text-[9px] font-black uppercase">🔴 Bloqueado</span>`);let d=Array.isArray(t.players)?t.players.map(e=>e.name).filter(Boolean).join(`, `):t.contact_name||`Sin nombres`,m=t.caddie_assigned||t.cart_numbers?`<p class="text-[9px] text-emerald-400 font-bold truncate mt-0.5"><span class="material-icons align-middle text-[11px]">sports_golf</span> Caddie: ${t.caddie_assigned||`S/C`} ${t.cart_numbers?`| Carro #`+t.cart_numbers:``}</p>`:``;return`
            <div onclick="window.selectSlotForBooking('${e}', '${t.id}')"
                class="p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${u} ${l}
                ${r?`ring-2 ring-primary/60 shadow-xl`:``}">
                <div class="flex items-center gap-3 min-w-0">
                    <span class="w-16 text-center font-black text-sm text-white bg-slate-900/90 border border-slate-700 px-2 py-1 rounded-xl shrink-0">
                        ${e}
                    </span>
                    <div class="min-w-0">
                        <div class="flex items-center gap-2">
                            <p class="font-black text-white text-xs uppercase truncate">${t.contact_name||`Reserva`}</p>
                            <span class="text-[10px] font-bold text-slate-400 shrink-0">(${t.total_players||1} jug)</span>
                        </div>
                        <p class="text-[10px] text-slate-400 font-bold truncate mt-0.5">${d}</p>
                        ${m}
                    </div>
                </div>
                <div class="flex flex-col items-end gap-1 shrink-0">
                    ${c}
                    <span class="text-[10px] font-black text-slate-300 bg-slate-900/80 px-2 py-0.5 rounded-md border border-slate-700">
                        Folio: #${t.folio?t.folio.split(`-`).pop():`—`}
                    </span>
                </div>
            </div>`}).join(``)}window.selectSlotForBooking=function(e,t){t?(p=f.find(e=>String(e.id)===String(t))||null,p&&(window._formTime=p.booking_time,m=Array.isArray(p.players)&&p.players.length>0?JSON.parse(JSON.stringify(p.players)):[T(1)])):(p=null,w(e)),C(),E()},window.startNewBookingFromScratch=function(){p=null,w(S(l)),C(),E()},window.handlePosTimeChange=function(e){window._formTime=e,p&&(p.booking_time=e),C(),E()};function w(e=`08:00`){p=null,m=[T(1)],window._formTime=e,E()}function T(e=1){return{id:`p_`+Math.random().toString(36).substr(2,9),name:``,player_type:`GUEST`,is_member:!1,member_id:null,member_number:``,convenio_id:null,convenio_name:``,holes:18,has_cart:!1,has_clubs:!1,green_fee:o.greenFee18Guest,cart_fee:0,club_fee:0,payment_method:window._posPaymentMethod===`CORTESIA`?`CORTESIA`:`EFECTIVO`,transaction_ref:``}}function E(){let e=document.getElementById(`reception-pos-card`);if(!e)return;let n=!!p,i=n?p.booking_time:window._formTime||`08:00`;n?p.contact_name:m[0]?.name;let a=n&&p.contact_phone||``;n?p.payment_method:window._posPaymentMethod;let o=n&&p.starting_hole||1,s=n&&p.notes||``,c=n?p.folio:P(),l=n?p.status:`NEW`;e.innerHTML=`
        <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-6">
            
            <!-- Top Control Bar -->
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 rounded-2xl bg-primary/20 border border-primary/30 flex items-center justify-center text-primary shrink-0 shadow-lg shadow-primary/10">
                        <span class="material-icons text-2xl">sports_score</span>
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <h3 class="text-xl font-black text-white uppercase tracking-tight">
                                ${n?`Editar Salida: Folio ${c}`:`Nuevo Registro de Salida`}
                            </h3>
                            <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${l===`PAID`?`bg-emerald-500/20 text-emerald-300 border border-emerald-500/40`:l===`ON_COURSE`?`bg-blue-500/20 text-blue-300 border border-blue-500/40`:l===`RESERVED`?`bg-amber-500/20 text-amber-300 border border-amber-500/40`:`bg-slate-800 text-slate-300 border border-slate-700`}">
                                ${l===`PAID`?`Pagado / Autorizado`:l===`ON_COURSE`?`En Campo`:l===`RESERVED`?`Reserva Telefónica`:`Nuevo`}
                            </span>
                        </div>
                        <p class="text-xs font-bold text-slate-400 mt-0.5">Captura de Jugadores, Green Fees, Carritos, Renta de Equipo & Cobro POS</p>
                    </div>
                </div>

                <div class="flex items-center gap-2 self-end sm:self-auto flex-wrap">
                    ${n&&t()?`
                        <button type="button" onclick="window.cancelBooking('${p.id}')"
                            class="px-3.5 py-2.5 bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-rose-400 hover:text-white rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-sm" title="Eliminar y liberar este horario (Solo Administrador)">
                            <span class="material-icons text-sm">delete_forever</span> Borrar Salida
                        </button>
                    `:``}

                    ${n?`
                        <button type="button" onclick="window.printReceiptModal('${p.id}', selectedBooking)"
                            class="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-1.5">
                            <span class="material-icons text-sm">print</span> Pase
                        </button>
                    `:``}

                    <button type="button" onclick="window.startNewBookingFromScratch()"
                        class="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-1.5" title="Limpiar y crear nuevo">
                        <span class="material-icons text-sm">add_circle_outline</span> Nuevo
                    </button>
                </div>
            </div>

            <!-- Form Body -->
            <form id="reception-pos-form" onsubmit="event.preventDefault();" class="space-y-6">
                
                <!-- Group & Time Metadata Strip -->
                <div class="grid grid-cols-1 sm:grid-cols-12 gap-3 p-4 bg-slate-950/60 border border-slate-800 rounded-2xl">
                    <div class="sm:col-span-3 space-y-1">
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Horario de Salida *</label>
                        <select id="pos-time" onchange="window.handlePosTimeChange(this.value)"
                            class="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-black text-white focus:outline-none focus:border-primary">
                            ${r.map(e=>`<option value="${e}" ${e===i?`selected`:``}>${e} hrs</option>`).join(``)}
                        </select>
                    </div>

                    <div class="sm:col-span-3 space-y-1">
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Hoyo de Salida (Tee)</label>
                        <select id="pos-starting-hole"
                            class="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-black text-white focus:outline-none focus:border-primary">
                            ${Array.from({length:18},(e,t)=>t+1).map(e=>`
                                <option value="${e}" ${e===o?`selected`:``}>Hoyo ${e}${e===1?` (Tee Inicial)`:e===10?` (Vuelta 2)`:``}</option>
                            `).join(``)}
                        </select>
                    </div>

                    <div class="sm:col-span-3 space-y-1">
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Teléfono de Contacto</label>
                        <input id="pos-contact-phone" type="tel" value="${a}" placeholder="Ej. 312 123 4567"
                            class="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-white placeholder:text-slate-600 focus:outline-none focus:border-primary">
                    </div>

                    <div class="sm:col-span-3 space-y-1">
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Folio de Ticket</label>
                        <div class="px-3.5 py-2.5 bg-slate-900/90 border border-slate-800 rounded-xl text-xs font-black text-primary flex items-center justify-between">
                            <span>${c}</span>
                            <span class="material-icons text-sm text-slate-600">confirmation_number</span>
                        </div>
                    </div>
                </div>

                <!-- Players Section -->
                <div class="space-y-3">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <h4 class="text-sm font-black uppercase text-white tracking-wider flex items-center gap-2">
                                <span class="material-icons text-primary text-base">groups</span> Jugadores del Grupo (${m.length})
                            </h4>
                            <span class="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Máximo 8 jugadores</span>
                        </div>

                        <button type="button" onclick="window.addPlayerToPOSForm()"
                            class="px-3.5 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-400 rounded-xl font-black text-[11px] uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-md">
                            <span class="material-icons text-sm">person_add</span> + Agregar Jugador
                        </button>
                    </div>

                    <!-- Dynamic Player Cards List -->
                    <div id="pos-players-list" class="space-y-3">
                        ${m.map((e,t)=>D(e,t)).join(``)}
                    </div>
                </div>

                <!-- Summary & Notes -->
                <div class="bg-slate-950/90 border border-slate-800 rounded-2xl p-5 space-y-4">
                    <div>
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 flex items-center gap-1.5">
                            <span class="material-icons text-sm text-slate-400">edit_note</span> Notas u Observaciones de la Salida
                        </label>
                        <input id="pos-notes" type="text" value="${s}" placeholder="Ej. Palos rentados, cortesía aprobada por presidencia"
                            class="w-full px-4 py-3 bg-slate-800 border-2 border-slate-700 rounded-xl text-xs font-bold text-white placeholder:text-slate-500 focus:outline-none focus:border-primary">
                    </div>

                    <!-- Live Total Calculation Bar with Method Breakdown -->
                    <div class="pt-4 border-t border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-xl">
                        <div class="space-y-2">
                            <div class="flex items-center gap-4 text-xs font-bold text-slate-400 flex-wrap">
                                <span>Green Fees: <strong id="pos-calc-greenfees" class="text-white font-black">$0</strong></span>
                                <span>Carritos: <strong id="pos-calc-carts" class="text-white font-black">$0</strong></span>
                                <span>Renta Equipo: <strong id="pos-calc-clubs" class="text-blue-400 font-black">$0</strong></span>
                            </div>
                            <!-- Live Breakdown by Payment Method -->
                            <div id="pos-calc-method-breakdown" class="flex items-center gap-2 flex-wrap text-xs">
                                <!-- Populated dynamically by recalculatePOSFormTotals -->
                            </div>
                        </div>

                        <div class="text-right shrink-0">
                            <p class="text-[10px] font-black uppercase text-primary tracking-widest">Total a Cobrar</p>
                            <h3 id="pos-calc-grand-total" class="text-3xl font-black text-emerald-400 leading-none mt-0.5">$0.00</h3>
                        </div>
                    </div>
                </div>

                <!-- Action Submit Buttons -->
                ${(()=>{let e=n&&(l===`PAID`||l===`ON_COURSE`),r=n&&l===`RESERVED`,i=t();return e?`
                            <div class="space-y-3 pt-2">
                                <div class="p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center justify-between gap-3 text-xs">
                                    <div class="flex items-center gap-2.5">
                                        <span class="w-8 h-8 rounded-xl ${l===`ON_COURSE`?`bg-emerald-500/20 text-emerald-400`:`bg-blue-500/20 text-blue-400`} flex items-center justify-center shrink-0">
                                            <span class="material-icons text-base">${l===`ON_COURSE`?`sports_golf`:`check_circle`}</span>
                                        </span>
                                        <div>
                                            <span class="font-black text-white uppercase">${l===`ON_COURSE`?`⛳ Salida en Campo`:`🔵 Salida Pagada & Autorizada`}</span>
                                            <p class="text-[10px] text-slate-400 font-bold">Esta salida ya cuenta con registro de pago en caja.</p>
                                        </div>
                                    </div>
                                    <span class="px-3 py-1 bg-emerald-500 text-slate-950 font-black text-[10px] rounded-lg uppercase">PAGADO</span>
                                </div>

                                <div class="grid grid-cols-1 ${i?`sm:grid-cols-3`:`sm:grid-cols-2`} gap-4">
                                    <button type="button" onclick="window.printReceiptModal('${p.id}', selectedBooking)"
                                        class="py-4 bg-slate-800 hover:bg-slate-700 border-2 border-slate-700 text-white rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg">
                                        <span class="material-icons text-primary text-base">print</span> 🖨️ Re-imprimir Pase
                                    </button>

                                    <button type="button" onclick="window.saveBookingAction('${l}')"
                                        class="py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-xl shadow-emerald-500/20 hover:scale-[1.01] active:scale-98">
                                        <span class="material-icons text-base">save</span> 💾 Guardar Cambios
                                    </button>

                                    ${i?`
                                        <button type="button" onclick="window.cancelBooking('${p.id}')"
                                            class="py-4 bg-rose-600/20 hover:bg-rose-600/30 border-2 border-rose-500/60 text-rose-300 hover:text-white rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-lg shadow-rose-500/10 hover:scale-[1.01] active:scale-98">
                                            <span class="material-icons text-base text-rose-400">delete_forever</span> 🗑️ Borrar Salida (Admin)
                                        </button>
                                    `:``}
                                </div>
                            </div>`:r?`
                            <div class="grid grid-cols-1 ${i?`sm:grid-cols-3`:`sm:grid-cols-2`} gap-4 pt-2">
                                <button type="button" onclick="window.saveBookingAction('RESERVED')"
                                    class="py-4 bg-amber-500/20 hover:bg-amber-500/30 border-2 border-amber-500/50 text-amber-400 rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg shadow-amber-500/10">
                                    <span class="material-icons text-base">bookmark</span> 💾 Actualizar Reserva
                                </button>

                                <button type="button" onclick="window.saveBookingAction('PAID')"
                                    class="py-4 bg-primary hover:bg-primary/90 text-slate-950 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-xl shadow-primary/20 hover:scale-[1.01] active:scale-98">
                                    <span class="material-icons text-base">payments</span> 💳 Cobrar & Autorizar Salida
                                </button>

                                ${i?`
                                    <button type="button" onclick="window.cancelBooking('${p.id}')"
                                        class="py-4 bg-rose-600/20 hover:bg-rose-600/30 border-2 border-rose-500/60 text-rose-300 hover:text-white rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-lg shadow-rose-500/10 hover:scale-[1.01] active:scale-98">
                                        <span class="material-icons text-base text-rose-400">delete_forever</span> 🗑️ Borrar Reserva (Admin)
                                    </button>
                                `:``}
                            </div>`:`
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                                <button type="button" onclick="window.saveBookingAction('RESERVED')"
                                    class="py-4 bg-amber-500/20 hover:bg-amber-500/30 border-2 border-amber-500/50 text-amber-400 rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg shadow-amber-500/10">
                                    <span class="material-icons text-base">bookmark</span> Guardar Reserva Telefónica (Pendiente de Pago)
                                </button>

                                <button type="button" onclick="window.saveBookingAction('PAID')"
                                    class="py-4 bg-primary hover:bg-primary/90 text-slate-950 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-xl shadow-primary/20 hover:scale-[1.01] active:scale-98">
                                    <span class="material-icons text-base">payments</span> 💳 Cobrar & Autorizar Salida (Caddie Master)
                                </button>
                            </div>`})()}

            </form>
        </div>
    `,O()}function D(e,t){let n=e.player_type||(e.is_member?`MEMBER`:e.convenio_id?`CONVENIO`:`GUEST`),r=n===`MEMBER`,i=n===`CONVENIO`,a=n===`CORTESIA`||e.payment_method===`CORTESIA`,l=e.holes||18,u=!!e.has_cart,f=!!e.has_clubs,p=e.payment_method||(a?`CORTESIA`:`EFECTIVO`),h=r&&e.member_id?d.find(t=>String(t.id)===String(e.member_id)):null,g=c(),_=!h||h.paid_until&&h.paid_until>=g&&h.status===`ACTIVE`,v=o.greenFee18Guest,y=u?o.cart18:0,b=f?o.clubRentalFee||400:0;if(a||r){if(v=0,i){let t=s.find(t=>String(t.id)===String(e.convenio_id))||s[0];y=u?parseFloat(t.cart_fee_18)||o.cart18:0}else y=u?o.cart18:0}else if(i){let t=s.find(t=>String(t.id)===String(e.convenio_id))||s[0];t&&(v=parseFloat(t.green_fee_18)||o.greenFee18Guest,u&&(y=parseFloat(t.cart_fee_18)||o.cart18))}else v=o.greenFee18Guest,y=u?o.cart18:0;let x=a?0:e.green_fee===void 0?v:e.green_fee,S=u?e.cart_fee===void 0?y:e.cart_fee:0,C=f?e.club_fee===void 0?b:e.club_fee:0,w=(parseFloat(x)||0)+(parseFloat(S)||0)+(parseFloat(C)||0);return e.green_fee=parseFloat(x)||0,e.cart_fee=parseFloat(S)||0,e.club_fee=parseFloat(C)||0,`
        <div id="player-row-${e.id}" class="bg-slate-950/70 border ${a?`border-purple-500/50 shadow-lg shadow-purple-500/5`:i?`border-indigo-500/40`:r?`border-emerald-500/30`:`border-slate-800`} rounded-2xl p-4 space-y-3 relative group transition-all">
            
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
                <div class="flex flex-wrap items-center gap-2">
                    <span class="w-6 h-6 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-[11px] font-black text-white">
                        #${t+1}
                    </span>
                    <span class="text-xs font-black uppercase text-slate-300">Jugador ${t+1}</span>
                    
                    <!-- 4-Pill Switch: Invitado | Socio | Convenio | Cortesía -->
                    <div class="inline-flex rounded-xl bg-slate-900 p-1 border border-slate-800 text-[10px] font-black flex-wrap gap-0.5">
                        <button type="button" onclick="window.setPlayerType('${e.id}', 'GUEST')"
                            class="px-2.5 py-1 rounded-lg transition-all ${n===`GUEST`?`bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20`:`text-slate-400 hover:text-white`}">
                            No Socio / Invitado
                        </button>
                        <button type="button" onclick="window.setPlayerType('${e.id}', 'MEMBER')"
                            class="px-2.5 py-1 rounded-lg transition-all ${n===`MEMBER`?`bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20`:`text-slate-400 hover:text-white`}">
                            Socio del Club
                        </button>
                        <button type="button" onclick="window.setPlayerType('${e.id}', 'CONVENIO')"
                            class="px-2.5 py-1 rounded-lg transition-all ${n===`CONVENIO`?`bg-indigo-500 text-white shadow-md shadow-indigo-500/20`:`text-slate-400 hover:text-white`}">
                            🤝 Convenio
                        </button>
                        <button type="button" onclick="window.setPlayerType('${e.id}', 'CORTESIA')"
                            class="px-2.5 py-1 rounded-lg transition-all ${n===`CORTESIA`?`bg-purple-600 text-white shadow-md shadow-purple-600/20`:`text-slate-400 hover:text-white`}">
                            ⛳ Cortesía Directiva
                        </button>
                    </div>
                </div>

                ${m.length>1?`
                    <button type="button" onclick="window.removePlayerFromPOSForm('${e.id}')"
                        class="text-rose-400 hover:text-rose-300 text-xs font-black uppercase flex items-center gap-1 self-end sm:self-auto transition-colors" title="Eliminar Jugador">
                        <span class="material-icons text-sm">remove_circle_outline</span> Quitar
                    </button>
                `:``}
            </div>

            <!-- Player Inputs Grid (12 cols) -->
            <div class="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                
                <!-- Player Name / Selector (sm:col-span-6) -->
                <div class="sm:col-span-6">
                    ${r?`
                        <div>
                            <div class="flex items-center justify-between mb-1.5 h-3.5">
                                <label class="block text-[9px] font-black text-emerald-400 uppercase tracking-widest leading-none">Nombre del Socio *</label>
                                ${h?`
                                    <span class="text-[9px] font-bold ${_?`text-emerald-400`:`text-rose-400`} leading-none">
                                        ${_?`✅ Cuota al Día`:`⚠️ Cuota Vencida`}
                                    </span>
                                `:``}
                            </div>
                            <div class="relative">
                                <input type="text"
                                    id="member-input-${e.id}"
                                    list="members-autocomplete-list"
                                    value="${I(h?h.name:e.name||``)}"
                                    placeholder="Escribe el nombre del socio..."
                                    autocomplete="off"
                                    oninput="window.onMemberTyped('${e.id}', this.value)"
                                    onchange="window.onMemberSearchChange('${e.id}', this.value)"
                                    class="w-full h-11 px-3.5 bg-slate-900 border ${h?`border-emerald-500/60 text-emerald-300`:`border-slate-700 text-white`} rounded-xl text-xs font-black uppercase placeholder:normal-case placeholder:text-slate-500 focus:outline-none focus:border-primary pr-8">
                                ${h?`
                                    <button type="button" onclick="window.clearSelectedMember('${e.id}')"
                                        class="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-rose-400 text-xs font-black transition-colors" title="Cambiar socio">
                                        <span class="material-icons text-sm">close</span>
                                    </button>
                                `:``}
                            </div>
                        </div>
                    `:i?`
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                                <label class="block text-[9px] font-black text-indigo-400 uppercase tracking-widest mb-1.5 h-3.5 leading-none">Convenio *</label>
                                <select onchange="window.onPlayerConvenioSelected('${e.id}', this.value)"
                                    class="w-full h-11 px-2.5 bg-slate-900 border border-indigo-500/40 rounded-xl text-xs font-black text-white focus:outline-none focus:border-indigo-400">
                                    ${s.map(t=>`
                                        <option value="${t.id}" ${e.convenio_id===t.id||e.convenio_name===t.name?`selected`:``}>
                                            ${t.name}
                                        </option>
                                    `).join(``)}
                                </select>
                            </div>
                            <div>
                                <label class="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5 h-3.5 leading-none">Nombre Jugador *</label>
                                <input type="text" value="${I(e.name||``)}" placeholder="Ej. Carlos Mendoza"
                                    oninput="window.onPlayerNameInput('${e.id}', this.value)"
                                    class="w-full h-11 px-3 bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-white placeholder:text-slate-600 focus:outline-none focus:border-primary">
                            </div>
                        </div>
                    `:a?`
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                                <label class="block text-[9px] font-black text-purple-400 uppercase tracking-widest mb-1.5 h-3.5 leading-none">Beneficiario *</label>
                                <input type="text" value="${I(e.name||``)}" placeholder="Ej. Lic. Manuel Mendoza"
                                    oninput="window.onPlayerNameInput('${e.id}', this.value)"
                                    class="w-full h-11 px-3 bg-slate-900 border border-purple-500/40 rounded-xl text-xs font-bold text-white placeholder:text-slate-600 focus:outline-none focus:border-purple-400">
                            </div>
                            <div>
                                <label class="block text-[9px] font-black text-amber-400 uppercase tracking-widest mb-1.5 h-3.5 leading-none flex items-center gap-1">
                                    <span class="material-icons text-xs">verified_user</span> ¿Quién Autoriza? *
                                </label>
                                <input type="text" value="${I(e.authorized_by||``)}" placeholder="Ej. Presidencia"
                                    oninput="window.onPlayerAuthorizedByInput('${e.id}', this.value)"
                                    class="w-full h-11 px-3 bg-slate-900 border border-amber-500/50 rounded-xl text-xs font-black text-amber-300 placeholder:text-slate-600 focus:outline-none focus:border-amber-400">
                            </div>
                        </div>
                    `:`
                        <div>
                            <label class="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5 h-3.5 leading-none">Nombre Completo del Invitado *</label>
                            <input type="text" value="${I(e.name||``)}" placeholder="Ej. Carlos Mendoza"
                                oninput="window.onPlayerNameInput('${e.id}', this.value)"
                                class="w-full h-11 px-3.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-bold text-white placeholder:text-slate-600 focus:outline-none focus:border-primary">
                        </div>
                    `}
                </div>

                <!-- Hoyos: 18 vs 9 (sm:col-span-2) -->
                <div class="sm:col-span-2">
                    <label class="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5 h-3.5 leading-none">Hoyos</label>
                    <select onchange="window.onPlayerHolesChange('${e.id}', parseInt(this.value))"
                        class="w-full h-11 px-3 bg-slate-900 border border-slate-700 rounded-xl text-xs font-black text-white focus:outline-none focus:border-primary cursor-pointer">
                        <option value="18" ${l===18?`selected`:``}>18 Hoyos</option>
                        <option value="9" ${l===9?`selected`:``}>9 Hoyos</option>
                    </select>
                </div>

                <!-- Rentas Adicionales: Carrito (sm:col-span-2) -->
                <div class="sm:col-span-2">
                    <label class="block text-[9px] font-black text-amber-400 uppercase tracking-widest mb-1.5 h-3.5 leading-none">Carrito</label>
                    <label class="flex items-center justify-center gap-2 w-full h-11 px-3 bg-slate-900 border ${u?`border-amber-500/60 bg-amber-950/20 text-amber-300 shadow-sm shadow-amber-500/10`:`border-slate-700 text-slate-400 hover:border-slate-600`} rounded-xl cursor-pointer transition-all select-none">
                        <input type="checkbox" ${u?`checked`:``} onchange="window.onPlayerCartToggle('${e.id}', this.checked)"
                            class="rounded text-amber-500 focus:ring-0 focus:outline-none w-4 h-4 bg-slate-800 border-slate-700 cursor-pointer">
                        <span class="text-xs font-black uppercase tracking-wider">🚗 Carro</span>
                    </label>
                </div>

                <!-- Rentas Adicionales: Palos / Equipo (sm:col-span-2) -->
                <div class="sm:col-span-2">
                    <label class="block text-[9px] font-black text-blue-400 uppercase tracking-widest mb-1.5 h-3.5 leading-none">Equipo</label>
                    <label class="flex items-center justify-center gap-2 w-full h-11 px-3 bg-slate-900 border ${f?`border-blue-500/60 bg-blue-950/20 text-blue-300 shadow-sm shadow-blue-500/10`:`border-slate-700 text-slate-400 hover:border-blue-500/40`} rounded-xl cursor-pointer transition-all select-none">
                        <input type="checkbox" ${f?`checked`:``} onchange="window.onPlayerClubToggle('${e.id}', this.checked)"
                            class="rounded text-blue-500 focus:ring-0 focus:outline-none w-4 h-4 bg-slate-800 border-slate-700 cursor-pointer">
                        <span class="text-xs font-black uppercase tracking-wider">🏌️ Palos</span>
                    </label>
                </div>

            </div>

            <!-- Individual Player Payment Method Row -->
            <div class="pt-2 border-t border-slate-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-900/30 p-2.5 rounded-xl">
                <div class="flex items-center gap-2 flex-wrap">
                    ${r?`
                        <div class="flex items-center gap-2">
                            <span class="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-emerald-400 font-black text-[10px] uppercase tracking-wider flex items-center gap-1.5">
                                <span class="material-icons text-sm">badge</span> Socio del Club
                            </span>
                            ${u||f?`
                                <span class="text-[9px] text-amber-400 font-bold uppercase tracking-wider">
                                    Paga adicionales: ${u?`🚗 Carro ($`+S+`)`:``} ${f?`🏌️ Equipo ($`+C+`)`:``}
                                </span>
                            `:``}
                        </div>
                    `:a?`
                        <div class="flex items-center gap-2">
                            <span class="px-2.5 py-1 bg-purple-500/10 border border-purple-500/30 rounded-lg text-purple-300 font-black text-[10px] uppercase tracking-wider flex items-center gap-1.5">
                                <span class="material-icons text-sm">flag</span> Cortesía Directiva (Exento)
                            </span>
                        </div>
                    `:`
                        <label class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Forma de Pago Jugador #${t+1}:</label>
                        <select onchange="window.onPlayerPaymentMethodChange('${e.id}', this.value)"
                            class="px-2.5 py-1 bg-slate-900 border border-slate-700 rounded-lg text-xs font-black text-white focus:outline-none focus:border-primary">
                            <option value="EFECTIVO" ${p===`EFECTIVO`?`selected`:``}>💵 Efectivo</option>
                            <option value="TARJETA" ${p===`TARJETA`?`selected`:``}>💳 Tarjeta (TPV)</option>
                            <option value="TRANSFERENCIA" ${p===`TRANSFERENCIA`?`selected`:``}>📲 Transferencia SPEI</option>
                        </select>

                        ${p===`TARJETA`||p===`TRANSFERENCIA`?`
                            <input type="text" value="${I(e.transaction_ref||``)}"
                                placeholder="${p===`TRANSFERENCIA`?`# Folio SPEI`:`# Ref / Aprobación TPV`}"
                                oninput="window.onPlayerTransactionRefInput('${e.id}', this.value)"
                                class="px-2.5 py-1 bg-slate-900 border border-blue-500/50 rounded-lg text-xs font-bold text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-400 w-40 animate-fade-in">
                        `:``}
                    `}
                </div>

                <div class="text-right flex items-center justify-end gap-2 sm:self-center">
                    <span class="text-[10px] text-slate-400 font-bold uppercase">Subtotal Jugador #${t+1}:</span>
                    <span class="text-sm font-black ${a&&!u&&!f?`text-purple-400`:`text-emerald-400`}">
                        $${w.toLocaleString(`es-MX`,{minimumFractionDigits:2})}
                    </span>
                </div>
            </div>

        </div>
    `}window.addPlayerToPOSForm=function(){if(m.length>=8){window.showNotification(`Límite de Jugadores`,`Un grupo puede tener un máximo de 8 jugadores en un solo recibo.`,`error`);return}m.push(T(m.length+1)),E()},window.removePlayerFromPOSForm=function(e){m.length<=1||(m=m.filter(t=>t.id!==e),E())},window.setPlayerType=function(e,t){let n=m.find(t=>t.id===e);if(n){if(t===!0&&(t=`MEMBER`),t===!1&&(t=`GUEST`),n.player_type=t,n.is_member=t===`MEMBER`,t===`MEMBER`)n.convenio_id=null,n.convenio_name=``,n.green_fee=0,n.payment_method=`SOCIO`,n.cart_fee=n.has_cart?o.cart18:0,n.club_fee=n.has_clubs?o.clubRentalFee||400:0;else if(t===`CONVENIO`){n.member_id=null,n.member_number=``,n.payment_method=n.payment_method===`CORTESIA`?`EFECTIVO`:n.payment_method||`EFECTIVO`;let e=s[0];e?(n.convenio_id=e.id,n.convenio_name=e.name,n.green_fee=parseFloat(e.green_fee_18)||o.greenFee18Guest,n.cart_fee=n.has_cart?parseFloat(e.cart_fee_18)||o.cart18:0):(n.green_fee=o.greenFee18Guest,n.cart_fee=n.has_cart?o.cart18:0),n.club_fee=n.has_clubs?o.clubRentalFee||400:0}else t===`CORTESIA`?(n.member_id=null,n.member_number=``,n.convenio_id=null,n.convenio_name=``,n.green_fee=0,n.payment_method=`CORTESIA`,n.cart_fee=n.has_cart?o.cart18:0,n.club_fee=n.has_clubs?o.clubRentalFee||400:0):(n.member_id=null,n.member_number=``,n.convenio_id=null,n.convenio_name=``,n.payment_method=n.payment_method===`CORTESIA`?`EFECTIVO`:n.payment_method||`EFECTIVO`,n.green_fee=o.greenFee18Guest,n.cart_fee=n.has_cart?o.cart18:0,n.club_fee=n.has_clubs?o.clubRentalFee||400:0);E()}},window.onPlayerPaymentMethodChange=function(e,t){let n=m.find(t=>t.id===e);n&&(n.payment_method=t,t===`CORTESIA`?(n.green_fee=0,n.player_type=`CORTESIA`):n.player_type===`CORTESIA`&&(n.player_type=`GUEST`,n.green_fee=o.greenFee18Guest),E())},window.onPlayerTransactionRefInput=function(e,t){let n=m.find(t=>t.id===e);n&&(n.transaction_ref=t)},window.onPlayerAuthorizedByInput=function(e,t){let n=m.find(t=>t.id===e);n&&(n.authorized_by=t)},window.applyGlobalPaymentMethod=function(e){window._posPaymentMethod=e,e!==`MIXTO`&&m.forEach(t=>{if(t.player_type===`MEMBER`||t.is_member){t.payment_method=`SOCIO`;return}t.payment_method=e,e===`CORTESIA`?(t.green_fee=0,t.player_type=`CORTESIA`):t.player_type===`CORTESIA`&&(t.player_type=`GUEST`,t.green_fee=o.greenFee18Guest)}),E()},window.onPlayerConvenioSelected=function(e,t){let n=m.find(t=>t.id===e);if(!n)return;let r=s.find(e=>String(e.id)===String(t));r&&(n.convenio_id=r.id,n.convenio_name=r.name,n.green_fee=parseFloat(r.green_fee_18)||o.greenFee18Guest,n.has_cart&&(n.cart_fee=parseFloat(r.cart_fee_18)||o.cart18)),E()},window.onMemberSelected=function(e,t){let n=m.find(t=>t.id===e);if(!n)return;let r=d.find(e=>String(e.id)===String(t));r?(n.member_id=r.id,n.member_number=r.member_number,n.name=r.name,n.green_fee=0):(n.member_id=null,n.member_number=``,n.name=``,n.green_fee=0),E()},window.onMemberTyped=function(e,t){let n=m.find(t=>t.id===e);if(!n)return;n.name=t;let r=(t||``).trim().toLowerCase();if(!r){n.member_id=null,n.member_number=``;return}let i=d.find(e=>(e.name||``).toLowerCase()===r);i&&(n.member_id=i.id,n.member_number=i.member_number,n.name=i.name,n.green_fee=0,E())},window.onMemberSearchChange=function(e,t){let n=m.find(t=>t.id===e);if(!n)return;let r=(t||``).trim().toLowerCase();if(!r){n.member_id=null,n.member_number=``,n.name=``,E();return}let i=d.find(e=>(e.name||``).toLowerCase()===r)||d.find(e=>(e.name||``).toLowerCase().includes(r));i?(n.member_id=i.id,n.member_number=i.member_number,n.name=i.name,n.green_fee=0):(n.member_id=null,n.member_number=``,n.name=t),E()},window.clearSelectedMember=function(e){let t=m.find(t=>t.id===e);t&&(t.member_id=null,t.member_number=``,t.name=``,E(),setTimeout(()=>{document.getElementById(`member-input-${e}`)?.focus()},50))},window.onPlayerNameInput=function(e,t){let n=m.find(t=>t.id===e);n&&(n.name=t)},window.onPlayerHolesChange=function(e,t){let n=m.find(t=>t.id===e);n&&(n.holes=t,E())},window.onPlayerCartToggle=function(e,t){let n=m.find(t=>t.id===e);if(n){if(n.has_cart=t,t){if(n.player_type===`CONVENIO`){let e=s.find(e=>String(e.id)===String(n.convenio_id))||s[0];n.cart_fee=e&&parseFloat(e.cart_fee_18)||o.cart18}else n.cart_fee=o.cart18}else n.cart_fee=0;E()}},window.onPlayerClubToggle=function(e,t){let n=m.find(t=>t.id===e);n&&(n.has_clubs=t,n.club_fee=t?o.clubRentalFee||400:0,E())},window.onPlayerGreenFeeInput=function(e,t){let n=m.find(t=>t.id===e);n&&(n.green_fee=t,O())},window.onPlayerCartFeeInput=function(e,t){let n=m.find(t=>t.id===e);n&&(n.cart_fee=t,O())},window.onPlayerClubFeeInput=function(e,t){let n=m.find(t=>t.id===e);n&&(n.club_fee=t,O())};function O(){let e=0,t=0,n=0,r={EFECTIVO:0,TARJETA:0,TRANSFERENCIA:0,CORTESIA:0},i=0,a=0;m.forEach(o=>{let s=parseFloat(o.green_fee||0),c=parseFloat(o.cart_fee||0),l=parseFloat(o.club_fee||0),u=s+c+l,d=o.payment_method||(o.player_type===`CORTESIA`?`CORTESIA`:o.player_type===`MEMBER`?`SOCIO`:`EFECTIVO`);e+=s,t+=c,n+=l,o.player_type===`MEMBER`||o.is_member||d===`SOCIO`?(a++,c+l>0&&(r.EFECTIVO+=c+l)):r[d]===void 0?r.EFECTIVO+=u:r[d]+=u,(d===`CORTESIA`||o.player_type===`CORTESIA`)&&i++});let o=e+t+n,s=document.getElementById(`pos-calc-greenfees`),c=document.getElementById(`pos-calc-carts`),l=document.getElementById(`pos-calc-clubs`),u=document.getElementById(`pos-calc-grand-total`),d=document.getElementById(`pos-calc-method-breakdown`);if(s&&(s.textContent=`$${e.toLocaleString(`es-MX`,{minimumFractionDigits:2})}`),c&&(c.textContent=`$${t.toLocaleString(`es-MX`,{minimumFractionDigits:2})}`),l&&(l.textContent=`$${n.toLocaleString(`es-MX`,{minimumFractionDigits:2})}`),u&&(u.textContent=`$${o.toLocaleString(`es-MX`,{minimumFractionDigits:2})}`),d){let e=[];r.EFECTIVO>0&&e.push(`<span class="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400 font-bold">💵 Efectivo: <strong>$${r.EFECTIVO.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</strong></span>`),r.TARJETA>0&&e.push(`<span class="px-2.5 py-1 bg-blue-500/10 border border-blue-500/30 rounded-xl text-blue-400 font-bold">💳 Tarjeta: <strong>$${r.TARJETA.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</strong></span>`),r.TRANSFERENCIA>0&&e.push(`<span class="px-2.5 py-1 bg-purple-500/10 border border-purple-500/30 rounded-xl text-purple-400 font-bold">📲 SPEI: <strong>$${r.TRANSFERENCIA.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</strong></span>`),a>0&&e.push(`<span class="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 font-bold">🟢 Socios: <strong>${a} Jugador${a>1?`es`:``}</strong></span>`),i>0&&e.push(`<span class="px-2.5 py-1 bg-indigo-500/10 border border-indigo-500/30 rounded-xl text-indigo-300 font-bold">⛳ Cortesías: <strong>${i} Jugador${i>1?`es`:``} ($0)</strong></span>`),d.innerHTML=e.length>0?e.join(` `):`<span class="text-slate-500 font-bold text-[10px]">Sin cobro pendiente</span>`}}window.saveBookingAction=async function(e){let t=document.getElementById(`pos-time`)?.value||`08:00`,r=parseInt(document.getElementById(`pos-starting-hole`)?.value)||1,i=document.getElementById(`pos-contact-phone`)?.value.trim()||``;document.getElementById(`pos-payment-method`)?.value;let a=document.getElementById(`pos-notes`)?.value.trim()||``;if(!m||m.length===0){window.showNotification(`Datos Requeridos`,`Agrega al menos un jugador al registro.`,`error`);return}for(let e=0;e<m.length;e++){let t=m[e];if(!t.name||t.name.trim()===``){window.showNotification(`Nombre Requerido`,`Ingresa el nombre del Jugador #${e+1}.`,`error`);return}}let o=m[0].name,s=m.length,c=m.filter(e=>e.has_cart).length,u=m.filter(e=>e.has_clubs).length,d=0,f=0,h=0;m.forEach(e=>{d+=parseFloat(e.green_fee||0),f+=parseFloat(e.cart_fee||0),h+=parseFloat(e.club_fee||0)});let g=d+f+h,_=s===1?`INDIVIDUAL`:s===2?`PAREJA`:s<=4?`FOURSOME`:`GRUPO`,v=!!p,y=v&&(p.status===`PAID`||p.status===`ON_COURSE`),x=y?p.status:e,S=y?p.paid_at||new Date().toISOString():e===`PAID`?new Date().toISOString():null,C=v?p.folio:N(l),w=m.filter(e=>parseFloat(e.green_fee||0)+parseFloat(e.cart_fee||0)+parseFloat(e.club_fee||0)>0),T=`EFECTIVO`;if(w.length>0){let e=[...new Set(w.map(e=>e.payment_method||`EFECTIVO`))];T=e.length===1?e[0]:`MIXTO`}else T=m.some(e=>e.player_type===`CORTESIA`||e.payment_method===`CORTESIA`)?`CORTESIA`:`SOCIO`;let E=m.filter(e=>e.player_type===`CORTESIA`||e.payment_method===`CORTESIA`).map(e=>e.authorized_by).filter(Boolean),D=E.length>0?[...new Set(E)].join(`, `):null,O={folio:C,booking_date:l,booking_time:t,contact_name:o,contact_phone:i,group_type:_,players:m,total_players:s,total_holes:m[0]?.holes||18,total_carts:c,total_club_rentals:u,green_fee_total:d,cart_fee_total:f,club_rental_total:h,total_amount:g,payment_method:T,authorized_by:D,transaction_ref:m.map(e=>e.transaction_ref).filter(Boolean).join(`, `)||null,status:x,starting_hole:r,notes:a,paid_at:S,updated_at:new Date().toISOString()},k=e=>{let t={...e};return delete t.authorized_by,delete t.club_rental_total,delete t.total_club_rentals,t};try{let r=null;if(v){let{data:e,error:t}=await n.from(`tee_times`).update(O).eq(`id`,p.id).select().single();if(t&&t.message&&(t.message.includes(`authorized_by`)||t.message.includes(`club_rental_total`)||t.message.includes(`total_club_rentals`))){let r=await n.from(`tee_times`).update(k(O)).eq(`id`,p.id).select().single();e=r.data,t=r.error}r=!t&&e?e:B(p.id,O)}else{let{data:e,error:t}=await n.from(`tee_times`).insert([O]).select().single();if(t&&t.message&&(t.message.includes(`authorized_by`)||t.message.includes(`club_rental_total`)||t.message.includes(`total_club_rentals`))){let r=await n.from(`tee_times`).insert([k(O)]).select().single();e=r.data,t=r.error}!t&&e?r=e:(O.id=`tt_`+Math.random().toString(36).substr(2,9),O.created_at=new Date().toISOString(),r=z(O))}try{localStorage.setItem(`cgc_caddie_alert_sync`,JSON.stringify({timestamp:Date.now(),type:x,booking_id:r.id,folio:r.folio,contact_name:r.contact_name,total_players:r.total_players}))}catch{}p=r,await b(),y?window.showNotification(`¡Cambios Guardados!`,`Se actualizaron los datos de la salida de ${o} (Folio: ${C}).`,`success`):e===`PAID`?(window.printReceiptModal(r.id,r),window.showNotification(`¡Salida Autorizada & Pagada!`,`Se autorizó la salida para el grupo de ${o} (Folio: ${C}). El Caddie Master ya tiene la alerta en su pantalla.`,`success`)):window.showNotification(`¡Reserva Guardada!`,`Reserva telefónica registrada para las ${t} hrs a nombre de ${o}.`,`success`)}catch(e){console.error(`Error saving booking:`,e),window.showNotification(`Error`,`No se pudo guardar la información: `+e.message,`error`)}},window.cancelBooking=function(e){let t=f.find(t=>String(t.id)===String(e))||(p&&String(p.id)===String(e)?p:null);t&&window.showNotification(`Eliminar / Liberar Salida`,`¿Confirmas que deseas eliminar permanentemente la salida ${t.folio} (${t.contact_name}) y liberar el horario de las ${t.booking_time} hrs? (Solo Administrador)`,`confirm`,async()=>{try{let{error:e}=await n.from(`tee_times`).delete().eq(`id`,t.id);V(t.id);try{localStorage.setItem(`cgc_caddie_alert_sync`,JSON.stringify({timestamp:Date.now(),type:`CANCELLED`,booking_id:t.id,folio:t.folio})),window.dispatchEvent(new StorageEvent(`storage`,{key:`cgc_caddie_alert_sync`}))}catch{}window.showNotification(`Salida Eliminada`,`La salida ${t.folio} ha sido eliminada y el horario de las ${t.booking_time} hrs quedó disponible.`,`success`),p=null,w(t.booking_time||`08:00`),await b()}catch(e){console.error(`Error al eliminar salida:`,e),V(t.id),p=null,w(`08:00`),await b()}})};function k(){let e=document.getElementById(`corte-financial-summary`),t=document.getElementById(`corte-table-container`);if(!e||!t)return;let n=0,r=0,i=0,a=0,o=0,s=0,c=f.filter(e=>e.status===`PAID`||e.status===`ON_COURSE`||e.status===`COMPLETED`);if(c.forEach(e=>{let t=parseFloat(e.total_amount||0);s+=t,Array.isArray(e.players)&&e.players.length>0&&e.players.some(e=>e.payment_method)?e.players.forEach(t=>{let s=parseFloat(t.green_fee||0)+parseFloat(t.cart_fee||0),c=t.payment_method||e.payment_method||`EFECTIVO`;c===`EFECTIVO`?n+=s:c===`TARJETA`?r+=s:c===`TRANSFERENCIA`?i+=s:c===`CARGO_SOCIO`?a+=s:c===`CORTESIA`&&(o+=s)}):e.payment_method===`EFECTIVO`?n+=t:e.payment_method===`TARJETA`?r+=t:e.payment_method===`TRANSFERENCIA`?i+=t:e.payment_method===`CARGO_SOCIO`?a+=t:e.payment_method===`CORTESIA`&&(o+=t)}),e.innerHTML=`
        <div class="bg-slate-950/70 border border-slate-800 rounded-2xl p-4">
            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">💵 Efectivo en Caja</p>
            <h4 class="text-xl font-black text-white mt-1">$${n.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</h4>
        </div>
        <div class="bg-slate-950/70 border border-slate-800 rounded-2xl p-4">
            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">💳 Tarjeta / TPV</p>
            <h4 class="text-xl font-black text-white mt-1">$${r.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</h4>
        </div>
        <div class="bg-slate-950/70 border border-slate-800 rounded-2xl p-4">
            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">📲 SPEI / Transferencia</p>
            <h4 class="text-xl font-black text-white mt-1">$${i.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</h4>
        </div>
        <div class="bg-slate-950/70 border border-primary/40 bg-primary/5 rounded-2xl p-4">
            <p class="text-[10px] font-black text-primary uppercase tracking-widest">💰 Total Cobrado</p>
            <h4 class="text-2xl font-black text-emerald-400 mt-1">$${s.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</h4>
        </div>
    `,c.length===0){t.innerHTML=`
            <div class="py-12 text-center bg-slate-950/40 border border-slate-800 rounded-2xl">
                <span class="material-icons text-slate-600 text-4xl mb-2">point_of_sale</span>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-wider">Aún no hay cobros registrados el día de hoy.</p>
            </div>`;return}t.innerHTML=`
        <div class="bg-slate-950/60 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="bg-slate-900 border-b border-slate-800 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                        <th class="px-5 py-3.5">Folio / Hora</th>
                        <th class="px-5 py-3.5">Titular / Foursome</th>
                        <th class="px-5 py-3.5 text-center">Jugadores</th>
                        <th class="px-5 py-3.5 text-center">Carros</th>
                        <th class="px-5 py-3.5">Forma de Pago</th>
                        <th class="px-5 py-3.5 text-right">Monto Total</th>
                        <th class="px-5 py-3.5 text-right">Ticket</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/60">
                    ${c.map(e=>{let t=parseFloat(e.total_amount||0),n=Array.isArray(e.players)?e.players.map(e=>e.name).join(`, `):e.contact_name,r=e.payment_method===`MIXTO`?`<span class="px-2.5 py-1 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded-lg text-[10px] font-black">🔀 Pago Mixto</span>`:e.payment_method===`TARJETA`?`<span class="px-2.5 py-1 bg-blue-500/10 text-blue-400 border border-blue-500/30 rounded-lg text-[10px] font-black">💳 Tarjeta TPV</span>`:e.payment_method===`TRANSFERENCIA`?`<span class="px-2.5 py-1 bg-purple-500/10 text-purple-400 border border-purple-500/30 rounded-lg text-[10px] font-black">📲 SPEI</span>`:e.payment_method===`CARGO_SOCIO`?`<span class="px-2.5 py-1 bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 rounded-lg text-[10px] font-black">📑 Cargo Socio</span>`:e.payment_method===`CORTESIA`?`<span class="px-2.5 py-1 bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 rounded-lg text-[10px] font-black">⛳ Cortesía</span>`:`<span class="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-lg text-[10px] font-black">💵 Efectivo</span>`;return`
                            <tr class="hover:bg-slate-800/40 transition-colors">
                                <td class="px-5 py-3.5">
                                    <span class="font-black text-white bg-slate-800 px-2.5 py-1 rounded-md text-[11px] border border-slate-700">
                                        #${e.folio}
                                    </span>
                                    <p class="text-[10px] font-bold text-slate-400 mt-1">${e.booking_time} hrs</p>
                                </td>
                                <td class="px-5 py-3.5">
                                    <p class="font-black text-white uppercase text-sm">${e.contact_name}</p>
                                    <p class="text-[10px] text-slate-400 font-bold truncate max-w-xs mt-0.5">${n}</p>
                                </td>
                                <td class="px-5 py-3.5 text-center font-black text-slate-200">
                                    ${e.total_players} jug (${e.total_holes||18}h)
                                </td>
                                <td class="px-5 py-3.5 text-center font-black text-amber-400">
                                    ${e.total_carts>0?`🚗 ${e.total_carts}`:`—`}
                                </td>
                                <td class="px-5 py-3.5">
                                    ${r}
                                </td>
                                <td class="px-5 py-3.5 text-right font-black text-emerald-400 text-sm">
                                    $${t.toLocaleString(`es-MX`,{minimumFractionDigits:2})}
                                </td>
                                <td class="px-5 py-3.5 text-right">
                                    <button onclick="window.printReceiptModal('${e.id}')"
                                        class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg font-black text-[10px] uppercase transition-all border border-slate-700">
                                        <span class="material-icons text-xs">receipt</span> Ver
                                    </button>
                                </td>
                            </tr>`}).join(``)}
                </tbody>
            </table>
        </div>
    `}window.printDailyCorte=function(){window.print()},window.printReceiptModal=function(e,t){let n=f.find(t=>String(t.id)===String(e))||t;if(!n)return;let r=document.getElementById(`modal-receipt-print`);r||(r=document.createElement(`div`),r.id=`modal-receipt-print`,r.className=`fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in`,document.body.appendChild(r));let i=parseFloat(n.total_amount||0),a=F(n.booking_date),o=Array.isArray(n.players)?n.players:[],s=n.transaction_ref?n.transaction_ref:null,c={MIXTO:`🔀 Pago Mixto / Individual`,EFECTIVO:`💵 Efectivo en Caja`,TARJETA:`💳 Tarjeta Débito / Crédito (TPV)`,TRANSFERENCIA:`📲 Transferencia SPEI`,CARGO_SOCIO:`📑 Cargo a Cuenta de Socio`,CORTESIA:`⛳ Cortesía de la Directiva`}[n.payment_method]||n.payment_method||`EFECTIVO`;r.innerHTML=`
        <div class="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
            <!-- Header -->
            <div class="p-5 border-b border-slate-800 flex justify-between items-center bg-slate-950/80">
                <div class="flex items-center gap-3">
                    <img src="/logoclub.png" alt="Club de Golf Colima" class="h-10 w-10 rounded-xl object-contain bg-white p-1">
                    <div>
                        <h3 class="font-black uppercase text-white text-base leading-none">Pase de Salida & Recibo</h3>
                        <p class="text-[10px] text-slate-400 font-bold uppercase mt-1">Club de Golf Colima · Casa Club</p>
                    </div>
                </div>
                <button onclick="document.getElementById('modal-receipt-print').classList.add('hidden')" class="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all">
                    <span class="material-icons text-sm">close</span>
                </button>
            </div>

            <!-- Receipt Printable Content -->
            <div id="printable-receipt-area" class="p-6 overflow-y-auto custom-scrollbar space-y-5 bg-slate-950/60 text-slate-200">
                
                <!-- Ticket Badge -->
                <div class="text-center p-4 bg-slate-900 border-2 border-dashed border-slate-700 rounded-2xl space-y-1">
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Pase Oficial de Salida</p>
                    <h2 class="text-3xl font-black text-primary tracking-tight">${n.folio}</h2>
                    <p class="text-xs font-black text-emerald-400 uppercase">🟢 SALIDA AUTORIZADA AL CAMPO</p>
                </div>

                <!-- Details Grid -->
                <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-2 text-xs">
                    <div class="flex justify-between">
                        <span class="text-slate-400 font-bold">Fecha de Juego:</span>
                        <span class="font-black text-white uppercase">${a}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-slate-400 font-bold">Horario de Salida:</span>
                        <span class="font-black text-white text-sm bg-slate-800 px-2 py-0.5 rounded border border-slate-700">${n.booking_time} hrs (Hoyo #${n.starting_hole||1})</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-slate-400 font-bold">Titular del Grupo:</span>
                        <span class="font-black text-white uppercase">${n.contact_name}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-slate-400 font-bold">Forma de Pago:</span>
                        <span class="font-black text-emerald-400 uppercase">${c}</span>
                    </div>
                    ${s?`
                    <div class="flex justify-between">
                        <span class="text-slate-400 font-bold">Ref. / Aprobaciones:</span>
                        <span class="font-black text-blue-400 truncate max-w-[200px]">${s}</span>
                    </div>`:``}
                </div>

                <!-- Players Table -->
                <div class="space-y-2">
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Jugadores Registrados (${o.length}):</p>
                    <div class="bg-slate-900/80 border border-slate-800 rounded-xl divide-y divide-slate-800">
                        ${o.map((e,t)=>{let r=e.payment_method||n.payment_method||`EFECTIVO`,i={EFECTIVO:`💵 Efectivo`,TARJETA:`💳 Tarjeta ${e.transaction_ref?`(#${e.transaction_ref})`:``}`,TRANSFERENCIA:`📲 SPEI ${e.transaction_ref?`(#${e.transaction_ref})`:``}`,CARGO_SOCIO:`📑 Cargo Socio`,CORTESIA:`⛳ Cortesía Directiva`}[r]||r,a=parseFloat(e.green_fee||0)+parseFloat(e.cart_fee||0)+parseFloat(e.club_fee||0);return`
                                <div class="p-3 flex items-center justify-between text-xs">
                                    <div>
                                        <p class="font-black text-white uppercase">${t+1}. ${I(e.name||`Jugador #${t+1}`)}</p>
                                        <p class="text-[10px] text-slate-400 font-bold">
                                            ${e.is_member?`Socio #${e.member_number}`:e.convenio_name?`Convenio (${e.convenio_name})`:e.player_type===`CORTESIA`||e.payment_method===`CORTESIA`?`Cortesía Directiva`:`Invitado`}
                                            · ${e.holes||18} Hoyos ${e.has_cart?`· 🚗 Carrito`:``} ${e.has_clubs?`· 🏌️ Equipo`:``}
                                            <span class="text-primary font-bold ml-1">· ${i}</span>
                                        </p>
                                    </div>
                                    <span class="font-black text-slate-200">$${a.toLocaleString(`es-MX`,{minimumFractionDigits:2})}</span>
                                </div>
                            `}).join(``)}
                    </div>
                </div>

                <!-- Total -->
                <div class="p-4 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-between">
                    <div>
                        <p class="text-[10px] font-black uppercase text-slate-400 tracking-wider">Total Pagado</p>
                        <p class="text-[10px] text-slate-500 font-bold">I.V.A. Incluido</p>
                    </div>
                    <h3 class="text-2xl font-black text-emerald-400">$${i.toLocaleString(`es-MX`,{minimumFractionDigits:2})} MXN</h3>
                </div>

                <div class="text-center text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                    Presenta este folio en la caseta de Caddie Master para recibir tus carros y caddies asignados.
                </div>
            </div>

            <!-- Footer -->
            <div class="p-4 border-t border-slate-800 bg-slate-900 flex items-center justify-between gap-2 flex-wrap">
                <button type="button" onclick="document.getElementById('modal-receipt-print').classList.add('hidden')"
                    class="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-black text-xs uppercase">
                    Cerrar
                </button>
                <div class="flex items-center gap-2">
                    <button type="button" onclick="window.shareReceiptWhatsApp(${JSON.stringify(n).replace(/"/g,`&quot;`)})"
                        class="px-5 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-black text-xs uppercase flex items-center gap-1.5 shadow-lg shadow-emerald-600/20">
                        <span class="material-icons text-base">chat</span> WhatsApp
                    </button>
                    <button type="button" onclick="window.printReceiptWindow(${JSON.stringify(n).replace(/"/g,`&quot;`)})"
                        class="px-6 py-3 bg-primary hover:bg-primary/90 text-slate-950 rounded-xl font-black text-xs uppercase flex items-center gap-1.5 shadow-lg shadow-primary/20">
                        <span class="material-icons text-base">print</span> Imprimir Pase
                    </button>
                </div>
            </div>
        </div>
    `,r.classList.remove(`hidden`)},window.printReceiptWindow=function(e){if(typeof e==`string`)try{e=JSON.parse(e)}catch{return}let t=parseFloat(e.total_amount||0),n=Array.isArray(e.players)?e.players:[],r=e.transaction_ref||null,i=window.location.origin+`/logoclub.png`,a={EFECTIVO:`Efectivo en Caja`,TARJETA:`Tarjeta Débito / Crédito (TPV)`,TRANSFERENCIA:`Transferencia SPEI`,CARGO_SOCIO:`Cargo a Cuenta de Socio`,CORTESIA:`Cortesía / Directiva`}[e.payment_method]||e.payment_method||``,o=(()=>{try{return new Date(e.booking_date+`T00:00:00`).toLocaleDateString(`es-MX`,{weekday:`long`,day:`numeric`,month:`long`,year:`numeric`})}catch{return e.booking_date}})(),s=n.map((e,t)=>`
        <tr>
            <td style="padding:8px 0;border-bottom:1px solid #e5e7eb;">
                <strong>${t+1}. ${e.name}</strong><br>
                <small style="color:#6b7280;">${e.is_member?`Socio #`+e.member_number:e.player_type===`CORTESIA`||e.payment_method===`CORTESIA`?`⛳ Cortesía Directiva`+(e.authorized_by?` (Autorizó: `+e.authorized_by+`)`:``):`Invitado`} · ${e.holes||18} Hoyos${e.has_cart?` · 🚗 Carrito`:``}${e.has_clubs?` · 🏌️ Equipo`:``}</small>
            </td>
            <td style="padding:8px 0;border-bottom:1px solid #e5e7eb;text-align:right;font-weight:900;">
                $${(parseFloat(e.green_fee||0)+parseFloat(e.cart_fee||0)+parseFloat(e.club_fee||0)).toFixed(2)}
            </td>
        </tr>`).join(``),c=`<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Pase de Salida · ${e.folio}</title>
<style>
  @media print {
    body { -webkit-print-color-adjust: exact; print-color-adjust: exact; margin: 0; }
    .no-print { display: none !important; }
  }
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Arial, sans-serif; background: #fff; color: #111; margin: 0; padding: 24px; max-width: 400px; margin: 0 auto; }
  .header { display: flex; align-items: center; gap: 14px; border-bottom: 2px solid #16a34a; padding-bottom: 14px; margin-bottom: 16px; }
  .header img { width: 54px; height: 54px; object-fit: contain; }
  .header h1 { font-size: 15px; font-weight: 900; margin: 0; text-transform: uppercase; color: #111; }
  .header p { font-size: 11px; color: #6b7280; margin: 2px 0 0; text-transform: uppercase; font-weight: 700; }
  .folio-box { background: #f0fdf4; border: 2px dashed #16a34a; border-radius: 12px; text-align: center; padding: 14px; margin-bottom: 16px; }
  .folio-box .label { font-size: 10px; font-weight: 800; color: #6b7280; text-transform: uppercase; letter-spacing: 0.1em; }
  .folio-box .folio { font-size: 26px; font-weight: 900; color: #16a34a; letter-spacing: 0.05em; }
  .folio-box .status { font-size: 11px; font-weight: 800; color: #15803d; text-transform: uppercase; }
  .info-box { background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 10px; padding: 12px 14px; margin-bottom: 14px; }
  .info-row { display: flex; justify-content: space-between; align-items: center; font-size: 11px; padding: 3px 0; }
  .info-row .lbl { color: #6b7280; font-weight: 700; }
  .info-row .val { font-weight: 900; color: #111; text-transform: uppercase; }
  .info-row .val.green { color: #16a34a; }
  .info-row .val.blue { color: #2563eb; }
  .section-title { font-size: 10px; font-weight: 800; color: #6b7280; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 6px; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; }
  .total-box { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 10px; padding: 12px 14px; display: flex; justify-content: space-between; align-items: center; margin: 14px 0; }
  .total-box .t-label { font-size: 11px; font-weight: 800; color: #6b7280; text-transform: uppercase; }
  .total-box .t-label small { display: block; font-size: 10px; color: #9ca3af; font-weight: 600; }
  .total-box .t-amount { font-size: 22px; font-weight: 900; color: #16a34a; }
  .footer-note { font-size: 10px; color: #9ca3af; text-align: center; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 12px; }
  .print-btn { display: block; width: 100%; padding: 12px; background: #16a34a; color: #fff; border: none; border-radius: 10px; font-weight: 900; font-size: 13px; text-transform: uppercase; cursor: pointer; margin-top: 20px; }
</style>
</head>
<body>
  <div class="header">
    <img src="${i}" alt="Club de Golf Colima" onerror="this.style.display='none'">
    <div>
      <h1>Club de Golf Colima</h1>
      <p>Pase de Salida & Recibo · Casa Club</p>
    </div>
  </div>

  <div class="folio-box">
    <div class="label">Pase Oficial de Salida</div>
    <div class="folio">${e.folio}</div>
    <div class="status">🟢 Salida Autorizada al Campo</div>
  </div>

  <div class="info-box">
    <div class="info-row"><span class="lbl">Fecha de Juego:</span><span class="val">${o}</span></div>
    <div class="info-row"><span class="lbl">Horario de Salida:</span><span class="val">${e.booking_time} hrs · Hoyo #${e.starting_hole||1}</span></div>
    <div class="info-row"><span class="lbl">Titular del Grupo:</span><span class="val">${e.contact_name}</span></div>
    <div class="info-row"><span class="lbl">Forma de Pago:</span><span class="val green">${a}</span></div>
    ${r?`<div class="info-row"><span class="lbl">Ref. / Aprobación:</span><span class="val blue">${r}</span></div>`:``}
  </div>

  <div class="section-title">Jugadores Registrados (${n.length})</div>
  <table>
    <tbody>${s}</tbody>
  </table>

  <div class="total-box">
    <div class="t-label">Total Pagado <small>I.V.A. Incluido</small></div>
    <div class="t-amount">$${t.toLocaleString(`es-MX`,{minimumFractionDigits:2})} MXN</div>
  </div>

  <div class="footer-note">Presenta este folio en la caseta del Caddie Master<br>para recibir tus carros y caddies asignados.</div>

  <button class="print-btn no-print" onclick="window.print()">🖨️ Imprimir</button>
</body>
</html>`,l=window.open(``,`_blank`,`width=460,height=720,menubar=no,toolbar=no,location=no`);if(!l){window.showNotification(`Aviso`,`Permite las ventanas emergentes para este sitio e intenta nuevamente.`,`error`);return}l.document.write(c),l.document.close(),l.onload=()=>{l.focus(),l.print()}},window.shareReceiptWhatsApp=function(e){if(typeof e==`string`)try{e=JSON.parse(e)}catch{return}let t=parseFloat(e.total_amount||0),n=Array.isArray(e.players)?e.players:[],r=(()=>{try{return new Date(e.booking_date+`T00:00:00`).toLocaleDateString(`es-MX`,{weekday:`long`,day:`numeric`,month:`long`,year:`numeric`})}catch{return e.booking_date}})(),i={EFECTIVO:`Efectivo en Caja`,TARJETA:`Tarjeta Débito / Crédito (TPV)`,TRANSFERENCIA:`Transferencia SPEI`,CARGO_SOCIO:`Cargo a Cuenta de Socio`,CORTESIA:`Cortesía / Directiva`}[e.payment_method]||e.payment_method||``,a=n.map((e,t)=>`  ${t+1}. ${e.name} (${e.is_member?`Socio`:`Invitado`} · ${e.holes||18} hoyos${e.has_cart?` · 🚗`:``})`).join(`
`),o=[`🏌️ *Club de Golf Colima — Pase de Salida*`,``,`🎫 *Folio:* ${e.folio}`,`📅 *Fecha:* ${r}`,`⏰ *Horario:* ${e.booking_time} hrs · Hoyo #${e.starting_hole||1}`,`👤 *Titular:* ${e.contact_name}`,``,`👥 *Jugadores (${n.length}):*`,a,``,`💳 *Forma de pago:* ${i}`,e.transaction_ref?`🔖 *Referencia:* ${e.transaction_ref}`:``,`💰 *Total Pagado:* $${t.toLocaleString(`es-MX`,{minimumFractionDigits:2})} MXN`,``,`_Presenta este folio en la caseta del Caddie Master para recibir carros y caddies asignados._`,``,`⛳ Club de Golf Colima · Casa Club`].filter(e=>e!==``).join(`
`),s=`https://wa.me/?text=${encodeURIComponent(o)}`;window.open(s,`_blank`)};var A=`GENERAL`,j=null;window.openReceptionPriceConfigModal=function(){A=`GENERAL`,j=null,M()};function M(){let e=document.getElementById(`modal-price-config`);e||(e=document.createElement(`div`),e.id=`modal-price-config`,e.className=`fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in`,document.body.appendChild(e)),e.innerHTML=`
        <div class="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <!-- Header -->
            <div class="p-5 border-b border-slate-800 flex justify-between items-center bg-slate-950/80">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
                        <span class="material-icons">tune</span>
                    </div>
                    <div>
                        <h3 class="font-black uppercase text-white text-base leading-none">Tarifas & Convenios Predeterminados</h3>
                        <p class="text-[10px] text-slate-400 font-bold uppercase mt-1">Precios oficiales en terminal de cobro (Solo Administrador)</p>
                    </div>
                </div>
                <button onclick="document.getElementById('modal-price-config').classList.add('hidden')" class="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all">
                    <span class="material-icons text-sm">close</span>
                </button>
            </div>

            <!-- Tab Switcher -->
            <div class="flex border-b border-slate-800 bg-slate-950/60 p-2 gap-2">
                <button type="button" onclick="window.switchPriceConfigTab('GENERAL')"
                    class="flex-1 py-2.5 px-4 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${A===`GENERAL`?`bg-primary text-slate-950 shadow-md shadow-primary/20`:`text-slate-400 hover:text-white hover:bg-slate-800`}">
                    <span class="material-icons text-sm">payments</span> Tarifas Base (Invitados)
                </button>
                <button type="button" onclick="window.switchPriceConfigTab('CONVENIOS')"
                    class="flex-1 py-2.5 px-4 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${A===`CONVENIOS`?`bg-indigo-600 text-white shadow-md shadow-indigo-600/20`:`text-slate-400 hover:text-white hover:bg-slate-800`}">
                    <span class="material-icons text-sm">handshake</span> Convenios Interclubes (${s.length})
                </button>
            </div>

            <!-- Body Content -->
            <div class="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-5 text-xs">
                ${A===`GENERAL`?`
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="space-y-1.5 p-4 bg-slate-950/60 border border-slate-800 rounded-2xl">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Green Fee (Invitado) · Tarifa Única</label>
                            <div class="relative">
                                <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-400 font-black">$</span>
                                <input id="cfg-gf-18-guest" type="number" step="50" value="${o.greenFee18Guest}" class="w-full pl-8 pr-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white font-black text-sm focus:outline-none focus:border-primary">
                            </div>
                            <p class="text-[9px] text-slate-500 font-bold">Misma tarifa jueguen 9 o 18 hoyos</p>
                        </div>
                        <div class="space-y-1.5 p-4 bg-slate-950/60 border border-slate-800 rounded-2xl">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Renta Carrito · Tarifa Única</label>
                            <div class="relative">
                                <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-amber-400 font-black">$</span>
                                <input id="cfg-cart-18" type="number" step="50" value="${o.cart18}" class="w-full pl-8 pr-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white font-black text-sm focus:outline-none focus:border-primary">
                            </div>
                            <p class="text-[9px] text-slate-500 font-bold">Misma tarifa jueguen 9 o 18 hoyos</p>
                        </div>
                        <div class="space-y-1.5 p-4 bg-slate-950/60 border border-blue-500/30 rounded-2xl">
                            <label class="block text-[10px] font-black text-blue-400 uppercase tracking-widest flex items-center gap-1">
                                <span class="material-icons text-xs">sports_golf</span> Renta de Equipo (Palos)
                            </label>
                            <div class="relative">
                                <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-blue-400 font-black">$</span>
                                <input id="cfg-club-rental" type="number" step="50" value="${o.clubRentalFee||400}" class="w-full pl-8 pr-4 py-3 bg-slate-800 border border-blue-500/40 rounded-xl text-white font-black text-sm focus:outline-none focus:border-blue-400">
                            </div>
                            <p class="text-[9px] text-slate-500 font-bold">Costo por set de palos de renta ($400 base)</p>
                        </div>
                        <div class="space-y-1.5 p-4 bg-slate-950/60 border border-purple-500/30 rounded-2xl">
                            <label class="block text-[10px] font-black text-purple-400 uppercase tracking-widest flex items-center gap-1">
                                <span class="material-icons text-xs">sports_golf</span> Renta Tee de Práctica
                            </label>
                            <div class="relative">
                                <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-purple-400 font-black">$</span>
                                <input id="cfg-practice-tee" type="number" step="25" value="${o.practiceTeeFee||150}" class="w-full pl-8 pr-4 py-3 bg-slate-800 border border-purple-500/40 rounded-xl text-white font-black text-sm focus:outline-none focus:border-purple-400">
                            </div>
                            <p class="text-[9px] text-slate-500 font-bold">Acceso a área de tiro / práctica</p>
                        </div>
                        <div class="space-y-1.5 p-4 bg-slate-950/60 border border-teal-500/30 rounded-2xl sm:col-span-2">
                            <label class="block text-[10px] font-black text-teal-400 uppercase tracking-widest flex items-center gap-1">
                                <span class="material-icons text-xs">sports_baseball</span> Cubeta 100 Pelotas (Práctica)
                            </label>
                            <div class="relative">
                                <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-teal-400 font-black">$</span>
                                <input id="cfg-bucket-100" type="number" step="10" value="${o.bucket100Fee||120}" class="w-full pl-8 pr-4 py-3 bg-slate-800 border border-teal-500/40 rounded-xl text-white font-black text-sm focus:outline-none focus:border-teal-400">
                            </div>
                            <p class="text-[9px] text-slate-500 font-bold">Precio unitario por cubeta de 100 pelotas</p>
                        </div>
                    </div>
                `:`
                    <div class="space-y-4">
                        <!-- Add / Edit Convenio Box -->
                        <div class="p-4 bg-slate-950/80 border border-indigo-500/30 rounded-2xl space-y-3">
                            <h4 class="font-black uppercase text-white text-xs flex items-center gap-2">
                                <span class="material-icons text-indigo-400 text-sm">add_circle</span> ${j?`Editar Convenio`:`Nuevo Convenio Interclubes`}
                            </h4>
                            <div class="grid grid-cols-1 sm:grid-cols-12 gap-3">
                                <div class="sm:col-span-12">
                                    <label class="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Nombre del Club o Convenio *</label>
                                    <input id="conv-name" type="text" placeholder="Ej. Manzanillo Golf / Club Atlas" class="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white font-black text-xs focus:outline-none focus:border-indigo-400">
                                </div>
                                <div class="sm:col-span-6">
                                    <label class="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Green Fee Convenio ($)</label>
                                    <input id="conv-gf-18" type="number" step="50" placeholder="800" class="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-emerald-400 font-black text-xs text-right focus:outline-none focus:border-indigo-400">
                                </div>
                                <div class="sm:col-span-6">
                                    <label class="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Renta Carrito Convenio ($)</label>
                                    <input id="conv-cart-18" type="number" step="50" placeholder="500" class="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-amber-400 font-black text-xs text-right focus:outline-none focus:border-indigo-400">
                                </div>
                            </div>
                            <div class="flex justify-end gap-2 pt-2 border-t border-slate-800/80">
                                ${j?`
                                    <button type="button" onclick="window.cancelEditConvenio()" class="px-3.5 py-2 bg-slate-800 text-slate-400 hover:text-white rounded-xl font-bold text-xs uppercase">Cancelar</button>
                                `:``}
                                <button type="button" onclick="window.saveConvenioItem()" class="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-black text-xs uppercase flex items-center gap-1.5 shadow-md shadow-indigo-600/20">
                                    <span class="material-icons text-sm">save</span> ${j?`Actualizar`:`Guardar Convenio`}
                                </button>
                            </div>
                        </div>

                        <!-- Existing Convenios List -->
                        <div class="space-y-2">
                            <h4 class="text-[10px] font-black uppercase text-slate-400 tracking-wider">Convenios Registrados:</h4>
                            ${s.length===0?`
                                <div class="p-6 text-center bg-slate-950/40 border border-slate-800 rounded-2xl text-slate-500 font-bold uppercase text-xs">
                                    No hay convenios registrados aún. Agrega uno arriba.
                                </div>
                            `:`
                                <div class="space-y-2">
                                    ${s.map(e=>`
                                        <div class="p-3.5 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-slate-700 transition-all">
                                            <div class="space-y-1">
                                                <div class="flex items-center gap-2">
                                                    <span class="px-2 py-0.5 bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 rounded-md text-[9px] font-black uppercase">Convenio</span>
                                                    <h5 class="font-black text-white text-sm uppercase">${I(e.name)}</h5>
                                                </div>
                                                <div class="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 font-bold">
                                                    <span>Green Fee: <strong class="text-emerald-400 font-black">$${parseFloat(e.green_fee_18||0).toLocaleString()}</strong></span>
                                                    <span>Renta Carro: <strong class="text-amber-400 font-black">$${parseFloat(e.cart_fee_18||0).toLocaleString()}</strong></span>
                                                </div>
                                            </div>
                                            <div class="flex items-center gap-1.5 self-end sm:self-auto">
                                                <button type="button" onclick="window.startEditConvenio('${e.id}')" class="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition-all" title="Editar Convenio">
                                                    <span class="material-icons text-sm">edit</span>
                                                </button>
                                                <button type="button" onclick="window.deleteConvenioItem('${e.id}')" class="p-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 rounded-xl transition-all" title="Eliminar Convenio">
                                                    <span class="material-icons text-sm">delete</span>
                                                </button>
                                            </div>
                                        </div>
                                    `).join(``)}
                                </div>
                            `}
                        </div>
                    </div>
                `}
            </div>

            <!-- Modal Footer -->
            <div class="p-4 border-t border-slate-800 bg-slate-950 flex justify-end gap-2">
                <button type="button" onclick="document.getElementById('modal-price-config').classList.add('hidden')" class="px-5 py-3 bg-slate-800 text-slate-300 rounded-xl font-black text-xs uppercase">Cerrar</button>
                ${A===`GENERAL`?`
                    <button type="button" onclick="window.savePriceConfig()" class="px-6 py-3 bg-primary text-slate-950 rounded-xl font-black text-xs uppercase">Guardar Tarifas</button>
                `:``}
            </div>
        </div>
    `,e.classList.remove(`hidden`)}window.switchPriceConfigTab=function(e){A=e,M()},window.savePriceConfig=function(){o.greenFee18Guest=parseFloat(document.getElementById(`cfg-gf-18-guest`)?.value)||1200,o.cart18=parseFloat(document.getElementById(`cfg-cart-18`)?.value)||500,o.clubRentalFee=parseFloat(document.getElementById(`cfg-club-rental`)?.value)||400,o.practiceTeeFee=parseFloat(document.getElementById(`cfg-practice-tee`)?.value)||150,o.bucket100Fee=parseFloat(document.getElementById(`cfg-bucket-100`)?.value)||120,o.greenFee9Guest=o.greenFee18Guest,o.cart9=o.cart18,localStorage.setItem(`cgc_reception_prices`,JSON.stringify(o)),document.getElementById(`modal-price-config`)?.classList.add(`hidden`),window.showNotification(`Tarifas Guardadas`,`Las nuevas tarifas base se aplicaron a los próximos registros.`,`success`)},window.startEditConvenio=function(e){let t=s.find(t=>String(t.id)===String(e));if(!t)return;j=e,M();let n=document.getElementById(`conv-name`),r=document.getElementById(`conv-gf-18`),i=document.getElementById(`conv-cart-18`);n&&(n.value=t.name||``),r&&(r.value=t.green_fee_18||0),i&&(i.value=t.cart_fee_18||0)},window.cancelEditConvenio=function(){j=null,M()},window.saveConvenioItem=async function(){let e=document.getElementById(`conv-name`)?.value.trim(),t=parseFloat(document.getElementById(`conv-gf-18`)?.value)||0,r=parseFloat(document.getElementById(`conv-cart-18`)?.value)||0;if(!e){window.showNotification(`Nombre Requerido`,`Ingresa el nombre del convenio o club.`,`error`);return}let i={name:e,green_fee_18:t,green_fee_9:t,cart_fee_18:r,cart_fee_9:r,is_active:!0,updated_at:new Date().toISOString()};if(j){let t=s.findIndex(e=>String(e.id)===String(j));t!==-1&&(s[t]={...s[t],...i});try{await n.from(`convenios`).update(i).eq(`id`,j)}catch(e){console.warn(`Supabase update convenio error:`,e)}window.showNotification(`Convenio Actualizado`,`El convenio "${e}" ha sido actualizado.`,`success`),j=null}else{i.id=`conv_`+Math.random().toString(36).substr(2,9),i.created_at=new Date().toISOString();try{let{data:e}=await n.from(`convenios`).insert([i]).select().single();e&&e.id&&(i.id=e.id)}catch(e){console.warn(`Supabase insert convenio error:`,e)}s.push(i),window.showNotification(`Convenio Creado`,`El convenio "${e}" ha sido registrado exitosamente.`,`success`)}localStorage.setItem(`cgc_convenios`,JSON.stringify(s)),M(),E()},window.deleteConvenioItem=async function(e){if(confirm(`¿Estás seguro de que deseas eliminar este convenio?`)){s=s.filter(t=>String(t.id)!==String(e));try{await n.from(`convenios`).delete().eq(`id`,e)}catch(e){console.warn(`Supabase delete convenio error:`,e)}localStorage.setItem(`cgc_convenios`,JSON.stringify(s)),window.showNotification(`Convenio Eliminado`,`El convenio ha sido retirado.`,`info`),M(),E()}},window.toggleTransactionField=function(e){window._posPaymentMethod=e;let t=document.getElementById(`pos-transaction-field`),n=t?.querySelector(`label`),r=document.getElementById(`pos-transaction-ref`);t&&([`TARJETA`,`TRANSFERENCIA`].includes(e)?(t.classList.remove(`hidden`),n&&(n.textContent=e===`TRANSFERENCIA`?`# Referencia / Folio SPEI *`:`# Aprobación / Referencia TPV *`),r&&(r.placeholder=e===`TRANSFERENCIA`?`Ej. 123456789012`:`Ej. 481920`)):(t.classList.add(`hidden`),r&&(r.value=``))),e===`CORTESIA`?(m.forEach(e=>{e.green_fee=0,e.has_cart?(e.cart_fee===void 0||e.cart_fee===null)&&(e.cart_fee=o.cart18):e.cart_fee=0}),E()):(m.forEach(e=>{let t=e.player_type||(e.is_member?`MEMBER`:e.convenio_id?`CONVENIO`:`GUEST`),n=!!e.has_cart;if(t===`MEMBER`)e.green_fee=0,e.cart_fee=n?o.cart18:0;else if(t===`CONVENIO`){let t=s.find(t=>String(t.id)===String(e.convenio_id))||s[0];e.green_fee=t&&parseFloat(t.green_fee_18)||o.greenFee18Guest,e.cart_fee=n?t&&parseFloat(t.cart_fee_18)||o.cart18:0}else e.green_fee=o.greenFee18Guest,e.cart_fee=n?o.cart18:0}),E())};function N(e){return`CC-${e.replace(/-/g,``)}-${Math.floor(100+Math.random()*900)}`}function P(){return`CC-${l.replace(/-/g,``)}-...`}function F(e){try{return new Date(e+`T00:00:00`).toLocaleDateString(`es-MX`,{weekday:`long`,day:`numeric`,month:`long`,year:`numeric`})}catch{return e}}function I(e){return e?String(e).replace(/"/g,`&quot;`).replace(/'/g,`&#39;`):``}function L(e){try{let t=localStorage.getItem(`cgc_tee_times_${e}`);return t?JSON.parse(t):[]}catch{return[]}}function R(e,t){try{localStorage.setItem(`cgc_tee_times_${e}`,JSON.stringify(t))}catch{}}function z(e){let t=L(e.booking_date);return t.push(e),R(e.booking_date,t),e}function B(e,t){let n=L(l),r=n.findIndex(t=>String(t.id)===String(e));return r===-1?t:(n[r]={...n[r],...t},R(l,n),n[r])}function V(e){let t=L(l).filter(t=>String(t.id)!==String(e));R(l,t)}window.setReceptionDate=function(e){e&&(l=e,b())},window.stepReceptionDate=function(e){let t=new Date(l+`T00:00:00`);t.setDate(t.getDate()+e),l=t.toISOString().split(`T`)[0],b()};async function H(){let e=document.getElementById(`reservas-list-container`);if(!e)return;e.innerHTML=`<div class="py-10 text-center"><div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div></div>`;let t=[];try{let e=c(),{data:r,error:i}=await n.from(`tee_times`).select(`*`).gte(`booking_date`,e).in(`status`,[`RESERVED`,`PAID`]).order(`booking_date`,{ascending:!0}).order(`booking_time`,{ascending:!0});!i&&r&&(t=r)}catch(e){console.warn(`Reservas fallback to local:`,e)}if(t.length===0){let e=new Date;for(let n=0;n<=30;n++){let r=new Date(e);r.setDate(r.getDate()+n),L(c(r)).forEach(e=>{(e.status===`RESERVED`||e.status===`PAID`)&&t.push(e)})}}let r=document.getElementById(`tab-reservas-badge`);if(r&&(r.textContent=t.length),t.length===0){e.innerHTML=`
            <div class="py-16 text-center text-slate-400">
                <span class="material-icons text-5xl text-slate-700 block mb-3">event_busy</span>
                <p class="font-black text-sm uppercase tracking-wider">Sin reservas pendientes</p>
                <p class="text-xs mt-1">No hay grupos reservados para los próximos días.</p>
            </div>`;return}let i={};t.forEach(e=>{let t=e.booking_date;i[t]||(i[t]=[]),i[t].push(e)});let a={RESERVED:{dot:`bg-amber-400`,text:`text-amber-400`,badge:`bg-amber-500/15 border-amber-500/30`,label:`🟡 Reserva Tel.`},PAID:{dot:`bg-blue-400`,text:`text-blue-400`,badge:`bg-blue-500/15 border-blue-500/30`,label:`🔵 Pagado / En Tee`}};e.innerHTML=Object.entries(i).map(([e,t])=>{let n=F(e),r=t.map(e=>{let t=a[e.status]||a.RESERVED,n=Array.isArray(e.players)?e.players.map(e=>`<span class="px-2 py-0.5 bg-slate-800 border border-slate-700 rounded-lg text-[10px] font-bold text-slate-200">${I(e.name)||`Sin nombre`}</span>`).join(``):`<span class="px-2 py-0.5 bg-slate-800 border border-slate-700 rounded-lg text-[10px] font-bold text-slate-200">${I(e.contact_name)||`Sin nombre`}</span>`;return`
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-slate-800/60 border border-slate-700/60 rounded-2xl hover:border-slate-600 transition-all">
                    <div class="flex items-start gap-4">
                        <div class="flex flex-col items-center justify-center bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 shrink-0 min-w-[64px] text-center">
                            <span class="font-black text-base text-white leading-none">${e.booking_time||`--:--`}</span>
                            <span class="text-[9px] text-slate-400 font-bold uppercase mt-0.5">hrs</span>
                        </div>
                        <div class="space-y-1.5 min-w-0">
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="font-black text-white text-sm uppercase">${I(e.contact_name)||`Grupo sin nombre`}</span>
                                <span class="px-2 py-0.5 rounded-lg text-[9px] font-black uppercase border ${t.badge} ${t.text}">${t.label}</span>
                                <span class="text-[10px] font-bold text-slate-400">${e.total_players||1} jugador${(e.total_players||1)>1?`es`:``}</span>
                            </div>
                            <div class="flex flex-wrap gap-1">
                                ${n}
                            </div>
                            <div class="flex items-center gap-3 text-[10px] font-bold text-slate-400 flex-wrap">
                                <span class="flex items-center gap-1"><span class="material-icons text-slate-500" style="font-size:12px">golf_course</span> ${e.total_holes||18} Hoyos</span>
                                ${e.total_carts?`<span class="flex items-center gap-1"><span class="material-icons text-amber-400/70" style="font-size:12px">electric_car</span> ${e.total_carts} Carrito${e.total_carts>1?`s`:``}</span>`:``}
                                ${e.folio?`<span class="text-slate-500">Folio: ${e.folio.split(`-`).pop()}</span>`:``}
                                ${e.contact_phone?`<span class="flex items-center gap-1"><span class="material-icons text-slate-500" style="font-size:12px">phone</span> ${I(e.contact_phone)}</span>`:``}
                            </div>
                        </div>
                    </div>
                    <div class="flex items-center gap-2 shrink-0">
                        <button onclick="window.setReceptionDate('${e.booking_date}'); window.selectSlotForBooking('${e.booking_time}', '${e.id}'); document.getElementById('tab-reception-slots').click();"
                            class="px-3.5 py-2 bg-primary/20 hover:bg-primary/30 border border-primary/40 text-primary rounded-xl text-[11px] font-black uppercase tracking-wider transition-all flex items-center gap-1">
                            <span class="material-icons text-sm">open_in_new</span> Ver
                        </button>
                    </div>
                </div>`}).join(``);return`
            <div class="space-y-2">
                <div class="flex items-center gap-3">
                    <span class="material-icons text-primary text-base">calendar_today</span>
                    <h4 class="font-black text-white uppercase text-sm tracking-wider">${n}</h4>
                    <span class="px-2.5 py-0.5 bg-slate-800 rounded-full text-[10px] font-black text-slate-300 border border-slate-700">${t.length} reserva${t.length>1?`s`:``}</span>
                </div>
                <div class="space-y-2 pl-6 border-l-2 border-slate-800">${r}</div>
            </div>`}).join(``)}window.refreshReservasView=function(){H()};var U={isMember:!1,memberId:null,memberNumber:``,customerName:``,customerPhone:``,hasTeePractice:!0,hasClubRental:!1,bucketsCount:1,paymentMethod:`EFECTIVO`,transactionRef:``,authorizedBy:``,notes:``,printTicket:!0};window.openDrivingRangeModal=function(){U={isMember:!1,memberId:null,memberNumber:``,customerName:``,customerPhone:``,hasTeePractice:!0,hasClubRental:!1,bucketsCount:1,paymentMethod:`EFECTIVO`,transactionRef:``,authorizedBy:``,notes:``,printTicket:!0},W()},window.closeDrivingRangeModal=function(){let e=document.getElementById(`modal-driving-range-pos`);e&&e.classList.add(`hidden`)};function W(){let e=document.getElementById(`modal-driving-range-pos`);e||(e=document.createElement(`div`),e.id=`modal-driving-range-pos`,e.className=`fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in`,document.body.appendChild(e));let t=U.hasTeePractice?parseFloat(o.practiceTeeFee)||150:0,n=U.hasClubRental?parseFloat(o.clubRentalFee)||400:0,r=parseFloat(o.bucket100Fee)||120,i=U.bucketsCount*r,a=U.paymentMethod===`CORTESIA`,s=a?0:t+n+i;e.innerHTML=`
        <div class="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            
            <!-- Header -->
            <div class="p-5 border-b border-slate-800 flex justify-between items-center bg-slate-950/80">
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 rounded-2xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
                        <span class="material-icons text-2xl">sports_golf</span>
                    </div>
                    <div>
                        <h3 class="font-black uppercase text-white text-base leading-tight">Cobro de Práctica & Cubetas</h3>
                        <p class="text-[10px] text-slate-400 font-bold uppercase mt-0.5">Acceso a Driving Range & Vale para Caddie Master</p>
                    </div>
                </div>
                <button type="button" onclick="window.closeDrivingRangeModal()" class="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all">
                    <span class="material-icons text-base">close</span>
                </button>
            </div>

            <!-- Body Content -->
            <div class="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-5 text-xs">
                
                <!-- 1. Tipo de Cliente: Visitante vs Socio -->
                <div class="space-y-2">
                    <div class="flex items-center justify-between">
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Tipo de Cliente *</label>
                        <div class="inline-flex rounded-xl bg-slate-950 p-1 border border-slate-800 text-[10px] font-black">
                            <button type="button" onclick="window.setDRCustomerType(false)"
                                class="px-3 py-1.5 rounded-lg transition-all ${U.isMember?`text-slate-400 hover:text-white`:`bg-purple-600 text-white shadow-md`}">
                                Visitante / No Socio
                            </button>
                            <button type="button" onclick="window.setDRCustomerType(true)"
                                class="px-3 py-1.5 rounded-lg transition-all ${U.isMember?`bg-emerald-500 text-slate-950 shadow-md font-black`:`text-slate-400 hover:text-white`}">
                                Socio del Club
                            </button>
                        </div>
                    </div>

                    ${U.isMember?`
                        <div class="space-y-1">
                            <div class="relative">
                                <input type="text"
                                    id="dr-member-input"
                                    list="members-autocomplete-list"
                                    value="${I(U.customerName||``)}"
                                    placeholder="Escribe el nombre o número de socio..."
                                    autocomplete="off"
                                    oninput="window.onDRMemberInput(this.value)"
                                    class="w-full px-4 py-3 bg-slate-800 border ${U.memberId?`border-emerald-500 text-emerald-300`:`border-slate-700 text-white`} rounded-xl text-xs font-black uppercase placeholder:normal-case placeholder:text-slate-500 focus:outline-none focus:border-primary">
                                ${U.memberId?`
                                    <span class="absolute right-3 top-1/2 -translate-y-1/2 px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded text-[9px] font-black">
                                        Socio #${U.memberNumber}
                                    </span>
                                `:``}
                            </div>
                        </div>
                    `:`
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                                <label class="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Nombre Completo *</label>
                                <input type="text" value="${I(U.customerName||``)}"
                                    placeholder="Ej. Ing. Roberto Gómez"
                                    oninput="window.setDRCustomerName(this.value)"
                                    class="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white placeholder:text-slate-500 focus:outline-none focus:border-purple-400">
                            </div>
                            <div>
                                <label class="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Teléfono (Opcional)</label>
                                <input type="tel" value="${I(U.customerPhone||``)}"
                                    placeholder="Ej. 312 123 4567"
                                    oninput="window.setDRCustomerPhone(this.value)"
                                    class="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white placeholder:text-slate-500 focus:outline-none focus:border-purple-400">
                            </div>
                        </div>
                    `}
                </div>

                <!-- 2. Conceptos a Cobrar -->
                <div class="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl space-y-3">
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                        <span class="material-icons text-sm text-purple-400">checklist</span> Conceptos de Práctica
                    </p>

                    <!-- Renta de Tee de Práctica -->
                    <div class="flex items-center justify-between p-3 bg-slate-900 border ${U.hasTeePractice?`border-purple-500/40 bg-purple-950/10`:`border-slate-800`} rounded-xl transition-all">
                        <label class="flex items-center gap-3 cursor-pointer select-none">
                            <input type="checkbox" ${U.hasTeePractice?`checked`:``}
                                onchange="window.setDRTeePractice(this.checked)"
                                class="w-4 h-4 rounded text-purple-600 focus:ring-0 focus:outline-none bg-slate-800 border-slate-700">
                            <div>
                                <p class="text-xs font-black text-white">Renta de Tee de Práctica</p>
                                <p class="text-[10px] text-slate-400 font-bold">Uso y acceso a tapete / pasto de tiro</p>
                            </div>
                        </label>
                        <span class="text-sm font-black text-purple-400">
                            $${(parseFloat(o.practiceTeeFee)||150).toLocaleString(`es-MX`,{minimumFractionDigits:2})}
                        </span>
                    </div>

                    <!-- Renta de Equipo (Palos) -->
                    <div class="flex items-center justify-between p-3 bg-slate-900 border ${U.hasClubRental?`border-blue-500/40 bg-blue-950/10`:`border-slate-800`} rounded-xl transition-all">
                        <label class="flex items-center gap-3 cursor-pointer select-none">
                            <input type="checkbox" ${U.hasClubRental?`checked`:``}
                                onchange="window.setDRClubRental(this.checked)"
                                class="w-4 h-4 rounded text-blue-600 focus:ring-0 focus:outline-none bg-slate-800 border-slate-700">
                            <div>
                                <p class="text-xs font-black text-white flex items-center gap-1.5">
                                    <span class="material-icons text-blue-400 text-sm">sports_golf</span> Renta de Equipo (Palos)
                                </p>
                                <p class="text-[10px] text-slate-400 font-bold">Set de bastones para la sesión de práctica</p>
                            </div>
                        </label>
                        <span class="text-sm font-black text-blue-400">
                            $${(parseFloat(o.clubRentalFee)||400).toLocaleString(`es-MX`,{minimumFractionDigits:2})}
                        </span>
                    </div>

                    <!-- Cubetas de 100 Pelotas Stepper -->
                    <div class="p-3 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between gap-4">
                        <div>
                            <p class="text-xs font-black text-white flex items-center gap-1.5">
                                <span class="material-icons text-teal-400 text-sm">sports_baseball</span> Cubeta(s) de 100 Pelotas
                            </p>
                            <p class="text-[10px] text-slate-400 font-bold">
                                $${r.toLocaleString(`es-MX`,{minimumFractionDigits:2})} c/u (${U.bucketsCount*100} pelotas en total)
                            </p>
                        </div>

                        <div class="flex items-center gap-2">
                            <button type="button" onclick="window.setDRBucketsCount(-1)"
                                class="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-black text-sm flex items-center justify-center transition-all border border-slate-700">
                                -
                            </button>
                            <span class="w-10 text-center font-black text-base text-teal-400">
                                ${U.bucketsCount}
                            </span>
                            <button type="button" onclick="window.setDRBucketsCount(1)"
                                class="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-black text-sm flex items-center justify-center transition-all border border-slate-700">
                                +
                            </button>
                        </div>
                    </div>
                </div>

                <!-- 3. Forma de Pago -->
                <div class="space-y-3">
                    <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Forma de Pago *</label>
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        <button type="button" onclick="window.setDRPaymentMethod('EFECTIVO')"
                            class="p-2.5 rounded-xl border text-center transition-all ${U.paymentMethod===`EFECTIVO`?`bg-emerald-500/20 border-emerald-500 text-emerald-400 font-black`:`bg-slate-950 border-slate-800 text-slate-400 hover:text-white`}">
                            💵 Efectivo
                        </button>
                        <button type="button" onclick="window.setDRPaymentMethod('TARJETA')"
                            class="p-2.5 rounded-xl border text-center transition-all ${U.paymentMethod===`TARJETA`?`bg-blue-500/20 border-blue-500 text-blue-400 font-black`:`bg-slate-950 border-slate-800 text-slate-400 hover:text-white`}">
                            💳 Tarjeta TPV
                        </button>
                        <button type="button" onclick="window.setDRPaymentMethod('TRANSFERENCIA')"
                            class="p-2.5 rounded-xl border text-center transition-all ${U.paymentMethod===`TRANSFERENCIA`?`bg-indigo-500/20 border-indigo-500 text-indigo-400 font-black`:`bg-slate-950 border-slate-800 text-slate-400 hover:text-white`}">
                            📲 SPEI
                        </button>
                        <button type="button" onclick="window.setDRPaymentMethod('CORTESIA')"
                            class="p-2.5 rounded-xl border text-center transition-all ${U.paymentMethod===`CORTESIA`?`bg-purple-500/20 border-purple-500 text-purple-300 font-black`:`bg-slate-950 border-slate-800 text-slate-400 hover:text-white`}">
                            ⛳ Cortesía
                        </button>
                    </div>

                    ${U.paymentMethod===`TARJETA`||U.paymentMethod===`TRANSFERENCIA`?`
                        <div class="pt-1">
                            <label class="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">
                                ${U.paymentMethod===`TRANSFERENCIA`?`# Folio SPEI *`:`# Referencia / Aprobación TPV *`}
                            </label>
                            <input type="text" value="${I(U.transactionRef||``)}"
                                placeholder="Ej. 94820194"
                                oninput="window.setDRTransactionRef(this.value)"
                                class="w-full px-3.5 py-2.5 bg-slate-800 border border-blue-500/50 rounded-xl text-xs font-bold text-white focus:outline-none focus:border-blue-400">
                        </div>
                    `:U.paymentMethod===`CORTESIA`?`
                        <div class="pt-1">
                            <label class="block text-[9px] font-black text-amber-400 uppercase tracking-widest mb-1 flex items-center gap-1">
                                <span class="material-icons text-xs">verified_user</span> ¿Quién Autoriza la Cortesía? *
                            </label>
                            <input type="text" value="${I(U.authorizedBy||``)}"
                                placeholder="Ej. Presidente / Directiva"
                                oninput="window.setDRAuthorizedBy(this.value)"
                                class="w-full px-3.5 py-2.5 bg-slate-800 border border-amber-500/50 rounded-xl text-xs font-black text-amber-300 focus:outline-none focus:border-amber-400">
                        </div>
                    `:``}
                </div>

                <!-- 4. Notas -->
                <div>
                    <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Notas u Observaciones (Opcional)</label>
                    <input type="text" value="${I(U.notes||``)}"
                        placeholder="Ej. Alumno con Pro de Golf, sesión vespertina"
                        oninput="window.setDRNotes(this.value)"
                        class="w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white placeholder:text-slate-500 focus:outline-none focus:border-purple-400">
                </div>

                <!-- 5. Resumen Total -->
                <div class="p-4 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-between">
                    <div>
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total a Cobrar</p>
                        <p class="text-xs text-slate-400 font-bold mt-0.5">
                            ${U.hasTeePractice?`Tee`:``} ${U.hasClubRental?`+ Equipo`:``} ${(U.hasTeePractice||U.hasClubRental)&&U.bucketsCount>0?`+`:``} ${U.bucketsCount>0?`${U.bucketsCount} cubeta(s)`:``}
                        </p>
                    </div>
                    <div class="text-right">
                        <span class="text-2xl font-black ${a?`text-purple-400`:`text-emerald-400`}">
                            $${s.toLocaleString(`es-MX`,{minimumFractionDigits:2})}
                        </span>
                        <p class="text-[9px] font-black text-slate-500 uppercase">${U.paymentMethod}</p>
                    </div>
                </div>

                <!-- Print Ticket Toggle -->
                <label class="flex items-center gap-2 px-1 cursor-pointer select-none text-slate-300">
                    <input type="checkbox" ${U.printTicket?`checked`:``}
                        onchange="drState.printTicket = this.checked;"
                        class="w-4 h-4 rounded text-purple-600 focus:ring-0 bg-slate-800 border-slate-700">
                    <span class="text-xs font-bold">🖨️ Imprimir ticket / vale de pelotas al guardar</span>
                </label>

            </div>

            <!-- Modal Footer -->
            <div class="p-4 border-t border-slate-800 bg-slate-950 flex justify-end gap-2">
                <button type="button" onclick="window.closeDrivingRangeModal()"
                    class="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-black text-xs uppercase transition-all">
                    Cancelar
                </button>
                <button type="button" onclick="window.saveDrivingRangeSession()"
                    class="px-6 py-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-black text-xs uppercase flex items-center gap-2 shadow-xl shadow-purple-600/20 active:scale-95 transition-all">
                    <span class="material-icons text-sm">payments</span> Cobrar & Enviar a Caddie Master
                </button>
            </div>
        </div>
    `,e.classList.remove(`hidden`)}window.setDRCustomerType=function(e){U.isMember=e,U.customerName=``,U.memberId=null,U.memberNumber=``,W(),e&&setTimeout(()=>document.getElementById(`dr-member-input`)?.focus(),50)},window.onDRMemberInput=function(e){U.customerName=e;let t=(e||``).trim().toLowerCase(),n=d.find(e=>(e.name||``).toLowerCase()===t)||d.find(e=>(e.name||``).toLowerCase().includes(t));n?(U.memberId=n.id,U.memberNumber=n.member_number,U.customerName=n.name):(U.memberId=null,U.memberNumber=``),W()},window.setDRCustomerName=function(e){U.customerName=e},window.setDRCustomerPhone=function(e){U.customerPhone=e},window.setDRTeePractice=function(e){U.hasTeePractice=e,W()},window.setDRClubRental=function(e){U.hasClubRental=e,W()},window.setDRBucketsCount=function(e){let t=U.bucketsCount+e;t<0||(U.bucketsCount=t,W())},window.setDRPaymentMethod=function(e){U.paymentMethod=e,W()},window.setDRTransactionRef=function(e){U.transactionRef=e},window.setDRAuthorizedBy=function(e){U.authorizedBy=e},window.setDRNotes=function(e){U.notes=e},window.saveDrivingRangeSession=async function(){if(!U.customerName||U.customerName.trim()===``){window.showNotification?.(`Nombre Requerido`,`Ingresa el nombre del socio o visitante.`,`error`);return}if(!U.hasTeePractice&&!U.hasClubRental&&U.bucketsCount<=0){window.showNotification?.(`Conceptos Requeridos`,`Selecciona al menos un concepto (Tee, Equipo o Cubetas).`,`error`);return}if(U.paymentMethod===`CORTESIA`&&(!U.authorizedBy||!U.authorizedBy.trim())){window.showNotification?.(`Autorización Requerida`,`Ingresa el nombre de quién autoriza la cortesía.`,`error`);return}let e=U.hasTeePractice?parseFloat(o.practiceTeeFee)||150:0,t=U.hasClubRental?parseFloat(o.clubRentalFee)||400:0,r=parseFloat(o.bucket100Fee)||120,i=U.bucketsCount*r,a=U.paymentMethod===`CORTESIA`,s=a?0:e+t+i,c=String(Math.floor(Math.random()*900)+100),u=`PRAC-${l.replace(/-/g,``)}-${c}`,d={folio:u,session_date:l,created_at:new Date().toISOString(),customer_name:U.customerName.trim(),is_member:U.isMember,member_id:U.memberId||null,has_tee_practice:U.hasTeePractice,tee_practice_fee:e,has_club_rental:U.hasClubRental,club_rental_fee:t,buckets_count:U.bucketsCount,bucket_unit_price:r,total_buckets_fee:i,total_amount:s,payment_method:U.paymentMethod,transaction_ref:U.transactionRef||null,authorized_by:a?U.authorizedBy.trim():null,status:`PAID`,balls_delivered:!1,notes:U.notes||null};try{let{data:e,error:t}=await n.from(`driving_range_sessions`).insert([d]).select().single();if(t&&(t.message.includes(`has_club_rental`)||t.message.includes(`club_rental_fee`))){let r={...d};delete r.has_club_rental,delete r.club_rental_fee;let i=await n.from(`driving_range_sessions`).insert([r]).select().single();e=i.data,t=i.error}!t&&e&&e.id&&(d.id=e.id)}catch(e){console.warn(`Driving range session save exception:`,e)}try{let e=`cgc_driving_range_${l}`,t=JSON.parse(localStorage.getItem(e)||`[]`);t.unshift(d),localStorage.setItem(e,JSON.stringify(t)),localStorage.setItem(`cgc_driving_range_sync`,String(Date.now())),window.dispatchEvent(new StorageEvent(`storage`,{key:`cgc_driving_range_sync`}))}catch(e){console.warn(`Local storage sync error:`,e)}U.printTicket&&window.printDrivingRangeTicket(d),window.closeDrivingRangeModal(),window.showNotification?.(`Cobro Registrado`,`Folio #${u} enviado a Caddie Master.`,`success`)},window.printDrivingRangeTicket=function(e){let t=window.open(``,`_blank`,`width=380,height=600`);if(!t)return;let n=new Date().toLocaleTimeString(`es-MX`,{hour:`2-digit`,minute:`2-digit`}),r=e.payment_method===`CORTESIA`;t.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Ticket Práctica #${e.folio}</title>
            <style>
                body { font-family: monospace, sans-serif; font-size: 12px; margin: 0; padding: 15px; color: #000; }
                .text-center { text-align: center; }
                .text-right { text-align: right; }
                .bold { font-weight: bold; }
                .divider { border-top: 1px dashed #000; margin: 10px 0; }
                .box-vale { border: 2px dashed #000; padding: 10px; margin-top: 15px; text-align: center; }
                table { width: 100%; font-size: 12px; }
                @media print {
                    @page { margin: 0; size: 80mm auto; }
                    body { padding: 8px; }
                }
            </style>
        </head>
        <body onload="window.print();">
            <div class="text-center">
                <h3 style="margin: 0; font-size: 15px;">CLUB DE GOLF COLIMA</h3>
                <p style="margin: 3px 0 0 0; font-size: 10px;">CASA CLUB · TEE DE PRÁCTICA</p>
                <div class="divider"></div>
                <p class="bold" style="margin: 0; font-size: 13px;">TICKET DE COBRO # ${e.folio}</p>
                <p style="margin: 3px 0 0 0; font-size: 10px;">${e.session_date} · ${n} hrs</p>
            </div>
            
            <div class="divider"></div>
            <div>
                <p style="margin: 2px 0;"><strong>Cliente:</strong> ${I(e.customer_name)}</p>
                <p style="margin: 2px 0;"><strong>Tipo:</strong> ${e.is_member?`SOCIO DEL CLUB`:`VISITANTE`}</p>
                ${r&&e.authorized_by?`<p style="margin: 2px 0;"><strong>Autorizó:</strong> ${I(e.authorized_by)}</p>`:``}
            </div>

            <div class="divider"></div>
            <table>
                ${e.has_tee_practice?`
                    <tr>
                        <td>Renta Tee de Práctica</td>
                        <td class="text-right">$${Number(e.tee_practice_fee).toFixed(2)}</td>
                    </tr>
                `:``}
                ${e.buckets_count>0?`
                    <tr>
                        <td>${e.buckets_count} Cubeta(s) (100 pelotas c/u)</td>
                        <td class="text-right">$${Number(e.total_buckets_fee).toFixed(2)}</td>
                    </tr>
                `:``}
                <tr>
                    <td colspan="2"><div class="divider"></div></td>
                </tr>
                <tr>
                    <td class="bold" style="font-size: 13px;">TOTAL:</td>
                    <td class="text-right bold" style="font-size: 13px;">$${Number(e.total_amount).toFixed(2)} MXN</td>
                </tr>
                <tr>
                    <td>Forma de Pago:</td>
                    <td class="text-right">${e.payment_method}</td>
                </tr>
                ${e.transaction_ref?`
                    <tr>
                        <td>Ref / Folio:</td>
                        <td class="text-right">${e.transaction_ref}</td>
                    </tr>
                `:``}
            </table>

            <div class="box-vale">
                <p style="margin: 0; font-size: 10px; font-weight: bold; letter-spacing: 1px;">VALE PARA CADDIE MASTER</p>
                <h2 style="margin: 6px 0; font-size: 18px;">${e.buckets_count} CUBETA(S)</h2>
                <p style="margin: 0; font-size: 11px; font-weight: bold;">TOTAL: ${e.buckets_count*100} PELOTAS</p>
                <p style="margin: 4px 0 0 0; font-size: 9px;">Presentar este vale en caseta para entrega de pelotas.</p>
            </div>

            <p class="text-center" style="margin-top: 15px; font-size: 9px;">¡Gracias por su visita al Club de Golf Colima!</p>
        </body>
        </html>
    `),t.document.close()};export{h as renderReceptionModule};