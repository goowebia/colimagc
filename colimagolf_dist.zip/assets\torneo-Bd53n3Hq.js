import"./modulepreload-polyfill-P2Xu9kJm.js";import{t as e}from"./dist-BN2bhVnw.js";var t=e(`https://tztolxgsaktqindoimtu.supabase.co`,`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR6dG9seGdzYWt0cWluZG9pbXR1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYyNzQ4ODAsImV4cCI6MjEwMTg1MDg4MH0.E2GABiOMXYb5hEwE9ErIcJa6_LHkj9lJUglQVoiLl0M`),n=t.schema(`colimaGC`),r=null,i=`posiciones`,a=null,o=null,s=null,c=null,l=[{hole:1,par:4,idx:3},{hole:2,par:3,idx:7},{hole:3,par:4,idx:15},{hole:4,par:4,idx:9},{hole:5,par:3,idx:17},{hole:6,par:5,idx:1},{hole:7,par:3,idx:5},{hole:8,par:4,idx:11},{hole:9,par:4,idx:13},{hole:10,par:4,idx:4},{hole:11,par:3,idx:10},{hole:12,par:4,idx:16},{hole:13,par:4,idx:14},{hole:14,par:3,idx:18},{hole:15,par:5,idx:2},{hole:16,par:3,idx:8},{hole:17,par:4,idx:6},{hole:18,par:4,idx:12}];function u(e){if(!e)return{inStrokes:0,outStrokes:0,holeScores:{}};let t={};if(e.hole_scores)try{t=typeof e.hole_scores==`string`?JSON.parse(e.hole_scores):e.hole_scores}catch{t={}}else Array.isArray(e.holes)&&e.holes.forEach((e,n)=>{t[`h${n+1}`]=e});let n=0;for(let e=1;e<=9;e++){let r=parseInt(t[`h${e}`]);!isNaN(r)&&r>0&&(n+=r)}let r=0;for(let e=10;e<=18;e++){let n=parseInt(t[`h${e}`]);!isNaN(n)&&n>0&&(r+=n)}return n===0&&(e.in_score||e.in)&&(n=e.in_score||e.in||0),r===0&&(e.out_score||e.out)&&(r=e.out_score||e.out||0),{inStrokes:n,outStrokes:r,holeScores:t}}function d(e,t){if(e.neto!==t.neto)return e.neto-t.neto;let n=e._tiebreak||u(e.scoreObj||e.latestScore),r=t._tiebreak||u(t.scoreObj||t.latestScore);if(n.outStrokes!==r.outStrokes&&n.outStrokes>0&&r.outStrokes>0)return n.outStrokes-r.outStrokes;if(n.inStrokes!==r.inStrokes&&n.inStrokes>0&&r.inStrokes>0)return n.inStrokes-r.inStrokes;let i=[...l].sort((e,t)=>(e.idx||99)-(t.idx||99));for(let e of i){let t=parseInt(n.holeScores[`h${e.hole}`])||0,i=parseInt(r.holeScores[`h${e.hole}`])||0;if(t>0&&i>0&&t!==i)return t-i}return 0}window.switchView=function(e){i=e,_(),p()},window.printView=async function(){if(!a)return;let e=window.open(``,`_blank`),t=a.name,n=a.courses||a.course||``,r=``,l=``,f=[{bg:`linear-gradient(135deg, #059669, #10b981)`,color:`#ffffff`},{bg:`linear-gradient(135deg, #1d4ed8, #3b82f6)`,color:`#ffffff`},{bg:`linear-gradient(135deg, #6d28d9, #8b5cf6)`,color:`#ffffff`},{bg:`linear-gradient(135deg, #b45309, #f59e0b)`,color:`#ffffff`},{bg:`linear-gradient(135deg, #be123c, #f43f5e)`,color:`#ffffff`},{bg:`linear-gradient(135deg, #0e7490, #06b6d4)`,color:`#ffffff`}];if(i===`posiciones`){r=`LEADERBOARD EN VIVO`;let e=o||[],t=s||[],n={};e.forEach(e=>{let r=e.category||`GENERAL`,i=t.filter(t=>String(t.teamid)===String(e.id));if(i.length>0){let t=i.reduce((e,t)=>e+(t.total||0),0);n[r]||(n[r]=[]);let a=i[0];n[r].push({team:e,total:t,rounds:i.length,scoreObj:a,_tiebreak:u(a)})}}),l=Object.keys(n).sort().map((e,t)=>{let r=f[t%f.length],i=e.toUpperCase().startsWith(`CATEGORÍA`)||e.toUpperCase().startsWith(`CATEGORIA`)?e.toUpperCase():`CATEGORÍA ${e.toUpperCase()}`;return`
            <div class="category-block" style="margin-bottom: 35px; page-break-inside: avoid; border-radius: 12px; overflow: hidden; border: 1px solid #cbd5e1; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);">
                <h2 style="background: ${r.bg}; color: ${r.color}; padding: 12px 20px; text-transform: uppercase; font-size: 15px; font-weight: 900; letter-spacing: 1.5px; text-align: center; margin: 0;">${i}</h2>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                            <th style="padding: 12px; text-align: center; width: 60px; font-weight: 800; font-size: 10px; color: #64748b;">POS</th>
                            <th style="padding: 12px; text-align: left; font-weight: 800; font-size: 10px; color: #64748b;">PARTICIPANTE / EQUIPO</th>
                            <th style="padding: 12px; text-align: center; width: 40px; font-weight: 800; font-size: 10px; color: #64748b;">RDS</th>
                            <th style="padding: 12px; text-align: center; width: 70px; font-weight: 800; font-size: 10px; color: #64748b;">VENTAJA</th>
                            <th style="padding: 12px; text-align: center; width: 70px; font-weight: 800; font-size: 10px; color: #64748b;">GROSS</th>
                            <th style="padding: 12px; text-align: center; width: 90px; background: #f1f5f9; font-weight: 800; font-size: 10px; color: #047857;">NETO</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${n[e].map(e=>{let t=e.team.ventaja||0,n=e.total,r=n-t*e.rounds;return{...e,gross:n,neto:r,advantage:t}}).sort(d).map((e,t)=>{let n=e.advantage===0?`0`:`-${Math.abs(e.advantage)}`;return`
                            <tr style="border-bottom: 1px solid #f1f5f9;">
                                <td style="padding: 12px; text-align: center; font-weight: 800; color: #334155;">#${t+1}</td>
                                <td style="padding: 12px; font-weight: 700; text-transform: uppercase; font-size: 12px; color: #0f172a;">${e.team.teamname}</td>
                                <td style="padding: 12px; text-align: center; color: #64748b; font-weight: 600;">${e.rounds}</td>
                                <td style="padding: 12px; text-align: center; color: #2563eb; font-weight: 800;">${n}</td>
                                <td style="padding: 12px; text-align: center; font-weight: 700; color: #334155;">${e.gross}</td>
                                <td style="padding: 12px; text-align: center; font-weight: 900; background: #f8fafc; color: #059669; font-size: 14px;">${e.neto}</td>
                            </tr>
                            `}).join(``)}
                    </tbody>
                </table>
            </div>
        `}).join(``)}else if(i===`oyeses`){r=`MARCAS OYE'S`;let e=c||[],t={};e.forEach(e=>{let n=e.coursename||`GENERAL`;t[n]||(t[n]={});let r=e.hole||`?`;t[n][r]||(t[n][r]=[]),t[n][r].push(e)});let n=[`#10b981`,`#3b82f6`,`#f59e0b`,`#ef4444`,`#8b5cf6`,`#ec4899`,`#06b6d4`,`#f97316`];l=Object.entries(t).map(([e,t])=>`
            <div class="course-block" style="margin-bottom: 50px;">
                <h2 style="border-bottom: 3px solid #000; padding-bottom: 10px; margin-bottom: 25px; text-transform: uppercase;">${e}</h2>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                    ${Object.entries(t).sort((e,t)=>parseInt(e[0])-parseInt(t[0])).map(([e,t],r)=>`
                            <div style="page-break-inside: avoid; border: 1px solid #eee; border-radius: 12px; overflow: hidden;">
                                <div style="background: ${n[r%n.length]}; color: white; padding: 10px 15px; font-weight: 900; border-bottom: 1px solid #ddd;">HOYO ${e}</div>
                                <table style="width: 100%; border-collapse: collapse;">
                                    ${t.sort((e,t)=>parseFloat(e.distance)-parseFloat(t.distance)).map((e,t)=>`
                                        <tr style="border-bottom: 1px solid #f8fafc;">
                                            <td style="padding: 10px; width: 30px; font-weight: 800; color: #94a3b8;">${t+1}</td>
                                            <td style="padding: 10px; font-weight: 700; text-transform: uppercase; font-size: 11px;">${e.playername}</td>
                                            <td style="padding: 10px; text-align: right; font-weight: 800; color: #10b981;">${e.distance}m</td>
                                        </tr>
                                    `).join(``)}
                                </table>
                            </div>
                        `).join(``)}
                </div>
            </div>
        `).join(``)}else{r=`LISTA DE SALIDAS`;let e=o||[],t={};e.forEach(e=>{let n=e.starting_hole||`TBA`;t[n]||(t[n]=[]),t[n].push(e)}),l=`
            <div style="display: grid; grid-template-columns: 1fr; gap: 30px;">
                ${Object.keys(t).sort((e,t)=>(parseInt(e)||99)-(parseInt(t)||99)).map(e=>`
                    <div style="page-break-inside: avoid; border: 1px solid #000; border-radius: 12px; overflow: hidden;">
                        <div style="background: #000; color: white; padding: 12px 20px; font-weight: 900; font-size: 16px; text-align: center;">HOYO ${e}</div>
                        <div style="padding: 15px; display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px;">
                            ${t[e].map(e=>{let t=e.players&&Array.isArray(e.players)?e.players.map(e=>`${e.name} <strong>(${e.hdcp||0})</strong>`).join(` - `):[e.player1,e.player2,e.player3,e.player4].filter(e=>e).join(` - `);return`
                                    <div style="background: #f8fafc; padding: 12px; border-radius: 8px; border: 1px solid #e2e8f0; display: flex; justify-between; align-items: center;">
                                        <div style="min-width: 0; flex: 1;">
                                            <div style="font-weight: 900; font-size: 11px; margin-bottom: 4px; text-transform: uppercase;">TEAM #${e.teamnumber||`?`}: ${e.teamname}</div>
                                            <div style="font-size: 8px; color: #64748b; font-weight: 700; text-transform: uppercase;">${t}</div>
                                        </div>
                                        <div style="background: #fff; padding: 5px 10px; border-radius: 6px; border: 1px solid #cbd5e1; text-align: center; margin-left: 10px; flex-shrink: 0;">
                                            <div style="font-size: 7px; color: #94a3b8; font-weight: 800;">HCP</div>
                                            <div style="font-weight: 900; font-size: 14px;">${e.ventaja||0}</div>
                                        </div>
                                    </div>
                                `}).join(``)}
                        </div>
                    </div>
                `).join(``)}
            </div>
        `}let p=new URL(`../golcolima.jpg`,window.location.href).href,m=new URL(`../logoclub.png`,window.location.href).href;e.document.write(`
        <html>
        <head>
            <title>${r} - ${t}</title>
            <style>
                @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap');
                body { font-family: 'Inter', sans-serif; color: #1e293b; margin: 0; padding: 0; }
                table.main-table { width: 100%; border-collapse: collapse; }
                .print-header-container { padding: 25px 40px; background: white; border-bottom: 4px solid #0f172a; }
                .print-content { padding: 25px 40px; }
                @media print { thead { display: table-header-group; } body { padding: 0; } }
                .header-table { width: 100%; border-collapse: collapse; }
            </style>
        </head>
        <body>
            <table class="main-table">
                <thead>
                    <tr>
                        <td>
                            <div class="print-header-container">
                                <table class="header-table">
                                    <tr>
                                        <td align="left" style="vertical-align: bottom;">
                                            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                                <img src="${p}" style="height: 55px; width: 55px; object-fit: contain; border-radius: 8px; border: 1px solid #cbd5e1; padding: 2px; background: #fff;" onerror="this.style.display='none'">
                                                <img src="${m}" style="height: 55px; width: 55px; object-fit: contain; border-radius: 8px; border: 1px solid #cbd5e1; padding: 2px; background: #fff;" onerror="this.style.display='none'">
                                            </div>
                                            <h1 style="margin: 0; font-size: 22px; font-weight: 900; text-transform: uppercase; color: #0f172a;">${t}</h1>
                                            <p style="margin: 3px 0 0 0; color: #64748b; font-weight: 700; font-size: 12px;">${n}</p>
                                        </td>
                                        <td align="right" style="vertical-align: bottom;">
                                            <p style="margin: 0; font-weight: 900; color: #059669; font-size: 15px; letter-spacing: 1px;">${r}</p>
                                            <p style="margin: 4px 0 0 0; font-size: 10px; font-weight: 700; color: #94a3b8;">SISTEMA PASSGOLF • ${new Date().toLocaleDateString()}</p>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="print-content">${l}</div>
                        </td>
                    </tr>
                </tbody>
            </table>
            <script>
                window.onload = () => {
                    const images = Array.from(document.images);
                    const loadPromises = images.map(img => {
                        if (img.complete) return Promise.resolve();
                        return new Promise(resolve => { img.onload = resolve; img.onerror = resolve; });
                    });
                    Promise.all(loadPromises).then(() => {
                        setTimeout(() => { window.print(); window.close(); }, 500);
                    });
                };
            <\/script>
        </body>
        </html>
    `),e.document.close()},window.showScorecard=async function(e,t){let n=document.getElementById(`scorecard-modal`);n||(n=document.createElement(`div`),n.className=`fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-6 bg-slate-950/90 backdrop-blur-md animate-fade-in`,n.id=`scorecard-modal`,document.body.appendChild(n)),n.classList.remove(`hidden`),n.innerHTML=`<div class="p-8 bg-slate-900 border border-slate-700 rounded-3xl text-center"><div class="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500 mx-auto"></div></div>`;let r=(s||[]).filter(t=>String(t.teamid)===String(e)),i=(o||[]).find(t=>String(t.id)===String(e))?.ventaja||0;if(!r||r.length===0){n.innerHTML=`
            <div class="bg-slate-900 border border-white/10 rounded-[2rem] p-6 text-center max-w-sm w-full space-y-4">
                <span class="material-icons-round text-amber-400 text-4xl">info</span>
                <h3 class="font-black text-white uppercase text-sm">Sin Scorecard</h3>
                <p class="text-slate-400 text-xs font-bold">No hay tarjetas registradas para ${t}.</p>
                <button onclick="document.getElementById('scorecard-modal').remove()" class="px-6 py-2.5 bg-emerald-500 text-slate-950 rounded-xl font-black text-xs uppercase">Cerrar</button>
            </div>`;return}let a=r.map(e=>{let t={};if(e.hole_scores)try{t=typeof e.hole_scores==`string`?JSON.parse(e.hole_scores):e.hole_scores}catch{t={}}let n=e.out_score!==void 0&&e.out_score!==null?e.out_score:e.out||0,r=e.in_score!==void 0&&e.in_score!==null?e.in_score:e.in||0,a=e.gross||e.total||0,o=e.net!==void 0&&e.net!==null?e.net:a>0?a-i:0,s=[];for(let e=1;e<=18;e++)s.push(t[`h${e}`]===void 0?`-`:t[`h${e}`]);return`
            <div class="bg-slate-900 rounded-[2rem] border border-white/10 shadow-xl overflow-hidden mb-6">
                <div class="bg-emerald-500 px-6 py-4 flex justify-between items-center text-slate-950">
                    <h4 class="font-black uppercase text-[11px] tracking-widest">${e.coursename||`CLUB DE GOLF COLIMA`}</h4>
                    <div class="flex items-center gap-2">
                        <span class="text-[10px] font-black uppercase bg-slate-950/20 px-3 py-1 rounded-full">Gross: ${a}</span>
                        <span class="text-[10px] font-black uppercase bg-slate-950/40 text-blue-300 px-3 py-1 rounded-full border border-blue-400/30">VTJ: −${i}</span>
                        <span class="text-xs font-black uppercase bg-slate-950 text-emerald-400 px-3 py-1 rounded-full">Neto: ${o}</span>
                    </div>
                </div>
                <div class="p-6">
                    <p class="text-[9px] font-black uppercase text-slate-400 tracking-widest mb-2">VUELTA 1-9 (IN)</p>
                    <div class="grid grid-cols-9 gap-1.5 mb-5">
                        ${s.slice(0,9).map((e,t)=>`
                            <div class="flex flex-col items-center">
                                <span class="text-[8px] text-slate-500 font-bold mb-1">#${t+1}</span>
                                <div class="w-full py-2 bg-slate-800 border border-slate-700/80 rounded-xl text-center font-black text-xs text-white">${e}</div>
                            </div>
                        `).join(``)}
                    </div>

                    <p class="text-[9px] font-black uppercase text-slate-400 tracking-widest mb-2">VUELTA 10-18 (OUT)</p>
                    <div class="grid grid-cols-9 gap-1.5 mb-6">
                        ${s.slice(9,18).map((e,t)=>`
                            <div class="flex flex-col items-center">
                                <span class="text-[8px] text-slate-500 font-bold mb-1">#${t+10}</span>
                                <div class="w-full py-2 bg-slate-800 border border-slate-700/80 rounded-xl text-center font-black text-xs text-white">${e}</div>
                            </div>
                        `).join(``)}
                    </div>

                    <div class="flex justify-between items-center pt-4 border-t border-white/10">
                        <div class="flex gap-3">
                            <div class="text-center px-3 py-1.5 bg-slate-800 rounded-xl">
                                <p class="text-[8px] text-slate-400 font-black">IN (1-9)</p>
                                <p class="font-black text-white text-sm">${n}</p>
                            </div>
                            <div class="text-center px-3 py-1.5 bg-slate-800 rounded-xl">
                                <p class="text-[8px] text-slate-400 font-black">OUT (10-18)</p>
                                <p class="font-black text-white text-sm">${r}</p>
                            </div>
                            <div class="text-center px-3 py-1.5 bg-blue-500/10 border border-blue-500/30 rounded-xl">
                                <p class="text-[8px] text-blue-400 font-black">VENTAJA</p>
                                <p class="font-black text-blue-400 text-sm">−${i}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="text-[8px] text-slate-400 font-black uppercase">TOTAL NETO</p>
                            <p class="text-2xl font-black text-emerald-400">${o}</p>
                        </div>
                    </div>
                </div>
            </div>
        `}).join(``);n.innerHTML=`
        <div class="w-full max-w-2xl bg-slate-950/95 backdrop-blur-3xl rounded-[2.5rem] border border-white/15 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div class="p-6 border-b border-white/10 flex justify-between items-center bg-slate-900/50">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                        <span class="material-icons-round">sports_golf</span>
                    </div>
                    <div>
                        <h3 class="font-black uppercase text-white text-base truncate">${t}</h3>
                        <p class="text-[10px] text-emerald-400 font-black uppercase tracking-widest">Tarjeta Oficial de Score</p>
                    </div>
                </div>
                <button onclick="document.getElementById('scorecard-modal').remove()" class="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all">
                    <span class="material-icons-round text-sm">close</span>
                </button>
            </div>
            <div class="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-4">${a}</div>
        </div>
    `};async function f(){let e=new URLSearchParams(window.location.search);r=e.get(`id`)||e.get(`tournament`);let t=e.get(`view`);t&&[`posiciones`,`oyeses`,`salidas`].includes(t)&&(i=t);let l=[];try{let{data:e}=await n.from(`tournaments`).select(`id, name`).order(`created_at`,{ascending:!1});e&&e.length>0&&(l=e)}catch{}let u=`b73a7380-589d-4986-84c4-7618d805fced`,d=`291bcd9c-674b-431e-9fd4-5690ce2b7b94`,f=`69452b77-44c7-400a-bb88-a763da03196b`,m=`dfecb440-d4ee-485f-b6d1-ad27f5032fc7`,h=e=>e&&(e.id===u||(e.name?.toLowerCase().includes(`8`)||e.name?.toLowerCase().includes(`1ª`)||e.name?.toLowerCase().includes(`1a`))&&e.name?.toLowerCase().includes(`ago`)&&!e.name?.toLowerCase().includes(`nov`)),g=e=>e&&(e.id===d||e.name?.toLowerCase().includes(`22`)&&e.name?.toLowerCase().includes(`ago`)),b=e=>e&&(e.id===f||(e.name?.toLowerCase().includes(`5`)||e.name?.toLowerCase().includes(`3ª`)||e.name?.toLowerCase().includes(`3a`))&&(e.name?.toLowerCase().includes(`sep`)||e.name?.toLowerCase().includes(`sept`))&&!e.name?.toLowerCase().includes(`nov`)),x=e=>e&&(e.id===m||(e.name?.toLowerCase().includes(`26`)||e.name?.toLowerCase().includes(`4ª`)||e.name?.toLowerCase().includes(`4a`))&&(e.name?.toLowerCase().includes(`sep`)||e.name?.toLowerCase().includes(`sept`))&&!e.name?.toLowerCase().includes(`nov`)),S=l.find(h),C=l.find(g),w=l.find(b),T=l.find(x),E=S?S.id:u,D=C?C.id:d,O=w?w.id:f,k=T?T.id:m,A=l.find(e=>e.id===`f116975d-d521-4001-91b5-2e21510f6be7`||e.name?.toLowerCase().includes(`mecate`)),j=A?A.id:`f116975d-d521-4001-91b5-2e21510f6be7`;if((!r||r===`5-sept-pending`||r===`69452b77-44c7-400a-bb88-a763da03196b`)&&(r=!r&&new Date<=new Date(2026,8,20,23,59,59)?j:O),r===`5-sept-pending`){a={id:`5-sept-pending`,name:`3ª FECHA · 5 DE SEPTIEMBRE`,courses:`CLUB DE GOLF COLIMA`,config:{categories:[{name:`CATEGORIA A`,pct:80},{name:`CATEGORIA B`,pct:80},{name:`CATEGORIA C`,pct:80}]}},o=[],s=[],c=[],document.getElementById(`tournament-name`).textContent=a.name,document.getElementById(`tournament-location`).innerHTML=`<span class="material-icons-round text-[12px]">location_on</span> ${a.courses}`;let e=document.getElementById(`live-indicator`),t=e?.nextElementSibling;e&&(e.innerHTML=`
                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            `),t&&(t.textContent=`Live Update · En Vivo`,t.className=`text-[10px] font-black uppercase tracking-[0.2em] text-emerald-500`);let n=document.getElementById(`torneo-date-pills`);n&&(n.innerHTML=`
                <span class="text-[9px] font-black uppercase text-slate-400 shrink-0">Fechas:</span>
                <a href="/torneo/?id=${u}"
                    style="text-decoration:none;"
                    class="px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shrink-0
                    ${r===u?`bg-amber-500 text-slate-950 font-black shadow-lg`:`bg-white/5 text-amber-300 border border-amber-500/40 hover:bg-white/10`}">
                    <span style="width:6px; height:6px; border-radius:9999px; background:${r===u?`#020617`:`#f59e0b`};"></span>
                    1ª Fecha · 8 Ago (Finalizado)
                </a>
                <a href="/torneo/?id=${d}"
                    style="text-decoration:none;"
                    class="px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shrink-0
                    ${r===d?`bg-amber-500 text-slate-950 font-black shadow-lg`:`bg-white/5 text-amber-300 border border-amber-500/40 hover:bg-white/10`}">
                    <span style="width:6px; height:6px; border-radius:9999px; background:${r===d?`#020617`:`#f59e0b`};"></span>
                    2ª Fecha · 22 Ago (Finalizado)
                </a>
                <a href="/torneo/?id=${f}"
                    style="text-decoration:none;"
                    class="px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shrink-0
                    ${r===f&&r!==u&&r!==d?`bg-emerald-500 text-slate-950 font-black shadow-lg`:`bg-white/5 text-emerald-300 border border-emerald-500/40 hover:bg-white/10`}">
                    <span style="width:6px; height:6px; border-radius:9999px; background:${r===f&&r!==u&&r!==d?`#020617`:`#10b981`};"></span>
                    3ª Fecha · 5 Sept (En Vivo)
                </a>
            `);let l=document.getElementById(`btn-oyeses`);l&&l.classList.add(`hidden`),i=`posiciones`,_(),p();return}try{let[e,l,u,d]=await Promise.all([n.from(`tournaments`).select(`*`).eq(`id`,r).single(),n.from(`teams`).select(`*`).eq(`eventid`,String(r)),n.from(`scores`).select(`*`).eq(`eventid`,String(r)),n.from(`oyeses`).select(`*`).eq(`eventid`,String(r))]);if(e.error||!e.data)throw Error(`Torneo no encontrado`);a=e.data,o=l.data||[],s=u.data||[],c=d.data||[],document.getElementById(`tournament-name`).textContent=a.name||`TORNEO DE GOLF`,document.getElementById(`tournament-location`).innerHTML=`<span class="material-icons-round text-[12px]">location_on</span> ${a.courses||`CLUB DE GOLF COLIMA`}`;let f=!1;try{let{count:e}=await n.from(`scores`).select(`id`,{count:`exact`,head:!0}).eq(`eventid`,k);e&&e>0&&(f=!0)}catch{}let m=r===j||a?.name?.toLowerCase().includes(`mecate`),y=a.name&&h(a)||r===E,S=a.name&&g(a)||r===D,C=a.name&&b(a)||r===O;a.name&&x(a);let w=!m&&(y||S||C),T=document.getElementById(`live-indicator`),A=T?.nextElementSibling;w?(T&&(T.innerHTML=`<span style="width:8px; height:8px; border-radius:9999px; background:#f59e0b; display:inline-block;"></span>`),A&&(A.textContent=`Torneo Finalizado · Resultados`,A.className=`text-[10px] font-black uppercase tracking-[0.2em] text-amber-400`)):(T&&(T.innerHTML=`
                    <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                `),A&&(A.textContent=`Live Update · En Vivo`,A.className=`text-[10px] font-black uppercase tracking-[0.2em] text-emerald-500`));let M=document.getElementById(`torneo-date-pills`);M&&(m?(M.innerHTML=``,M.classList.add(`hidden`)):(M.classList.remove(`hidden`),M.innerHTML=`
                    <span class="text-[9px] font-black uppercase text-slate-400 shrink-0">Fechas:</span>
                    <a href="/torneo/?id=${E}"
                        style="text-decoration:none;"
                        class="px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shrink-0
                        ${r===E?`bg-amber-500 text-slate-950 font-black shadow-lg`:`bg-white/5 text-amber-300 border border-amber-500/40 hover:bg-white/10`}">
                        <span style="width:6px; height:6px; border-radius:9999px; background:${r===E?`#020617`:`#f59e0b`};"></span>
                        1ª Fecha · 8 Ago (Finalizado)
                    </a>
                    <a href="/torneo/?id=${D}"
                        style="text-decoration:none;"
                        class="px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shrink-0
                        ${r===D?`bg-amber-500 text-slate-950 font-black shadow-lg`:`bg-white/5 text-amber-300 border border-amber-500/40 hover:bg-white/10`}">
                        <span style="width:6px; height:6px; border-radius:9999px; background:${r===D?`#020617`:`#f59e0b`};"></span>
                        2ª Fecha · 22 Ago (Finalizado)
                    </a>
                    <a href="/torneo/?id=${O}"
                        style="text-decoration:none;"
                        class="px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shrink-0
                        ${r===O?`bg-amber-500 text-slate-950 font-black shadow-lg`:`bg-white/5 text-amber-300 border border-amber-500/40 hover:bg-white/10`}">
                        <span style="width:6px; height:6px; border-radius:9999px; background:${r===O?`#020617`:`#f59e0b`};"></span>
                        3ª Fecha · 5 Sept (Finalizado)
                    </a>
                    ${f?`
                    <a href="/torneo/?id=${k}"
                        style="text-decoration:none;"
                        class="px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shrink-0
                        ${r===k?`bg-emerald-500 text-slate-950 font-black shadow-lg`:`bg-white/5 text-emerald-300 border border-emerald-500/40 hover:bg-white/10`}">
                        <span style="width:6px; height:6px; border-radius:9999px; background:${r===k?`#020617`:`#10b981`};"></span>
                        4ª Fecha · 26 Sept (Gran Final)
                    </a>
                    `:``}
                    <a href="/torneo/?id=${j}"
                        style="text-decoration:none;"
                        class="px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shrink-0 ml-auto bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20"
                        title="Ver Torneo del Mecate 19 Sep">
                        🚩 Torneo del Mecate (19 Sep)
                    </a>
                `)),t||(i=s.length===0&&o.length>0?`salidas`:`posiciones`);let N=document.getElementById(`btn-oyeses`);c.length===0?(N.classList.add(`hidden`),i===`oyeses`&&(i=s.length>0?`posiciones`:`salidas`)):N.classList.remove(`hidden`),_(),p(),setTimeout(()=>v(),800)}catch(e){y(e.message)}}function p(){let e=document.getElementById(`loader`);e&&e.classList.add(`hidden`),i===`posiciones`?h():i===`oyeses`?g():m()}function m(){let e=document.getElementById(`content-area`),t=o||[];if(t.length===0){e.innerHTML=`
            <div class="py-24 text-center space-y-4 max-w-md mx-auto">
                <div class="w-16 h-16 rounded-3xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/10">
                    <span class="material-icons-round text-3xl">flag</span>
                </div>
                <div class="space-y-2">
                    <h4 class="text-base font-black uppercase tracking-tight text-white">Salidas por Asignar</h4>
                    <p class="text-xs text-slate-400 leading-relaxed font-medium">
                        Las salidas por hoyo y grupos de jugadores se publicarán aquí en cuanto sean asignadas por el Caddie Master y Comité Organizador.
                    </p>
                </div>
            </div>`;return}let n={};t.forEach(e=>{let t=e.hole!==null&&e.hole!==void 0&&e.hole!==``?e.hole:e.starting_hole||`SIN HOYO`;n[t]||(n[t]=[]),n[t].push(e)}),e.innerHTML=`
        <div class="grid gap-6 animate-fade-in pb-20 px-1 sm:px-0">
            ${Object.keys(n).sort((e,t)=>(parseInt(e)||99)-(parseInt(t)||99)).map(e=>`
                <div class="bg-white/5 backdrop-blur-md rounded-[2.5rem] border border-white/10 shadow-xl overflow-hidden group hover:border-emerald-500/30 transition-all">
                    <div class="bg-black/40 px-6 py-5 flex items-center relative border-b border-white/5">
                        <div class="flex items-center gap-4 z-10">
                            <div class="w-10 h-10 rounded-2xl bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20"><span class="material-icons-round text-emerald-500 text-sm">flag</span></div>
                        </div>
                        <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
                            <h3 class="text-xl font-black uppercase text-white tracking-tight">${isNaN(parseInt(e))?e:`Hoyo ${e}`}</h3>
                        </div>
                        <span class="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-auto z-10">${n[e].length} EQUIPOS</span>
                    </div>
                    <div class="p-6 grid gap-4 grid-cols-1 md:grid-cols-2">
                        ${n[e].map(e=>{let t=e.players&&Array.isArray(e.players)?e.players.map(e=>`${e.name} <strong class="text-white">(${e.hdcp||0})</strong>`):[e.player1,e.player2,e.player3,e.player4].filter(e=>e&&e.trim()!==``);return`
                                <div class="p-5 bg-white/[0.02] rounded-3xl border border-white/5 hover:bg-white/5 transition-all flex flex-col sm:flex-row justify-between items-center gap-5 text-center sm:text-left">
                                    <div class="min-w-0 w-full flex-1 order-2 sm:order-1">
                                        <p class="text-[8px] font-black text-slate-600 uppercase mb-1">Equipo #${e.teamnumber||`?`}</p>
                                        <h4 class="font-black text-[15px] sm:text-[14px] uppercase text-white truncate mb-2 leading-tight">${e.teamname||`EQUIPO`}</h4>
                                        <div class="grid grid-cols-2 gap-x-3 gap-y-2 mt-3">
                                            ${t.map(e=>`<div class="text-[10px] sm:text-[9px] font-bold text-slate-400 uppercase tracking-tight leading-tight">${e}</div>`).join(``)}
                                        </div>
                                    </div>
                                    <div class="shrink-0 flex items-center gap-2 order-1 sm:order-2">
                                        <div class="flex flex-col items-center px-3.5 py-2 bg-slate-800/80 rounded-2xl border border-slate-700/80 min-w-[50px]">
                                            <span class="text-[7px] font-black text-slate-400 uppercase tracking-wider mb-0.5">HCP</span>
                                            <span class="text-sm font-black text-white leading-none">${e.hdcp||0}</span>
                                        </div>
                                        <div class="flex flex-col items-center px-3.5 py-2 bg-emerald-500/10 rounded-2xl border border-emerald-500/30 min-w-[50px]">
                                            <span class="text-[7px] font-black text-emerald-400 uppercase tracking-wider mb-0.5">VTJ</span>
                                            <span class="text-sm font-black text-emerald-400 leading-none">${e.ventaja||0}</span>
                                        </div>
                                    </div>
                                </div>
                            `}).join(``)}
                    </div>
                </div>
            `).join(``)}
        </div>
    `}function h(){let e=document.getElementById(`content-area`),t=o||[],n=s||[];if(n.length===0){e.innerHTML=`
            <div class="py-24 text-center space-y-4 max-w-md mx-auto">
                <div class="w-16 h-16 rounded-3xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/10">
                    <span class="material-icons-round text-3xl">emoji_events</span>
                </div>
                <div class="space-y-2">
                    <h4 class="text-base font-black uppercase tracking-tight text-white">Esperando Registro de Scores</h4>
                    <p class="text-xs text-slate-400 leading-relaxed font-medium">
                        ${t.length>0?`Los jugadores y salidas ya están registrados. En cuanto comiencen a capturarse los scores hoyo por hoyo, el leaderboard se actualizará automáticamente en tiempo real.`:`El torneo "${a?.name||`Torneo`}" se encuentra en preparación. En cuanto se creen los registros y se capturen los primeros scores, la tabla de posiciones aparecerá aquí en tiempo real.`}
                    </p>
                </div>
            </div>`;return}let r={};t.forEach(e=>{let t=(e.category||`GENERAL`).replace(/\s+/g,` `).trim(),i=n.filter(t=>String(t.teamid)===String(e.id));if(i.length>0){let n=i.reduce((e,t)=>e+(t.total||0),0);r[t]||(r[t]=[]);let a=i[0];r[t].push({team:e,total:n,rounds:i.length,scoreObj:a,_tiebreak:u(a)})}}),e.innerHTML=Object.keys(r).sort().map(e=>`
        <div class="space-y-6 mb-12 animate-fade-in">
           <div class="flex items-center gap-4 px-2">
              <div class="w-1.5 h-10 bg-emerald-500 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.3)]"></div>
              <h3 class="text-xl font-black uppercase tracking-tight text-white">${e}</h3>
           </div>
           <div class="bg-white/5 backdrop-blur-md rounded-[2.5rem] border border-white/10 shadow-xl overflow-hidden">
             <div class="overflow-x-auto custom-scrollbar">
               <table class="w-full text-left min-w-[550px] md:min-w-full">
                 <thead>
                   <tr class="bg-black/40 text-white/40 text-[9px] font-black uppercase tracking-[0.2em]">
                     <th class="px-3 md:px-6 py-5 w-16 md:w-20 text-center">POS</th>
                     <th class="px-3 md:px-6 py-5">EQUIPO / JUGADORES</th>
                     <th class="px-3 md:px-6 py-5 text-center">RDS</th>
                     <th class="px-3 md:px-6 py-5 text-center">VENTAJA</th>
                     <th class="px-3 md:px-6 py-5 text-center">GROSS</th>
                     <th class="px-3 md:px-6 py-5 text-center bg-black/40 text-emerald-500">NETO</th>
                     <th class="px-3 md:px-6 py-5 text-center w-20 md:w-24">INFO</th>
                   </tr>
                 </thead>
                 <tbody class="divide-y divide-white/5">
                   ${r[e].map(e=>{let t=e.team.ventaja||0,n=e.total,r=n-t*e.rounds;return{...e,gross:n,neto:r,advantage:t}}).sort(d).map((e,t)=>{let n=e.advantage===0?`0`:`-${Math.abs(e.advantage)}`;return`
                     <tr class="hover:bg-white/[0.02] transition-colors group">
                       <td class="px-3 md:px-6 py-4 md:py-5 text-center">
                         <span class="w-7 h-7 md:w-8 md:h-8 flex items-center justify-center rounded-lg md:rounded-xl bg-white/5 text-white font-black text-xs md:text-sm mx-auto">#${t+1}</span>
                       </td>
                       <td class="px-3 md:px-6 py-4 md:py-5">
                         <p class="font-black text-[12px] md:text-[13px] uppercase text-white truncate max-w-[120px] md:max-w-none">${e.team.teamname}</p>
                       </td>
                       <td class="px-3 md:px-6 py-4 md:py-5 text-center text-white/70 font-bold text-xs md:text-sm">${e.rounds}</td>
                       <td class="px-3 md:px-6 py-4 md:py-5 text-center text-blue-400 font-bold text-xs md:text-sm">${n}</td>
                       <td class="px-3 md:px-6 py-4 md:py-5 text-center text-white font-bold text-xs md:text-sm">${e.gross}</td>
                       <td class="px-3 md:px-6 py-4 md:py-5 text-center bg-emerald-500/10">
                         <span class="text-lg md:text-xl font-black text-emerald-400">${e.neto}</span>
                       </td>
                       <td class="px-3 md:px-6 py-4 md:py-5 text-center">
                         <button onclick="showScorecard('${e.team.id}', '${e.team.teamname.replace(/'/g,`\\'`)}')" class="w-8 h-8 md:w-10 md:h-10 bg-white/5 text-slate-400 hover:text-emerald-400 hover:bg-emerald-400/10 rounded-lg md:rounded-xl flex items-center justify-center mx-auto transition-all">
                           <span class="material-icons-round text-xs md:text-sm">visibility</span>
                         </button>
                       </td>
                     </tr>
                    `}).join(``)}
                 </tbody>
               </table>
             </div>
           </div>
        </div>
    `).join(``)}function g(){let e=document.getElementById(`content-area`),t=c||[];if(t.length===0){e.innerHTML=`<div class="py-20 text-center opacity-40"><p class="text-[10px] font-black uppercase tracking-widest text-white/50">No hay registros de Oye's.</p></div>`;return}let n={1:`#10b981`,2:`#10b981`,3:`#06b6d4`,4:`#3b82f6`,5:`#6366f1`,6:`#a855f7`,7:`#f59e0b`,8:`#f97316`,9:`#06b6d4`,10:`#f43f5e`,11:`#6366f1`,12:`#14b8a6`,13:`#eab308`,14:`#84cc16`,15:`#0ea5e9`,16:`#8b5cf6`,17:`#ec4899`,18:`#10b981`},r={};t.forEach(e=>{let t=e.hole||`?`;r[t]||(r[t]=[]),r[t].push(e)});let i=Object.keys(r).sort((e,t)=>(parseInt(e)||99)-(parseInt(t)||99));e.innerHTML=`
        <div class="space-y-12 animate-fade-in pb-16">
            <div class="text-center">
                <h2 class="text-2xl font-black uppercase tracking-tight text-white mb-1">${a?a.name:`OYE'S LEADERBOARD`}</h2>
                <p class="text-xs font-bold text-slate-400 uppercase tracking-widest">Premios a la bandera</p>
            </div>

            ${i.map(e=>{let t=n[parseInt(e)||1]||`#10b981`;return`
                <div class="space-y-4">
                    <div class="flex items-center gap-4">
                        <div class="h-px flex-1 bg-white/10"></div>
                        <span class="text-xs font-black uppercase tracking-[0.3em] px-4 py-1.5 rounded-full border border-white/10" style="color:${t}; background: ${t}15">
                            Hoyo ${e}
                        </span>
                        <div class="h-px flex-1 bg-white/10"></div>
                    </div>

                    <div class="grid gap-3">
                        ${r[e].sort((e,t)=>parseFloat(e.distance)-parseFloat(t.distance)).map((e,t)=>`
                            <div class="flex items-center justify-between p-4 sm:p-5 rounded-[2rem] bg-white/5 border border-white/5 ${t===0?`border-emerald-500/30 shadow-lg shadow-emerald-500/5`:``}">
                                <div class="flex items-center gap-3 sm:gap-4 min-w-0 flex-1">
                                    <div class="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl ${t===0?`bg-amber-500/20 text-amber-400 border border-amber-500/30`:`bg-white/5 text-slate-400`} flex items-center justify-center font-black text-sm shrink-0">
                                        ${t===0?`🥇`:t+1}
                                    </div>
                                    <h4 class="text-xs sm:text-sm font-black uppercase tracking-tight text-white truncate">${e.player_name||e.playername}</h4>
                                </div>
                                <div class="px-4 py-2 rounded-2xl bg-black/40 font-black text-emerald-400 text-xs sm:text-sm shrink-0">
                                    ${e.distance}
                                </div>
                            </div>
                        `).join(``)}
                    </div>
                </div>`}).join(``)}
        </div>`}function _(){let e=a?.name?.toLowerCase().includes(`8`)&&a?.name?.toLowerCase().includes(`agosto`)?`bg-amber-500`:`bg-emerald-500`;document.querySelectorAll(`.tab-btn`).forEach(e=>e.classList.remove(`active`,`bg-emerald-500`,`bg-amber-500`,`text-slate-950`,`shadow-lg`,`shadow-emerald-500/20`,`shadow-amber-500/20`)),document.querySelectorAll(`.tab-btn`).forEach(e=>e.classList.add(`text-white/50`));let t=document.getElementById(`btn-${i}`);t&&(t.classList.remove(`text-white/50`),t.classList.add(`active`,e,`text-slate-950`,`shadow-lg`))}function v(){try{t.removeAllChannels(),t.channel(`tournament-live`).on(`postgres_changes`,{event:`*`,schema:`colimaGC`,table:`scores`,filter:`eventid=eq.${r}`},async()=>{let{data:e}=await n.from(`scores`).select(`*`).eq(`eventid`,String(r));e&&(s=e),p()}).on(`postgres_changes`,{event:`*`,schema:`colimaGC`,table:`oyeses`,filter:`eventid=eq.${r}`},async()=>{let{data:e}=await n.from(`oyeses`).select(`*`).eq(`eventid`,String(r));e&&(c=e),p()}).on(`postgres_changes`,{event:`*`,schema:`colimaGC`,table:`teams`,filter:`eventid=eq.${r}`},async()=>{let{data:e}=await n.from(`teams`).select(`*`).eq(`eventid`,String(r));e&&(o=e),p()}).subscribe()}catch(e){console.warn(`Realtime subscription delayed:`,e)}}function y(e){document.getElementById(`content-area`).innerHTML=`<div class="py-20 text-center"><span class="material-icons-round text-red-500 mb-4">error</span><p class="text-red-500 font-black uppercase text-[10px]">${e}</p></div>`}f();