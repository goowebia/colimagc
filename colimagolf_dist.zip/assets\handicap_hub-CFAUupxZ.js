import{t as e}from"./dist-BN2bhVnw.js";var t=e(`https://tztolxgsaktqindoimtu.supabase.co`,`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR6dG9seGdzYWt0cWluZG9pbXR1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYyNzQ4ODAsImV4cCI6MjEwMTg1MDg4MH0.E2GABiOMXYb5hEwE9ErIcJa6_LHkj9lJUglQVoiLl0M`),n=t.schema(`colimaGC`),r=t.schema(`starter`),i=[],a=null,o=[],s=`CLUB_HANDICAP`,c=``,l=new Date().toISOString().split(`T`)[0],u=[{color:`BLANCO`,code:`B`,label:`Blanco (B)`,bg:`bg-slate-200 text-slate-950`,text:`text-slate-200`,rating:67.5,slope:114,par:68},{color:`DORADO`,code:`D`,label:`Dorado (D)`,bg:`bg-amber-400 text-slate-950`,text:`text-amber-400`,rating:65.8,slope:110,par:68},{color:`PLATA / ROJO`,code:`P`,label:`Plata / Rojo (P)`,bg:`bg-rose-600 text-white`,text:`text-rose-400`,rating:64.5,slope:108,par:68}];async function d(e){e.innerHTML=`
        <div class="space-y-6">
            <!-- Header Banner SpeiHandicap Style -->
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
                <div class="flex items-center gap-4">
                    <div class="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                        <span class="material-icons" style="font-size:30px">analytics</span>
                    </div>
                    <div>
                        <h2 class="text-2xl font-black text-white uppercase tracking-tight">Handicap del Club · Club de Golf Colima</h2>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-0.5">Tabla General de Handicaps por Tee de Salida & Consultas Individuales WHS</p>
                    </div>
                </div>

                <!-- Date Picker & Quick Actions -->
                <div class="flex items-center gap-3">
                    <div class="px-4 py-2 bg-slate-800 border border-slate-700 rounded-2xl">
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-widest">Selección Fecha de Handicap</label>
                        <input id="whs-date-picker" type="date" value="${l}" class="bg-transparent text-xs font-black text-amber-400 focus:outline-none cursor-pointer">
                    </div>
                </div>
            </div>

            <!-- Sub Tabs Bar (SpeiHandicap Navigation Style) -->
            <div class="flex items-center gap-2 border-b border-slate-800 pb-2">
                <button id="hub-tab-club" class="px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20">
                    <span class="material-icons" style="font-size:18px">table_chart</span> Club Handicap (Tabla General)
                </button>
                <button id="hub-tab-individual" class="px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white">
                    <span class="material-icons" style="font-size:18px">person</span> Handicap Individual
                </button>
            </div>

            <!-- Main Content Area -->
            <div id="whs-hub-content" class="w-full">
                <div class="py-16 text-center bg-slate-900/50 border border-slate-800 rounded-3xl">
                    <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-400 mx-auto"></div>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-3">Cargando Datos WHS...</p>
                </div>
            </div>
        </div>
    `;let t=document.getElementById(`hub-tab-club`),n=document.getElementById(`hub-tab-individual`);t.onclick=()=>{s=`CLUB_HANDICAP`,t.className=`px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20`,n.className=`px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white`,y()},n.onclick=()=>{s=`INDIVIDUAL`,n.className=`px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20`,t.className=`px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white`,b()},document.getElementById(`whs-date-picker`).onchange=e=>{l=e.target.value,s===`CLUB_HANDICAP`?y():b()},await f()}async function f(){try{let{data:e}=await n.from(`members`).select(`*`).order(`name`,{ascending:!0});if(i=e||[],i.length>0){a=i[0];let{data:e}=await r.from(`member_scores`).select(`*`).eq(`member_id`,a.id).order(`date_played`,{ascending:!1}).limit(20);o=e||[]}y()}catch(e){console.error(`Error loading WHS hub data:`,e)}}function p(e){return Math.max(0,parseFloat(e)||0).toFixed(1)}function m(e,t){let n=Math.max(0,parseFloat(e)||0)*(t.slope/113),r=Math.floor(n),i=n-r>=.5?r+1:r;return Math.max(0,i)}function h(e){return u.map(t=>m(e,t))}function g(e,t){if(!t)return e;try{let n=t.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`),r=RegExp(`(${n})`,`gi`);return e.replace(r,`<span class="text-amber-400 font-black underline">$1</span>`)}catch{return e}}function _(){return c?i.filter(e=>`${e.name} ${e.member_number}`.toLowerCase().includes(c)):i}function v(e){return!e||e.length===0?`
            <tr>
                <td colspan="6" class="px-6 py-12 text-center text-slate-500 font-bold uppercase text-xs">
                    <div class="flex flex-col items-center justify-center gap-2">
                        <span class="material-icons text-slate-600 text-3xl">person_search</span>
                        <span>No se encontraron jugadores que coincidan con "${c}"</span>
                    </div>
                </td>
            </tr>`:e.map(e=>{let t=parseFloat(e.current_handicap||0),[n,r,i]=h(t);return`
            <tr onclick="window.viewMemberWHSProfile('${e.id}')"
                class="hover:bg-slate-800/50 transition-colors cursor-pointer group">
                <td class="px-6 py-4">
                    <div class="flex items-center gap-3">
                        <span class="px-2 py-0.5 bg-slate-800 text-slate-400 border border-slate-700 font-black text-[10px] rounded-md">#${e.member_number}</span>
                        <span class="font-black text-white uppercase group-hover:text-amber-400 transition-colors text-sm">${e.name}</span>
                    </div>
                </td>
                <td class="px-6 py-4 text-center font-black text-rose-500 text-base">${p(t)}</td>
                <td class="px-6 py-4 text-center font-black text-slate-200 text-base">${n}</td>
                <td class="px-6 py-4 text-center font-black text-amber-400 text-base">${r}</td>
                <td class="px-6 py-4 text-center font-black text-rose-400 text-base">${i}</td>
                <td class="px-4 py-4 text-right" onclick="event.stopPropagation()">
                    <button onclick="window.viewMemberWHSProfile('${e.id}')" class="px-3 py-1.5 bg-slate-800 hover:bg-amber-500/20 hover:border-amber-500/40 border border-slate-700 rounded-xl text-[11px] font-black text-amber-400 transition-all">
                        Ver Tarjetas ➔
                    </button>
                </td>
            </tr>`}).join(``)}function y(){let e=document.getElementById(`whs-hub-content`);if(!e)return;let t=_();e.innerHTML=`
        <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 animate-fade-in">
            <!-- Header Controls for Club Handicap Table -->
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
                        <span class="material-icons">groups</span>
                    </div>
                    <div>
                        <h3 class="font-black text-white text-lg uppercase tracking-tight">HANDICAP DEL CLUB</h3>
                        <p class="text-xs text-slate-400 font-bold uppercase">Club: <span class="text-white">CLUB DE GOLF COLIMA</span> · Fecha: <span class="text-amber-400 font-black">${l}</span></p>
                    </div>
                </div>

                <div class="flex items-center gap-3">
                    <div class="relative w-full sm:w-80" id="club-search-wrapper">
                        <span class="material-icons absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 text-sm pointer-events-none">search</span>
                        <input id="club-search-input" type="text" value="${c}" autocomplete="off" placeholder="Buscar jugador..." class="w-full pl-10 pr-9 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:border-amber-400">
                        <button id="club-search-clear" type="button" class="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-all ${c?``:`hidden`}" title="Limpiar búsqueda">
                            <span class="material-icons text-sm">close</span>
                        </button>
                        <!-- Autocomplete Suggestions Menu -->
                        <div id="club-search-suggestions" class="absolute left-0 right-0 top-full mt-1.5 bg-slate-900/95 backdrop-blur-md border border-slate-700 rounded-2xl shadow-2xl overflow-hidden z-50 hidden max-h-64 overflow-y-auto custom-scrollbar">
                        </div>
                    </div>
                    <button onclick="window.print()" class="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-xl font-black text-xs uppercase flex items-center gap-1.5 transition-all shrink-0">
                        <span class="material-icons" style="font-size:16px">print</span> Imprimir
                    </button>
                </div>
            </div>

            <!-- General SpeiHandicap Table (Exact Match to SpeiHandicap Screenshot 1 & 2) -->
            <div class="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
                <div class="overflow-x-auto custom-scrollbar">
                    <table class="w-full text-left border-collapse text-xs">
                        <thead>
                            <tr class="bg-slate-900 border-b border-slate-800 text-[11px] font-black uppercase text-slate-400 tracking-wider">
                                <th class="px-6 py-4">Jugador</th>
                                <th class="px-6 py-4 text-center text-rose-500 font-black">Index</th>
                                <th class="px-6 py-4 text-center text-slate-200 font-black">B</th>
                                <th class="px-6 py-4 text-center text-amber-400 font-black">D</th>
                                <th class="px-6 py-4 text-center text-rose-400 font-black">P</th>
                                <th class="px-4 py-4 text-right">Consulta WHS</th>
                            </tr>
                        </thead>
                        <tbody id="club-handicap-tbody" class="divide-y divide-slate-800/60 font-bold">
                            ${v(t)}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;let n=document.getElementById(`club-search-input`),r=document.getElementById(`club-search-clear`),a=document.getElementById(`club-search-suggestions`),o=document.getElementById(`club-handicap-tbody`),s=()=>{let e=_();o&&(o.innerHTML=v(e))},u=e=>{if(!a)return;let t=(e||``).toLowerCase().trim();if(!t){a.innerHTML=``,a.classList.add(`hidden`);return}let o=i.filter(e=>`${e.name} ${e.member_number}`.toLowerCase().includes(t)).slice(0,8);if(o.length===0){a.innerHTML=`
                <div class="px-4 py-3 text-slate-500 text-xs font-bold text-center">
                    No hay sugerencias para "${t}"
                </div>`,a.classList.remove(`hidden`);return}a.innerHTML=o.map(e=>{let n=parseFloat(e.current_handicap||0),r=e.name.replace(/"/g,`&quot;`),i=g(e.name,t);return`
                <div class="suggestion-item px-4 py-2.5 hover:bg-slate-800 cursor-pointer flex items-center justify-between border-b border-slate-800/60 last:border-0 transition-colors"
                     data-name="${r}">
                    <div class="flex items-center gap-2.5">
                        <span class="px-1.5 py-0.5 bg-slate-800 border border-slate-700 text-amber-400 font-black text-[9px] rounded">#${e.member_number}</span>
                        <span class="font-black text-white text-xs uppercase">${i}</span>
                    </div>
                    <span class="text-[10px] font-bold text-slate-400">Index: <strong class="text-rose-400">${p(n)}</strong></span>
                </div>
            `}).join(``),a.classList.remove(`hidden`),a.querySelectorAll(`.suggestion-item`).forEach(e=>{e.onclick=t=>{t.stopPropagation();let i=e.dataset.name;n&&(n.value=i),c=i.toLowerCase().trim(),r&&r.classList.remove(`hidden`),s(),a.classList.add(`hidden`),n&&n.focus()}})};n&&(n.oninput=e=>{let t=e.target.value;c=t.toLowerCase().trim(),r&&(t?r.classList.remove(`hidden`):r.classList.add(`hidden`)),s(),u(t)},n.onfocus=()=>{n.value.trim()&&u(n.value)},n.onkeydown=e=>{e.key===`Escape`&&a&&a.classList.add(`hidden`)}),r&&(r.onclick=e=>{e.stopPropagation(),n&&(n.value=``,n.focus()),c=``,r.classList.add(`hidden`),a&&a.classList.add(`hidden`),s()}),document.addEventListener(`click`,e=>{let t=document.getElementById(`club-search-wrapper`);t&&!t.contains(e.target)&&a&&a.classList.add(`hidden`)})}window.viewMemberWHSProfile=async function(e){let t=document.getElementById(`hub-tab-individual`),n=document.getElementById(`hub-tab-club`);if(s=`INDIVIDUAL`,t&&n&&(t.className=`px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20`,n.className=`px-5 py-3 rounded-2xl font-black text-xs uppercase tracking-wider transition-all flex items-center gap-2 bg-slate-900 text-slate-400 border border-slate-800 hover:text-white`),a=i.find(t=>String(t.id)===String(e)),a){let{data:e}=await r.from(`member_scores`).select(`*`).eq(`member_id`,a.id).order(`date_played`,{ascending:!1}).limit(20);o=e||[]}b()};function b(){let e=document.getElementById(`whs-hub-content`);if(!e)return;if(!a){e.innerHTML=`
            <div class="py-16 text-center bg-slate-900 border border-slate-800 rounded-3xl">
                <p class="text-xs text-slate-400 font-bold uppercase">Selecciona un jugador para consultar.</p>
            </div>`;return}let t=l,n=new Date;n.setDate(n.getDate()-365);let r=n.toISOString().split(`T`)[0],s=o.filter(e=>e.date_played>=r),c=p(s.length>0?Math.min(...s.map(e=>parseFloat(e.differential)||99)):a.current_handicap||0),d=[...o].sort((e,t)=>(parseFloat(e.differential)||0)-(parseFloat(t.differential)||0)),f=o.length,h=1;h=f>=20?8:f>=19?7:f>=17?6:f>=15?5:f>=12?4:f>=9?3:f>=6?2:1;let g=new Set(d.slice(0,h).map(e=>e.id)),_=parseFloat(a.current_handicap||0),v=u.map(e=>{let t=m(_,e);return{...e,ch:t}});e.innerHTML=`
        <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-8 animate-fade-in">
            <!-- Selector Dropdown Inside Individual View -->
            <div class="flex flex-col sm:flex-row items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div class="relative w-full sm:w-80">
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Seleccionar Jugador</label>
                    <select id="select-individual-member" class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-xs font-black text-white focus:outline-none focus:border-amber-400">
                        ${i.map(e=>`
                            <option value="${e.id}" ${String(e.id)===String(a.id)?`selected`:``}>${e.name} (#${e.member_number})</option>
                        `).join(``)}
                    </select>
                </div>
                <button onclick="window.renderHandicapHubModule(document.getElementById('handicap-app-root'))" class="px-4 py-2.5 bg-slate-800 text-slate-400 hover:text-white rounded-xl text-xs font-bold uppercase transition-all">
                    ⬅ Volver a Tabla General del Club
                </button>
            </div>

            <!-- Header SpeiHandicap Card -->
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-slate-800">
                <div class="flex items-center gap-5">
                    <div class="p-3 bg-white/5 border border-white/10 rounded-2xl shadow-xl backdrop-blur-md shrink-0">
                        <img src="./golcolima.jpg" alt="Club Colima" class="h-16 w-auto object-contain rounded-xl" onerror="this.style.display='none'">
                    </div>
                    <div>
                        <p class="font-black text-blue-400 text-lg uppercase tracking-wide">ID Jugador: #${a.member_number}</p>
                        <h3 class="font-black text-white text-2xl uppercase tracking-tight leading-tight mt-0.5">${a.name}</h3>
                        <p class="text-xs text-slate-400 font-bold uppercase mt-1">Fecha Handicap: <span class="text-slate-200">${t}</span></p>
                    </div>
                </div>

                <div class="flex items-center gap-4 bg-slate-950/80 p-4 border border-slate-800 rounded-2xl self-start lg:self-auto">
                    <div class="text-center px-4 border-r border-slate-800">
                        <p class="text-[9px] font-black text-slate-400 uppercase tracking-widest">Handicap Índice</p>
                        <p class="text-3xl font-black text-rose-500 leading-tight mt-0.5">${p(_)}</p>
                    </div>
                    <div class="text-center px-4">
                        <p class="text-[9px] font-black text-amber-400 uppercase tracking-widest">Low H.I. (365d)</p>
                        <p class="text-3xl font-black text-amber-400 leading-tight mt-0.5">${c}</p>
                    </div>
                </div>
            </div>

            <!-- Color Badges (Tee Handicap Calculator - Exact Match to SpeiHandicap) -->
            <div>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Calculadora de Handicap de Campo por Marca de Salida (Tees)</p>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    ${v.map(e=>`
                        <div class="p-5 bg-slate-950 border border-slate-800 rounded-2xl text-center space-y-2 shadow-lg hover:border-slate-700 transition-all">
                            <span class="inline-block px-5 py-1.5 rounded-lg font-black text-sm uppercase shadow-md ${e.bg}">${e.label}</span>
                            <p class="text-4xl font-black ${e.text} mt-2">${e.ch}</p>
                            <p class="text-xs font-bold text-slate-500 uppercase">RTG: ${e.rating} / SLO: ${e.slope}</p>
                        </div>
                    `).join(``)}
                </div>
            </div>

            <!-- 20 Recent WHS Rounds Table (Estilo SpeiHandicap) -->
            <div class="space-y-4 pt-2">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <h4 class="font-black text-white uppercase text-base tracking-tight flex items-center gap-2">
                        <span class="material-icons text-amber-400">history_edu</span> Historial de Rondas WHS Registradas
                    </h4>
                    <span class="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/20">
                        🌟 Las rondas verdes promedian tu Handicap Index actual (${h} de ${f})
                    </span>
                </div>

                ${o.length===0?`
                    <div class="py-16 text-center bg-slate-950/60 border border-slate-800 rounded-3xl">
                        <span class="material-icons text-slate-600 text-5xl mb-2">sports_golf</span>
                        <p class="text-sm font-black text-slate-400 uppercase tracking-widest">Aún no hay tarjetas capturadas para este jugador</p>
                        <p class="text-xs text-slate-600 mt-1">Registra rondas desde el portal de Caddie Master para actualizar este historial.</p>
                    </div>
                `:`
                    <div class="bg-slate-950/80 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
                        <div class="overflow-x-auto custom-scrollbar">
                            <table class="w-full text-left border-collapse min-w-[750px] text-xs">
                                <thead>
                                    <tr class="bg-slate-900 border-b border-slate-800 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                                        <th class="px-5 py-4">Fecha</th>
                                        <th class="px-5 py-4">Campo</th>
                                        <th class="px-5 py-4 text-center">Tee</th>
                                        <th class="px-5 py-4 text-center">RTG / SLO</th>
                                        <th class="px-5 py-4 text-center">Score (SA)</th>
                                        <th class="px-5 py-4 text-center">Diferencial (WHS)</th>
                                        <th class="px-5 py-4 text-right">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-800/60">
                                    ${o.map(e=>{let t=g.has(e.id),n=p(parseFloat(e.differential||0)),r=e.tee_color||`BLANCO`;return`
                                            <tr class="hover:bg-slate-800/50 transition-colors ${t?`bg-emerald-500/10`:``}">
                                                <td class="px-5 py-4 text-slate-300 font-bold">${new Date(e.date_played+`T00:00:00`).toLocaleDateString(`es-MX`,{day:`2-digit`,month:`short`,year:`numeric`})}</td>
                                                <td class="px-5 py-4 font-black text-white uppercase text-sm">${e.course_name||`CLUB DE GOLF COLIMA`}</td>
                                                <td class="px-5 py-4 text-center">
                                                    <span class="px-3 py-1 rounded-lg font-black text-[10px] uppercase bg-slate-800 text-slate-300 border border-slate-700">${r}</span>
                                                </td>
                                                <td class="px-5 py-4 text-center font-bold text-slate-400">${e.course_rating||67.5} / ${e.slope_rating||114}</td>
                                                <td class="px-5 py-4 text-center font-black text-white text-base">${e.gross_score}</td>
                                                <td class="px-5 py-4 text-center font-black text-base ${t?`text-emerald-400`:`text-slate-400`}">
                                                    ${t?`🌟 `:``}${n}
                                                </td>
                                                <td class="px-5 py-4 text-right">
                                                    <div class="flex items-center justify-end gap-2">
                                                        ${e.hole_scores?`
                                                            <button onclick="window.toggleWHSDetail('${e.id}')" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-xs font-bold text-slate-300 transition-all">
                                                                Ver 18 Hoyos
                                                            </button>
                                                        `:``}
                                                        <button onclick="window.deleteWHSScoreItem('${e.id}', '${a.id}')" title="Eliminar ronda" class="w-8 h-8 bg-rose-500/10 hover:bg-rose-500/30 border border-rose-500/30 text-rose-400 rounded-xl flex items-center justify-center transition-all">
                                                            <span class="material-icons" style="font-size:16px">delete</span>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            ${e.hole_scores?`
                                                <tr id="whs-detail-${e.id}" class="hidden bg-slate-950">
                                                    <td colspan="7" class="p-5">
                                                        <div class="text-xs font-black text-slate-400 uppercase mb-3 flex items-center justify-between">
                                                            <span>Tarjeta Hoyo por Hoyo (${e.gross_score} Golpes Gross)</span>
                                                            <span class="text-emerald-400 font-bold">Diferencial: ${n}</span>
                                                        </div>
                                                        <div class="grid grid-cols-9 sm:grid-cols-18 gap-1.5 text-center text-xs">
                                                            ${Object.entries(e.hole_scores).map(([e,t])=>`
                                                                <div class="p-2 bg-slate-900 border border-slate-800 rounded-xl">
                                                                    <p class="text-[9px] font-bold text-slate-500">${e.replace(`h`,`#`)}</p>
                                                                    <p class="font-black text-emerald-400 text-sm">${t||`—`}</p>
                                                                </div>
                                                            `).join(``)}
                                                        </div>
                                                    </td>
                                                </tr>
                                            `:``}
                                        `}).join(``)}
                                </tbody>
                            </table>
                        </div>
                    </div>
                `}
            </div>
        </div>
    `,document.getElementById(`select-individual-member`).onchange=e=>{window.viewMemberWHSProfile(e.target.value)}}window.toggleWHSDetail=function(e){let t=document.getElementById(`whs-detail-${e}`);t&&t.classList.toggle(`hidden`)},window.deleteWHSScoreItem=async function(e,t){window.showNotification(`Eliminar Tarjeta`,`¿Deseas eliminar esta ronda del historial del socio? El Handicap Index se recalculará automáticamente.`,`confirm`,async()=>{let{error:n}=await r.from(`member_scores`).delete().eq(`id`,e);if(n){window.showNotification(`Error`,`No se pudo eliminar la tarjeta: `+n.message,`error`);return}await x(t),window.showNotification(`Tarjeta Eliminada`,`Se eliminó la ronda y se recalculó el Handicap del socio.`,`success`),await selectMemberForWHS(t)})};async function x(e){try{let{data:t}=await r.from(`member_scores`).select(`*`).eq(`member_id`,e).order(`date_played`,{ascending:!1}).limit(20);if(!t||t.length===0)return;let i=t.map(e=>parseFloat(e.differential)||0).sort((e,t)=>e-t),a=i.length,o=1;o=a>=20?8:a>=19?7:a>=17?6:a>=15?5:a>=12?4:a>=9?3:a>=6?2:1;let s=i.slice(0,o).reduce((e,t)=>e+t,0)/o,c=parseFloat(s.toFixed(1));await n.from(`members`).update({current_handicap:c}).eq(`id`,e)}catch(e){console.error(`Error recalculating handicap:`,e)}}export{d as renderHandicapHubModule};