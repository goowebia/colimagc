var e=async(e,t,n,r)=>{let i=[],a=`noticias`,o=null,s=null,c=[],l=null,u=r||window.showNotification||alert,d=e=>{if(e.galeria&&Array.isArray(e.galeria)&&e.galeria.length>0)return e.galeria.filter(Boolean);if(typeof e.galeria==`string`&&e.galeria.trim())try{let t=JSON.parse(e.galeria);if(Array.isArray(t)&&t.length>0)return t.filter(Boolean)}catch{}if(e.imagen_url&&e.imagen_url.trim()){if(e.imagen_url.startsWith(`[`))try{let t=JSON.parse(e.imagen_url);if(Array.isArray(t)&&t.length>0)return t.filter(Boolean)}catch{}return[e.imagen_url]}return[`./imagenes/feria.jpeg`]},f=async()=>{try{let{data:e,error:n}=await t.from(`noticias`).select(`*`).order(`fecha_publicacion`,{ascending:!1}).order(`created_at`,{ascending:!1});!n&&e?i=e:(console.warn(`Error loading records from Supabase:`,n),i=[])}catch(e){console.error(`Failed to load records:`,e),i=[]}};await f();let p=async(e,t=1920,n=1280,r=.85)=>new Promise(i=>{if(!e.type.startsWith(`image/`)){i({file:e,preview:URL.createObjectURL(e)});return}let a=new FileReader;a.readAsDataURL(e),a.onload=a=>{let o=new Image;o.src=a.target.result,o.onload=()=>{let s=o.width,c=o.height;(s>t||c>n)&&(s/t>c/n?(c=Math.round(c*t/s),s=t):(s=Math.round(s*n/c),c=n));let l=document.createElement(`canvas`);l.width=s,l.height=c;let u=l.getContext(`2d`);u.imageSmoothingEnabled=!0,u.imageSmoothingQuality=`high`,u.drawImage(o,0,0,s,c);let d=`image/webp`;l.toBlob(t=>{if(t){let n=e.name.replace(/\.[^/.]+$/,``)+`.webp`;i({file:new File([t],n,{type:d,lastModified:Date.now()}),preview:l.toDataURL(d,r),size:t.size})}else i({file:e,preview:a.target.result,size:e.size})},d,r)},o.onerror=()=>i({file:e,preview:a.target.result,size:e.size})},a.onerror=()=>i({file:e,preview:``,size:e.size})}),m=e=>e.subtitulo?.toUpperCase()===`EVENTO`||e.subtitulo?.toUpperCase().includes(`EVENTO`),h=()=>{let t=i.filter(e=>!m(e)),n=i.filter(e=>m(e)),r=t.length,o=t.filter(e=>e.activo).length,s=n.length;e.innerHTML=`
            <div class="animate-fade-in space-y-6 max-w-7xl mx-auto">
                <!-- Header with Action Buttons -->
                <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
                    <div class="space-y-1.5">
                        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[10px] font-black uppercase tracking-widest">
                            <span class="material-icons text-xs">feed</span> Comunicación & Eventos
                        </div>
                        <h2 class="text-2xl sm:text-3xl font-black tracking-tight text-white uppercase">Gestión de Noticias & Eventos</h2>
                        <p class="text-slate-400 text-xs mt-1 max-w-2xl leading-relaxed">
                            Crea y administra los comunicados y los próximos eventos del Club de Golf Colima. Las imágenes se comprimen automáticamente y se sincronizan con la página oficial.
                        </p>
                    </div>
                    <div class="flex flex-wrap items-center gap-3">
                        <button id="btn-open-modal-noticia" class="flex items-center gap-2 px-5 py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-2xl text-xs font-black uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-xl shadow-amber-500/20 cursor-pointer">
                            <span class="material-icons text-base">newspaper</span> Publicar Noticia
                        </button>
                        <button id="btn-open-modal-evento" class="flex items-center gap-2 px-5 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-2xl text-xs font-black uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-xl shadow-emerald-500/20 cursor-pointer">
                            <span class="material-icons text-base">event</span> Crear Evento
                        </button>
                    </div>
                </div>

                <!-- Stats Quick Overview -->
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-5">
                    <div class="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex items-center justify-between shadow-lg">
                        <div>
                            <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest">Noticias Publicadas</p>
                            <h3 class="text-2xl font-black text-amber-400 mt-1">${o} <span class="text-xs font-bold text-slate-400">/ ${r}</span></h3>
                            <p class="text-[10px] font-bold text-slate-400 mt-0.5">Visibles en sitio web</p>
                        </div>
                        <div class="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                            <span class="material-icons">newspaper</span>
                        </div>
                    </div>

                    <div class="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex items-center justify-between shadow-lg">
                        <div>
                            <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest">Próximos Eventos</p>
                            <h3 class="text-2xl font-black text-emerald-400 mt-1">${n.filter(e=>e.activo).length} <span class="text-xs font-bold text-slate-400">/ ${s}</span></h3>
                            <p class="text-[10px] font-bold text-slate-400 mt-0.5">En cartelera web</p>
                        </div>
                        <div class="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                            <span class="material-icons">event</span>
                        </div>
                    </div>

                    <div class="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex items-center justify-between shadow-lg">
                        <div>
                            <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest">Total Registros</p>
                            <h3 class="text-2xl font-black text-white mt-1">${i.length}</h3>
                            <p class="text-[10px] font-bold text-slate-400 mt-0.5">Publicaciones totales</p>
                        </div>
                        <div class="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                            <span class="material-icons">dashboard</span>
                        </div>
                    </div>
                </div>

                <!-- Navigation Tabs (Noticias vs Eventos) -->
                <div class="flex p-1.5 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-slate-800 max-w-md shadow-inner">
                    <button id="tab-btn-noticias" class="flex-1 py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${a===`noticias`?`bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20`:`text-slate-400 hover:text-white`}">
                        <span class="material-icons text-sm">newspaper</span> Noticias (${r})
                    </button>
                    <button id="tab-btn-eventos" class="flex-1 py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${a===`eventos`?`bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20`:`text-slate-400 hover:text-white`}">
                        <span class="material-icons text-sm">event</span> Eventos (${s})
                    </button>
                </div>

                <!-- TAB 1: NOTICIAS LIST -->
                <div id="tab-content-noticias" class="${a===`noticias`?`block`:`hidden`} space-y-4">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-xl font-black text-white uppercase tracking-tight">Artículos y Noticias Publicadas</h3>
                            <p class="text-slate-500 text-xs mt-0.5">Notas informativas con galerías de hasta 9 fotografías.</p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        ${t.length===0?`
                            <div class="col-span-full py-16 flex flex-col items-center justify-center gap-4 text-center bg-slate-900/50 border border-slate-800 rounded-3xl p-8">
                                <div class="w-16 h-16 bg-slate-800 rounded-2xl flex items-center justify-center text-slate-500">
                                    <span class="material-icons text-3xl">feed</span>
                                </div>
                                <div class="space-y-1">
                                    <h4 class="text-base font-black text-slate-300 uppercase">Aún no hay noticias creadas</h4>
                                    <p class="text-xs text-slate-500 max-w-sm">Comienza agregando el primer artículo para que aparezca en el sitio web de Colima Golf Club.</p>
                                </div>
                                <button id="btn-crear-primer-noticia" class="mt-2 px-6 py-3 bg-amber-500 text-slate-950 font-black rounded-xl text-xs uppercase tracking-widest shadow-lg shadow-amber-500/20 hover:scale-105 transition-transform cursor-pointer">
                                    Crear Primera Noticia
                                </button>
                            </div>
                        `:t.map(e=>{let t=e.fecha_publicacion?new Date(e.fecha_publicacion+`T00:00:00`).toLocaleDateString(`es-MX`,{day:`2-digit`,month:`long`,year:`numeric`}):`Fecha no especificada`,n=d(e),r=n[0]||`./imagenes/DJI_0001.JPG`,i=e.autor||`Club Colima`,a=e.contenido?e.contenido.length>110?e.contenido.substring(0,110)+`...`:e.contenido:``;return`
                                <div class="bg-slate-900 border ${e.activo?`border-slate-800 hover:border-amber-500/40`:`border-red-950/40 opacity-70`} rounded-3xl overflow-hidden shadow-xl transition-all flex flex-col justify-between group">
                                    <div>
                                        <div class="relative aspect-video w-full overflow-hidden bg-slate-950 border-b border-slate-800">
                                            <img src="${r}" alt="${e.titulo}" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" onerror="this.src='./golcolima.jpg'">
                                            <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>
                                            
                                            <div class="absolute top-3 right-3 flex items-center gap-1.5">
                                                ${n.length>1?`
                                                    <span class="px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider bg-slate-950/80 text-amber-300 border border-amber-500/30 backdrop-blur-md flex items-center gap-1">
                                                        <span class="material-icons" style="font-size:12px">collections</span> ${n.length}
                                                    </span>
                                                `:``}
                                                <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-wider ${e.activo?`bg-emerald-500/90 text-slate-950 shadow-lg`:`bg-slate-800/90 text-slate-400 border border-slate-700`} backdrop-blur-md">
                                                    ${e.activo?`● Publicada`:`○ Pausada`}
                                                </span>
                                            </div>
                                        </div>

                                        <div class="p-6 space-y-2.5">
                                            <div class="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                                                <span class="material-icons text-xs text-amber-400">calendar_today</span>
                                                <span>${t}</span>
                                                <span>·</span>
                                                <span class="text-slate-500">${i}</span>
                                            </div>

                                            <h4 class="text-lg font-black text-white uppercase tracking-tight leading-snug line-clamp-2 group-hover:text-amber-400 transition-colors">
                                                ${e.titulo}
                                            </h4>

                                            <p class="text-xs text-slate-400 leading-relaxed line-clamp-2 font-medium">
                                                ${a}
                                            </p>
                                        </div>
                                    </div>

                                    <div class="px-6 py-4 border-t border-slate-800/80 bg-slate-950/40 flex items-center justify-between gap-2">
                                        <button data-toggle-id="${e.id}" data-activo="${e.activo}" class="btn-toggle-record text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 ${e.activo?`text-amber-400 hover:text-amber-300`:`text-emerald-400 hover:text-emerald-300`} transition-colors cursor-pointer">
                                            <span class="material-icons text-sm">${e.activo?`visibility_off`:`visibility`}</span>
                                            ${e.activo?`Pausar`:`Activar`}
                                        </button>

                                        <div class="flex items-center gap-1.5">
                                            <button data-edit-noticia-id="${e.id}" class="btn-edit-noticia p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition-all cursor-pointer" title="Editar Noticia">
                                                <span class="material-icons text-sm">edit</span>
                                            </button>
                                            <button data-delete-id="${e.id}" data-title="${e.titulo}" class="btn-delete-record p-2 bg-slate-800 hover:bg-red-950 text-slate-400 hover:text-red-400 rounded-xl transition-all cursor-pointer" title="Eliminar Noticia">
                                                <span class="material-icons text-sm">delete</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            `}).join(``)}
                    </div>
                </div>

                <!-- TAB 2: EVENTOS LIST -->
                <div id="tab-content-eventos" class="${a===`eventos`?`block`:`hidden`} space-y-4">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-xl font-black text-white uppercase tracking-tight">Próximos Eventos Registrados</h3>
                            <p class="text-slate-500 text-xs mt-0.5">Publicaciones para la sección Cartelera / Próximos Eventos (2 columnas × 2 filas).</p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        ${n.length===0?`
                            <div class="col-span-full py-16 flex flex-col items-center justify-center gap-4 text-center bg-slate-900/50 border border-slate-800 rounded-3xl p-8">
                                <div class="w-16 h-16 bg-slate-800 rounded-2xl flex items-center justify-center text-slate-500">
                                    <span class="material-icons text-3xl">event</span>
                                </div>
                                <div class="space-y-1">
                                    <h4 class="text-base font-black text-slate-300 uppercase">Aún no hay eventos creados</h4>
                                    <p class="text-xs text-slate-500 max-w-sm">Crea tu primer evento para que aparezca en la sección de PRÓXIMOS EVENTOS de la landing page.</p>
                                </div>
                                <button id="btn-crear-primer-evento" class="mt-2 px-6 py-3 bg-emerald-500 text-slate-950 font-black rounded-xl text-xs uppercase tracking-widest shadow-lg shadow-emerald-500/20 hover:scale-105 transition-transform cursor-pointer">
                                    Crear Primer Evento
                                </button>
                            </div>
                        `:n.map(e=>{let t=e.autor&&e.autor!==`Administrador`&&e.autor!==`Club de Golf Colima`?e.autor:e.fecha_publicacion||`Próximamente`,n=e.imagen_url||e.galeria&&e.galeria[0]||`./imagenes/feria.jpeg`,r=e.contenido?e.contenido.length>120?e.contenido.substring(0,120)+`...`:e.contenido:``;return`
                                <div class="bg-slate-900 border ${e.activo?`border-slate-800 hover:border-emerald-500/40`:`border-red-950/40 opacity-70`} rounded-3xl overflow-hidden shadow-xl transition-all flex flex-col justify-between group">
                                    <div>
                                        <div class="relative aspect-[4/3] w-full overflow-hidden bg-slate-950 border-b border-slate-800">
                                            <img src="${n}" alt="${e.titulo}" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" onerror="this.src='./golcolima.jpg'">
                                            <div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent"></div>
                                            
                                            <div class="absolute top-3 right-3">
                                                <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-wider ${e.activo?`bg-emerald-500 text-slate-950 shadow-lg`:`bg-slate-800/90 text-slate-400 border border-slate-700`} backdrop-blur-md">
                                                    ${e.activo?`● Publicado`:`○ Pausado`}
                                                </span>
                                            </div>

                                            <div class="absolute bottom-3 left-3">
                                                <span class="px-3 py-1 bg-purple-500/30 border border-purple-400/40 text-purple-300 rounded-xl text-[9px] font-black uppercase tracking-wider backdrop-blur-md shadow-lg">
                                                    ${t}
                                                </span>
                                            </div>
                                        </div>

                                        <div class="p-6 space-y-2">
                                            <h4 class="text-lg font-black text-white uppercase tracking-tight leading-snug line-clamp-2 group-hover:text-emerald-400 transition-colors">
                                                ${e.titulo}
                                            </h4>
                                            <p class="text-xs text-slate-400 leading-relaxed line-clamp-3 font-medium">
                                                ${r}
                                            </p>
                                        </div>
                                    </div>

                                    <div class="px-6 py-4 border-t border-slate-800/80 bg-slate-950/40 flex items-center justify-between gap-2">
                                        <button data-toggle-id="${e.id}" data-activo="${e.activo}" class="btn-toggle-record text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 ${e.activo?`text-amber-400 hover:text-amber-300`:`text-emerald-400 hover:text-emerald-300`} transition-colors cursor-pointer">
                                            <span class="material-icons text-sm">${e.activo?`visibility_off`:`visibility`}</span>
                                            ${e.activo?`Pausar`:`Activar`}
                                        </button>

                                        <div class="flex items-center gap-1.5">
                                            <button data-edit-evento-id="${e.id}" class="btn-edit-evento p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition-all cursor-pointer" title="Editar Evento">
                                                <span class="material-icons text-sm">edit</span>
                                            </button>
                                            <button data-delete-id="${e.id}" data-title="${e.titulo}" class="btn-delete-record p-2 bg-slate-800 hover:bg-red-950 text-slate-400 hover:text-red-400 rounded-xl transition-all cursor-pointer" title="Eliminar Evento">
                                                <span class="material-icons text-sm">delete</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            `}).join(``)}
                    </div>
                </div>
            </div>

            <!-- 1. MODAL NOTICIA (HASTA 9 FOTOS) -->
            <div id="modal-noticia" class="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 hidden">
                <div class="bg-slate-900 border border-slate-800 w-full max-w-3xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-scale-up">
                    <div class="px-6 sm:px-8 py-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                                <span class="material-icons text-xl" id="modal-noticia-icon">newspaper</span>
                            </div>
                            <div>
                                <h3 class="text-lg font-black text-white uppercase tracking-tight" id="modal-noticia-title">Nueva Noticia</h3>
                                <p class="text-[10px] text-slate-400 uppercase tracking-wider">Galería de hasta 9 fotos</p>
                            </div>
                        </div>
                        <button id="btn-close-modal-noticia" class="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors">
                            <span class="material-icons">close</span>
                        </button>
                    </div>

                    <form id="form-noticia" class="p-6 sm:p-8 overflow-y-auto space-y-6 flex-1">
                        <!-- Galería Noticia -->
                        <div class="space-y-3">
                            <div class="flex items-center justify-between">
                                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                    Galería de Fotos <span class="text-amber-400">(Hasta 9 fotos · 1ª es portada)</span>
                                </label>
                                <span id="noticia-photo-count-badge" class="text-[10px] font-black text-slate-400 uppercase">0 / 9 fotos</span>
                            </div>

                            <div id="noticia-photos-preview-grid" class="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3"></div>

                            <div id="noticia-image-dropzone" class="border-2 border-dashed border-slate-700 hover:border-amber-400/60 rounded-2xl p-5 text-center cursor-pointer transition-all bg-slate-950/60 relative overflow-hidden group">
                                <input type="file" id="input-noticia-image-file" multiple accept="image/jpeg,image/png,image/webp,image/jpg" class="hidden">
                                <div class="py-3 space-y-1.5">
                                    <div class="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-400 mx-auto flex items-center justify-center group-hover:scale-110 transition-transform">
                                        <span class="material-icons text-xl">add_photo_alternate</span>
                                    </div>
                                    <p class="text-xs font-bold text-white uppercase tracking-wider">Haz clic para agregar fotos o arrástralas aquí</p>
                                    <p class="text-[10px] text-slate-500">Selecciona fotos (se optimizarán automáticamente en formato WebP liviano)</p>
                                </div>
                            </div>
                        </div>

                        <!-- Título -->
                        <div class="space-y-1.5">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Título del Artículo *</label>
                            <input type="text" id="input-noticia-titulo" required class="w-full px-4 py-3.5 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:border-amber-400 transition-all font-bold text-sm" placeholder="Ej. ¡Arrancó con gran éxito el Ranking Stroke Play!">
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            <div class="space-y-1.5">
                                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Fecha *</label>
                                <input type="date" id="input-noticia-fecha" required class="w-full px-4 py-3 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:border-amber-400 transition-all font-bold text-xs">
                            </div>

                            <div class="space-y-1.5">
                                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Autor / Redactor</label>
                                <input type="text" id="input-noticia-autor" class="w-full px-4 py-3 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:border-amber-400 transition-all font-bold text-xs" placeholder="Club de Golf Colima">
                            </div>

                            <div class="space-y-1.5">
                                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Estado en la Web</label>
                                <select id="input-noticia-activo" class="w-full px-4 py-3 bg-slate-800/80 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-amber-400 transition-all font-bold text-xs">
                                    <option value="true">Visible (Publicado)</option>
                                    <option value="false">Oculto (Borrador / Pausado)</option>
                                </select>
                            </div>
                        </div>

                        <div class="space-y-1.5">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Contenido / Redacción del Artículo *</label>
                            <textarea id="input-noticia-contenido" required rows="5" class="w-full px-4 py-3.5 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:border-amber-400 transition-all font-medium text-xs leading-relaxed" placeholder="Escribe aquí el texto detallado de la noticia..."></textarea>
                        </div>
                    </form>

                    <div class="px-6 sm:px-8 py-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-end gap-3">
                        <button type="button" id="btn-cancel-modal-noticia" class="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold uppercase tracking-wider text-xs transition-all cursor-pointer">
                            Cancelar
                        </button>
                        <button type="button" id="btn-submit-noticia" class="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl font-black uppercase tracking-widest text-xs hover:scale-[1.02] active:scale-95 transition-all shadow-lg shadow-amber-500/20 flex items-center gap-2 cursor-pointer">
                            <span class="material-icons text-sm">save</span> <span id="submit-noticia-btn-text">Publicar Noticia</span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- 2. MODAL EVENTO (1 FOTO PÓSTER + DESCRIPCIÓN) -->
            <div id="modal-evento" class="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 hidden">
                <div class="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-scale-up">
                    <div class="px-6 sm:px-8 py-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                                <span class="material-icons text-xl" id="modal-evento-icon">event</span>
                            </div>
                            <div>
                                <h3 class="text-lg font-black text-white uppercase tracking-tight" id="modal-evento-title">Crear Próximo Evento</h3>
                                <p class="text-[10px] text-slate-400 uppercase tracking-wider">Póster oficial y detalles</p>
                            </div>
                        </div>
                        <button id="btn-close-modal-evento" class="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors">
                            <span class="material-icons">close</span>
                        </button>
                    </div>

                    <form id="form-evento" class="p-6 sm:p-8 overflow-y-auto space-y-6 flex-1">
                        <!-- Imagen Póster del Evento -->
                        <div class="space-y-2">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                Imagen / Póster del Evento * <span class="text-emerald-400">(Se optimiza automáticamente)</span>
                            </label>

                            <div id="evento-photo-preview-box" class="hidden relative aspect-[4/3] max-w-sm mx-auto rounded-2xl overflow-hidden border-2 border-emerald-500 bg-slate-950 shadow-xl group">
                                <img id="evento-preview-img" src="" alt="Póster Evento" class="w-full h-full object-cover">
                                <button type="button" id="btn-remove-evento-photo" class="absolute top-2 right-2 w-8 h-8 rounded-full bg-red-600/90 hover:bg-red-500 text-white flex items-center justify-center transition-all cursor-pointer shadow-lg">
                                    <span class="material-icons text-base">close</span>
                                </button>
                            </div>

                            <div id="evento-image-dropzone" class="border-2 border-dashed border-slate-700 hover:border-emerald-400/60 rounded-2xl p-6 text-center cursor-pointer transition-all bg-slate-950/60 relative overflow-hidden group">
                                <input type="file" id="input-evento-image-file" accept="image/jpeg,image/png,image/webp,image/jpg" class="hidden">
                                <div class="py-3 space-y-1.5">
                                    <div class="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 mx-auto flex items-center justify-center group-hover:scale-110 transition-transform">
                                        <span class="material-icons text-2xl">add_photo_alternate</span>
                                    </div>
                                    <p class="text-xs font-bold text-white uppercase tracking-wider">Subir Póster o Flyer del Evento</p>
                                    <p class="text-[10px] text-slate-500">Haz clic o arrastra la imagen aquí (se guardará comprimida en tu hosting)</p>
                                </div>
                            </div>
                        </div>

                        <!-- Título del Evento -->
                        <div class="space-y-1.5">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Nombre o Título del Evento *</label>
                            <input type="text" id="input-evento-titulo" required class="w-full px-4 py-3.5 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-400 transition-all font-bold text-sm" placeholder="Ej. Torneo Anual de Golf Feria de Todos Los Santos">
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div class="space-y-1.5">
                                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Fecha o Período del Evento *</label>
                                <input type="text" id="input-evento-fecha" required class="w-full px-4 py-3 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-400 transition-all font-bold text-xs" placeholder="Ej. 5 al 8 de Noviembre 2026">
                            </div>

                            <div class="space-y-1.5">
                                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Estado en la Web</label>
                                <select id="input-evento-activo" class="w-full px-4 py-3 bg-slate-800/80 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-400 transition-all font-bold text-xs">
                                    <option value="true">Visible (Publicado)</option>
                                    <option value="false">Oculto (Borrador / Pausado)</option>
                                </select>
                            </div>
                        </div>

                        <!-- Descripción del Evento -->
                        <div class="space-y-1.5">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Descripción / Información del Evento *</label>
                            <textarea id="input-evento-contenido" required rows="5" class="w-full px-4 py-3.5 bg-slate-800/80 border border-slate-700 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-400 transition-all font-medium text-xs leading-relaxed" placeholder="Escribe los detalles, categorías, premios y dinámica del evento..."></textarea>
                        </div>
                    </form>

                    <div class="px-6 sm:px-8 py-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-end gap-3">
                        <button type="button" id="btn-cancel-modal-evento" class="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold uppercase tracking-wider text-xs transition-all cursor-pointer">
                            Cancelar
                        </button>
                        <button type="button" id="btn-submit-evento" class="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl font-black uppercase tracking-widest text-xs hover:scale-[1.02] active:scale-95 transition-all shadow-lg shadow-emerald-500/20 flex items-center gap-2 cursor-pointer">
                            <span class="material-icons text-sm">save</span> <span id="submit-evento-btn-text">Publicar Evento</span>
                        </button>
                    </div>
                </div>
            </div>
        `,v()},g=()=>{let e=document.getElementById(`noticia-photos-preview-grid`),t=document.getElementById(`noticia-photo-count-badge`),n=document.getElementById(`noticia-image-dropzone`);if(e){if(t&&(t.textContent=`${c.length} / 9 fotos`),n&&(c.length>=9?n.classList.add(`opacity-50`,`pointer-events-none`):n.classList.remove(`opacity-50`,`pointer-events-none`)),c.length===0){e.innerHTML=``,e.classList.add(`hidden`);return}e.classList.remove(`hidden`),e.innerHTML=c.map((e,t)=>`
            <div class="relative aspect-square rounded-2xl overflow-hidden border-2 ${t===0?`border-amber-400 shadow-md shadow-amber-500/20`:`border-slate-700`} bg-slate-950 group">
                <img src="${e.preview}" alt="Foto ${t+1}" class="w-full h-full object-cover">
                <div class="absolute top-1 left-1">
                    <span class="px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${t===0?`bg-amber-400 text-slate-950`:`bg-slate-900/90 text-slate-300`} backdrop-blur-md">
                        ${t===0?`★ Portada`:`#${t+1}`}
                    </span>
                </div>
                <button type="button" data-remove-noticia-idx="${t}" class="btn-remove-noticia-photo absolute top-1 right-1 w-6 h-6 rounded-full bg-red-600/90 hover:bg-red-500 text-white flex items-center justify-center transition-all opacity-90 group-hover:opacity-100 cursor-pointer shadow-md">
                    <span class="material-icons" style="font-size:14px">close</span>
                </button>
            </div>
        `).join(``),e.querySelectorAll(`.btn-remove-noticia-photo`).forEach(e=>{e.onclick=t=>{t.stopPropagation();let n=parseInt(e.getAttribute(`data-remove-noticia-idx`),10);c.splice(n,1),g()}})}},_=()=>{let e=document.getElementById(`evento-photo-preview-box`),t=document.getElementById(`evento-preview-img`),n=document.getElementById(`evento-image-dropzone`);!e||!n||(l&&l.preview?(t.src=l.preview,e.classList.remove(`hidden`),n.classList.add(`hidden`)):(e.classList.add(`hidden`),n.classList.remove(`hidden`)))},v=()=>{let e=document.getElementById(`tab-btn-noticias`),n=document.getElementById(`tab-btn-eventos`),r=document.getElementById(`tab-content-noticias`),m=document.getElementById(`tab-content-eventos`);e&&n&&(e.onclick=()=>{a=`noticias`,e.className=`flex-1 py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20`,n.className=`flex-1 py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer text-slate-400 hover:text-white`,r.classList.remove(`hidden`),m.classList.add(`hidden`)},n.onclick=()=>{a=`eventos`,n.className=`flex-1 py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20`,e.className=`flex-1 py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer text-slate-400 hover:text-white`,m.classList.remove(`hidden`),r.classList.add(`hidden`)});let v=document.getElementById(`modal-noticia`),y=document.getElementById(`btn-open-modal-noticia`),b=document.getElementById(`btn-crear-primer-noticia`),x=document.getElementById(`btn-close-modal-noticia`),S=document.getElementById(`btn-cancel-modal-noticia`),C=document.getElementById(`noticia-image-dropzone`),w=document.getElementById(`input-noticia-image-file`),T=document.getElementById(`btn-submit-noticia`),E=()=>{o=null,c=[],document.getElementById(`modal-noticia-title`).textContent=`Publicar Nueva Noticia`,document.getElementById(`submit-noticia-btn-text`).textContent=`Publicar Noticia`,document.getElementById(`input-noticia-titulo`).value=``,document.getElementById(`input-noticia-fecha`).value=new Date().toISOString().split(`T`)[0];let e=sessionStorage.getItem(`cgc_user_data`),t=e?JSON.parse(e):null;document.getElementById(`input-noticia-autor`).value=t&&t.full_name?t.full_name:`Club de Golf Colima`,document.getElementById(`input-noticia-activo`).value=`true`,document.getElementById(`input-noticia-contenido`).value=``,w.value=``,g(),v.classList.remove(`hidden`)};y&&(y.onclick=E),b&&(b.onclick=E);let D=()=>{v.classList.add(`hidden`),o=null,c=[]};x&&(x.onclick=D),S&&(S.onclick=D);let O=async e=>{let t=Array.from(e),n=9-c.length;if(n<=0){u(`Límite alcanzado`,`Ya has alcanzado el límite máximo de 9 fotos para esta noticia.`,`error`);return}let r=t.slice(0,n),i=document.getElementById(`noticia-photo-count-badge`);i&&(i.textContent=`Optimizando ${r.length} foto(s)...`);for(let e of r){let t=await p(e);c.push({type:`file`,file:t.file,preview:t.preview})}g()};C&&w&&(C.onclick=()=>w.click(),w.onchange=e=>{e.target.files&&e.target.files.length>0&&(O(e.target.files),w.value=``)},C.ondragover=e=>{e.preventDefault(),C.classList.add(`border-amber-400`)},C.ondragleave=()=>{C.classList.remove(`border-amber-400`)},C.ondrop=e=>{e.preventDefault(),C.classList.remove(`border-amber-400`),e.dataTransfer.files&&e.dataTransfer.files.length>0&&O(e.dataTransfer.files)}),document.querySelectorAll(`.btn-edit-noticia`).forEach(e=>{e.onclick=()=>{let t=e.getAttribute(`data-edit-noticia-id`),n=i.find(e=>e.id===t);n&&(o=t,c=d(n).map(e=>({type:`url`,url:e,preview:e})),document.getElementById(`modal-noticia-title`).textContent=`Editar Noticia`,document.getElementById(`submit-noticia-btn-text`).textContent=`Guardar Cambios`,document.getElementById(`input-noticia-titulo`).value=n.titulo||``,document.getElementById(`input-noticia-fecha`).value=n.fecha_publicacion||new Date().toISOString().split(`T`)[0],document.getElementById(`input-noticia-autor`).value=n.autor||`Club de Golf Colima`,document.getElementById(`input-noticia-activo`).value=n.activo?`true`:`false`,document.getElementById(`input-noticia-contenido`).value=n.contenido||``,g(),v.classList.remove(`hidden`))}}),T&&(T.onclick=async()=>{let e=document.getElementById(`input-noticia-titulo`).value.trim(),n=document.getElementById(`input-noticia-fecha`).value,r=document.getElementById(`input-noticia-autor`).value.trim()||`Club de Golf Colima`,i=document.getElementById(`input-noticia-activo`).value===`true`,a=document.getElementById(`input-noticia-contenido`).value.trim();if(!e){u(`Título Requerido`,`Por favor ingresa el título de la noticia.`,`error`);return}if(!a){u(`Contenido Requerido`,`Por favor redacta el contenido del artículo.`,`error`);return}T.disabled=!0,T.innerHTML=`<span class="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span> Guardando fotos...`;try{let s=[],l=[`/upload.php`,`${window.location.origin}/upload.php`,`https://colimagolf.com/upload.php`];for(let e=0;e<c.length;e++){let t=c[e];if(t.type===`url`&&t.url)s.push(t.url);else if(t.type===`file`&&t.file){T.innerHTML=`<span class="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span> Subiendo foto ${e+1} de ${c.length}...`;let n=new FormData;n.append(`image`,t.file);let r=null;for(let e of l)try{let t=await fetch(e,{method:`POST`,body:n});if(t.ok){let e=await t.json();if(e.success&&(e.url||e.relative_url)){r=e.url||e.relative_url;break}}}catch{}r&&s.push(r)}}s.length===0&&s.push(`./imagenes/feria.jpeg`);let d=s[0],p={titulo:e,subtitulo:``,fecha_publicacion:n,autor:r,activo:i,contenido:a,imagen_url:d,galeria:s},{error:m}=o?await t.from(`noticias`).update(p).eq(`id`,o):await t.from(`noticias`).insert([p]);m&&(m.message?.includes(`galeria`)||m.code===`42703`)&&(delete p.galeria,p.imagen_url=s.length>1?JSON.stringify(s):d,m=(o?await t.from(`noticias`).update(p).eq(`id`,o):await t.from(`noticias`).insert([p])).error),m?u(`Error al Guardar`,m.message||`No se pudo guardar en Supabase.`,`error`):(u(`¡Éxito!`,o?`Noticia actualizada correctamente.`:`Noticia publicada con éxito.`,`success`),D(),await f(),h())}catch(e){console.error(`Save error:`,e),u(`Error`,`Ocurrió un error inesperado al procesar la noticia.`,`error`)}finally{T.disabled=!1,T.innerHTML=`<span class="material-icons text-sm">save</span> <span id="submit-noticia-btn-text">${o?`Guardar Cambios`:`Publicar Noticia`}</span>`}});let k=document.getElementById(`modal-evento`),A=document.getElementById(`btn-open-modal-evento`),j=document.getElementById(`btn-crear-primer-evento`),M=document.getElementById(`btn-close-modal-evento`),N=document.getElementById(`btn-cancel-modal-evento`),P=document.getElementById(`evento-image-dropzone`),F=document.getElementById(`input-evento-image-file`),I=document.getElementById(`btn-remove-evento-photo`),L=document.getElementById(`btn-submit-evento`),R=()=>{s=null,l=null,document.getElementById(`modal-evento-title`).textContent=`Crear Próximo Evento`,document.getElementById(`submit-evento-btn-text`).textContent=`Publicar Evento`,document.getElementById(`input-evento-titulo`).value=``,document.getElementById(`input-evento-fecha`).value=``,document.getElementById(`input-evento-activo`).value=`true`,document.getElementById(`input-evento-contenido`).value=``,F.value=``,_(),k.classList.remove(`hidden`)};A&&(A.onclick=R),j&&(j.onclick=R);let z=()=>{k.classList.add(`hidden`),s=null,l=null};M&&(M.onclick=z),N&&(N.onclick=z),I&&(I.onclick=()=>{l=null,_()});let B=async e=>{if(!e)return;let t=await p(e);l={type:`file`,file:t.file,preview:t.preview},_()};P&&F&&(P.onclick=()=>F.click(),F.onchange=e=>{e.target.files&&e.target.files.length>0&&(B(e.target.files[0]),F.value=``)},P.ondragover=e=>{e.preventDefault(),P.classList.add(`border-emerald-400`)},P.ondragleave=()=>{P.classList.remove(`border-emerald-400`)},P.ondrop=e=>{e.preventDefault(),P.classList.remove(`border-emerald-400`),e.dataTransfer.files&&e.dataTransfer.files.length>0&&B(e.dataTransfer.files[0])}),document.querySelectorAll(`.btn-edit-evento`).forEach(e=>{e.onclick=()=>{let t=e.getAttribute(`data-edit-evento-id`),n=i.find(e=>e.id===t);if(!n)return;s=t;let r=n.imagen_url||n.galeria&&n.galeria[0]||`./imagenes/feria.jpeg`;l={type:`url`,url:r,preview:r},document.getElementById(`modal-evento-title`).textContent=`Editar Evento`,document.getElementById(`submit-evento-btn-text`).textContent=`Guardar Cambios`,document.getElementById(`input-evento-titulo`).value=n.titulo||``,document.getElementById(`input-evento-fecha`).value=n.autor||``,document.getElementById(`input-evento-activo`).value=n.activo?`true`:`false`,document.getElementById(`input-evento-contenido`).value=n.contenido||``,_(),k.classList.remove(`hidden`)}}),L&&(L.onclick=async()=>{let e=document.getElementById(`input-evento-titulo`).value.trim(),n=document.getElementById(`input-evento-fecha`).value.trim(),r=document.getElementById(`input-evento-activo`).value===`true`,i=document.getElementById(`input-evento-contenido`).value.trim();if(!l){u(`Póster Requerido`,`Por favor selecciona o sube una imagen para el evento.`,`error`);return}if(!e){u(`Título Requerido`,`Por favor ingresa el nombre o título del evento.`,`error`);return}if(!n){u(`Fecha Requerida`,`Por favor ingresa la fecha o período del evento (ej. 5 al 8 de Noviembre).`,`error`);return}if(!i){u(`Descripción Requerida`,`Por favor ingresa la descripción o información del evento.`,`error`);return}L.disabled=!0,L.innerHTML=`<span class="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span> Procesando póster...`;try{let o=l.type===`url`?l.url:null;if(l.type===`file`&&l.file){L.innerHTML=`<span class="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span> Subiendo a servidor...`;let e=new FormData;e.append(`image`,l.file);let t=[`/upload.php`,`${window.location.origin}/upload.php`,`https://colimagolf.com/upload.php`];for(let n of t)try{let t=await fetch(n,{method:`POST`,body:e});if(t.ok){let e=await t.json();if(e.success&&(e.url||e.relative_url)){o=e.url||e.relative_url;break}}}catch{}}o||=`./imagenes/feria.jpeg`;let c={titulo:e,subtitulo:`EVENTO`,fecha_publicacion:new Date().toISOString().split(`T`)[0],autor:n,activo:r,contenido:i,imagen_url:o,galeria:[o]},{error:d}=s?await t.from(`noticias`).update(c).eq(`id`,s):await t.from(`noticias`).insert([c]);d&&(d.message?.includes(`galeria`)||d.code===`42703`)&&(delete c.galeria,c.imagen_url=o,d=(s?await t.from(`noticias`).update(c).eq(`id`,s):await t.from(`noticias`).insert([c])).error),d?u(`Error al Guardar`,d.message||`No se pudo guardar el evento en Supabase.`,`error`):(u(`¡Éxito!`,s?`Evento actualizado correctamente.`:`Evento publicado con éxito en la cartelera.`,`success`),z(),a=`eventos`,await f(),h())}catch(e){console.error(`Save evento error:`,e),u(`Error`,`Ocurrió un error inesperado al procesar el evento.`,`error`)}finally{L.disabled=!1,L.innerHTML=`<span class="material-icons text-sm">save</span> <span id="submit-evento-btn-text">${s?`Guardar Cambios`:`Publicar Evento`}</span>`}}),document.querySelectorAll(`.btn-toggle-record`).forEach(e=>{e.onclick=async()=>{let n=e.getAttribute(`data-toggle-id`),r=e.getAttribute(`data-activo`)!==`true`;try{let{error:e}=await t.from(`noticias`).update({activo:r}).eq(`id`,n);e?u(`Error`,e.message,`error`):(u(`Estado actualizado`,r?`El registro ahora está visible en el sitio web.`:`El registro ha sido ocultado del sitio web.`,`success`),await f(),h())}catch{u(`Error`,`No se pudo actualizar el estado.`,`error`)}}}),document.querySelectorAll(`.btn-delete-record`).forEach(e=>{e.onclick=()=>{let n=e.getAttribute(`data-delete-id`),r=e.getAttribute(`data-title`);u(`Confirmar Eliminación`,`¿Estás seguro de que deseas eliminar "${r}"? Esta acción no se puede deshacer.`,`confirm`,async()=>{try{let{error:e}=await t.from(`noticias`).delete().eq(`id`,n);e?u(`Error`,e.message,`error`):(u(`Eliminado`,`La publicación fue eliminada correctamente.`,`success`),await f(),h())}catch{u(`Error`,`No se pudo eliminar el registro.`,`error`)}})}})};h()};export{e as renderNoticiasModule};