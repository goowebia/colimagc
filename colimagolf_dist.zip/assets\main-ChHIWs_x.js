const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/tournaments_detail-Ct_Wjtz7.js","assets/dist-BN2bhVnw.js","assets/members-Ca0vDt4M.js","assets/reception-39jnCKvT.js","assets/caddiemaster-DtO27y1w.js","assets/handicap_hub-CFAUupxZ.js","assets/reports-Bj9vO51Y.js","assets/landing_page-BO_c4zTM.js"])))=>i.map(i=>d[i]);
import"./modulepreload-polyfill-P2Xu9kJm.js";import{t as e}from"./dist-BN2bhVnw.js";var t=async e=>{if(!e)return``;let t=new TextEncoder().encode(e),n=await crypto.subtle.digest(`SHA-256`,t);return Array.from(new Uint8Array(n)).map(e=>e.toString(16).padStart(2,`0`)).join(``)},n=[{key:`dashboard`,label:`Panel Principal (Dashboard)`,icon:`dashboard`,color:`text-primary`},{key:`tournaments`,label:`Gestión de Torneos`,icon:`emoji_events`,color:`text-emerald-400`},{key:`members`,label:`Socios & Membresías`,icon:`groups`,color:`text-blue-400`},{key:`casaclub`,label:`Recepción & Tee Times`,icon:`point_of_sale`,color:`text-emerald-400`},{key:`caddiemaster`,label:`Caddie Master`,icon:`golf_course`,color:`text-teal-400`},{key:`handicaphub`,label:`Handicaps WHS`,icon:`analytics`,color:`text-amber-400`},{key:`reports`,label:`Reportes & Métricas Operativas`,icon:`insights`,color:`text-emerald-400`},{key:`noticias`,label:`Noticias & Artículos`,icon:`feed`,color:`text-amber-400`},{key:`users`,label:`Gestión de Usuarios (Admin)`,icon:`manage_accounts`,color:`text-purple-400`},{key:`landing`,label:`Sitio Web / Landing`,icon:`language`,color:`text-cyan-400`}],r=async(e,r,i)=>{let a=r.schema(`usuarios`),o=[],s=async()=>{try{let{data:e,error:t}=await a.from(`portal_users`).select(`*`).order(`created_at`,{ascending:!0});if(!t&&e&&e.length>0)o=e,localStorage.setItem(`cgc_cached_users`,JSON.stringify(o));else throw Error(t?t.message:`No users`)}catch(e){console.warn(`Falling back to local cached users:`,e);let t=localStorage.getItem(`cgc_cached_users`);o=t?JSON.parse(t):[{id:`default-admin-id`,username:`colimagc`,password_hash:`8c49f828dbbc919041b9ef2b0eb58afac2f53c5699d60e9ef544f9a4eb501603`,full_name:`Administrador`,role:`admin`,allowed_sections:[`dashboard`,`tournaments`,`members`,`casaclub`,`caddiemaster`,`handicaphub`,`reports`,`noticias`,`landing`,`users`],is_active:!0}]}};await s();let c=()=>{e.innerHTML=`
            <div class="animate-fade-in space-y-6 max-w-7xl mx-auto">
                <!-- Header -->
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8">
                    <div>
                        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-[10px] font-black uppercase tracking-widest mb-2">
                            <span class="material-icons text-xs">shield</span> Control de Accesos
                        </div>
                        <h2 class="text-3xl font-black tracking-tight text-white uppercase">Gestión de Usuarios</h2>
                        <p class="text-slate-400 text-xs mt-1">Crea usuarios, asigna contraseñas y selecciona los módulos del portal que pueden acceder.</p>
                    </div>
                    <button onclick="window.openUserModal()" class="flex items-center gap-2 px-6 py-3.5 bg-primary text-slate-900 rounded-xl text-xs font-black uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-lg shadow-primary/20">
                        <span class="material-icons">person_add</span> Crear Nuevo Usuario
                    </button>
                </div>

                <!-- User Cards List -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="users-grid">
                    ${o.map(e=>{let t=Array.isArray(e.allowed_sections)?e.allowed_sections:[],r=e.username===`colimagc`;return`
                            <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 hover:border-purple-500/40 transition-all relative flex flex-col justify-between">
                                <div class="space-y-4">
                                    <div class="flex items-start justify-between">
                                        <div class="flex items-center gap-3">
                                            <div class="w-12 h-12 rounded-2xl ${r?`bg-purple-500/20 text-purple-400 border border-purple-500/30`:`bg-primary/10 text-primary border border-primary/20`} flex items-center justify-center font-black text-lg">
                                                ${e.full_name?e.full_name.charAt(0).toUpperCase():`U`}
                                            </div>
                                            <div>
                                                <h3 class="text-base font-black text-white leading-tight uppercase">${e.full_name}</h3>
                                                <p class="text-xs font-bold text-slate-400 flex items-center gap-1 mt-0.5">
                                                    <span class="material-icons text-slate-500" style="font-size:14px">account_circle</span> @${e.username}
                                                </p>
                                            </div>
                                        </div>
                                        <span class="px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider ${e.role===`admin`?`bg-purple-500/10 text-purple-400 border border-purple-500/20`:`bg-slate-800 text-slate-300`}">
                                            ${e.role||`operator`}
                                        </span>
                                    </div>

                                    <div class="pt-3 border-t border-slate-800">
                                        <p class="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Módulos Autorizados (${t.length}):</p>
                                        <div class="flex flex-wrap gap-1.5">
                                            ${n.map(e=>t.includes(e.key)?`
                                                    <span class="px-2 py-1 bg-slate-800/80 border border-slate-700/60 rounded-lg text-[9px] font-bold text-slate-300 flex items-center gap-1">
                                                        <span class="material-icons ${e.color}" style="font-size:11px">${e.icon}</span> ${e.label.split(` `)[0]}
                                                    </span>`:``).join(``)}
                                        </div>
                                    </div>
                                </div>

                                <div class="pt-4 border-t border-slate-800 flex items-center justify-between mt-4">
                                    <span class="inline-flex items-center gap-1.5 text-[10px] font-bold ${e.is_active===!1?`text-red-400`:`text-emerald-400`}">
                                        <span class="w-2 h-2 rounded-full ${e.is_active===!1?`bg-red-400`:`bg-emerald-400`}"></span>
                                        ${e.is_active===!1?`Inactivo`:`Activo`}
                                    </span>
                                    <div class="flex items-center gap-2">
                                        <button onclick="window.editUserModal('${e.id}')" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 transition-colors">
                                            <span class="material-icons text-sm">edit</span> Editar
                                        </button>
                                        ${r?``:`
                                            <button onclick="window.deleteUserConfirm('${e.id}', '${e.username}')" class="p-1.5 bg-slate-800 hover:bg-red-900/40 text-slate-400 hover:text-red-400 rounded-xl transition-colors" title="Eliminar Usuario">
                                                <span class="material-icons text-sm">delete</span>
                                            </button>
                                        `}
                                    </div>
                                </div>
                            </div>`}).join(``)}
                </div>
            </div>

            <!-- Modal Form for Create / Edit User -->
            <div id="user-modal-overlay" class="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 hidden items-center justify-center p-4">
                <div class="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl p-6 sm:p-8 space-y-6 shadow-2xl animate-fade-in overflow-y-auto max-h-[90vh]">
                    <div class="flex items-center justify-between border-b border-slate-800 pb-4">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center border border-purple-500/20">
                                <span class="material-icons">manage_accounts</span>
                            </div>
                            <div>
                                <h3 id="modal-title" class="text-xl font-black text-white uppercase">Crear Usuario</h3>
                                <p class="text-xs text-slate-400">Configura el acceso al portal para este usuario.</p>
                            </div>
                        </div>
                        <button onclick="window.closeUserModal()" class="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-800">
                            <span class="material-icons">close</span>
                        </button>
                    </div>

                    <form id="user-form" class="space-y-5" onsubmit="event.preventDefault(); window.saveUserSubmit();">
                        <input type="hidden" id="user-id-field" value="">

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div class="space-y-1.5">
                                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Nombre de Usuario *</label>
                                <input type="text" id="user-username" required class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white font-bold text-sm focus:border-primary focus:outline-none" placeholder="ej. juanperez">
                            </div>
                            <div class="space-y-1.5">
                                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Nombre Completo *</label>
                                <input type="text" id="user-fullname" required class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white font-bold text-sm focus:border-primary focus:outline-none" placeholder="ej. Juan Pérez">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div class="space-y-1.5">
                                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Contraseña *</label>
                                <div class="relative">
                                    <input type="password" id="user-password" class="w-full pl-4 pr-10 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white font-bold text-sm focus:border-primary focus:outline-none" placeholder="••••••••">
                                    <button type="button" onclick="window.togglePasswordVisibility()" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white">
                                        <span class="material-icons text-sm" id="pwd-icon">visibility</span>
                                    </button>
                                </div>
                                <p class="text-[9px] text-slate-500" id="pwd-hint">Deja en blanco en edición si no deseas cambiarla.</p>
                            </div>
                            <div class="space-y-1.5">
                                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Rol del Puesto</label>
                                <select id="user-role" class="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white font-bold text-sm focus:border-primary focus:outline-none">
                                    <option value="operator">Operador / Staff</option>
                                    <option value="caddie">Caddie Master</option>
                                    <option value="recepcion">Recepción & Pagos</option>
                                    <option value="admin">Administrador Total</option>
                                </select>
                            </div>
                        </div>

                        <!-- Permissions Section Checkboxes -->
                        <div class="space-y-3 pt-3 border-t border-slate-800">
                            <div class="flex items-center justify-between">
                                <label class="block text-[11px] font-black text-primary uppercase tracking-widest">Seleccionar Secciones Permitidas *</label>
                                <button type="button" onclick="window.toggleAllPermissions(true)" class="text-[10px] text-slate-400 hover:text-white underline font-bold">Seleccionar Todas</button>
                            </div>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                                ${n.map(e=>`
                                    <label class="flex items-center gap-3 p-3 bg-slate-800/60 border border-slate-700/70 rounded-xl cursor-pointer hover:bg-slate-800 transition-colors">
                                        <input type="checkbox" name="user-perm" value="${e.key}" class="w-4 h-4 rounded text-primary focus:ring-primary bg-slate-900 border-slate-700">
                                        <span class="material-icons text-sm ${e.color}">${e.icon}</span>
                                        <span class="text-xs font-bold text-slate-200">${e.label}</span>
                                    </label>
                                `).join(``)}
                            </div>
                        </div>

                        <div class="pt-4 border-t border-slate-800 flex gap-3">
                            <button type="button" onclick="window.closeUserModal()" class="flex-1 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs uppercase tracking-wider">
                                Cancelar
                            </button>
                            <button type="submit" class="flex-1 py-3.5 bg-primary text-slate-900 font-black rounded-xl text-xs uppercase tracking-wider shadow-lg shadow-primary/20 hover:scale-[1.01] active:scale-95 transition-all">
                                Guardar Usuario
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        `};c(),window.openUserModal=()=>{document.getElementById(`user-id-field`).value=``,document.getElementById(`user-username`).value=``,document.getElementById(`user-username`).disabled=!1,document.getElementById(`user-fullname`).value=``,document.getElementById(`user-password`).value=``,document.getElementById(`user-password`).required=!0,document.getElementById(`user-role`).value=`operator`,document.getElementById(`modal-title`).textContent=`Crear Usuario`,document.getElementById(`pwd-hint`).textContent=`Ingresa la contraseña para el nuevo usuario.`,document.querySelectorAll(`input[name="user-perm"]`).forEach(e=>{e.checked=[`dashboard`,`tournaments`].includes(e.value)});let e=document.getElementById(`user-modal-overlay`);e.classList.remove(`hidden`),e.classList.add(`flex`)},window.closeUserModal=()=>{let e=document.getElementById(`user-modal-overlay`);e.classList.add(`hidden`),e.classList.remove(`flex`)},window.togglePasswordVisibility=()=>{let e=document.getElementById(`user-password`),t=document.getElementById(`pwd-icon`);e.type===`password`?(e.type=`text`,t.textContent=`visibility_off`):(e.type=`password`,t.textContent=`visibility`)},window.toggleAllPermissions=e=>{document.querySelectorAll(`input[name="user-perm"]`).forEach(t=>t.checked=e)},window.editUserModal=e=>{let t=o.find(t=>t.id===e||t.username===e);if(!t)return;document.getElementById(`user-id-field`).value=t.id||t.username,document.getElementById(`user-username`).value=t.username,document.getElementById(`user-username`).disabled=t.username===`colimagc`,document.getElementById(`user-fullname`).value=t.full_name,document.getElementById(`user-password`).value=``,document.getElementById(`user-password`).required=!1,document.getElementById(`user-role`).value=t.role||`operator`,document.getElementById(`modal-title`).textContent=`Editar Usuario`,document.getElementById(`pwd-hint`).textContent=`Deja en blanco para conservar la contraseña actual.`;let n=Array.isArray(t.allowed_sections)?t.allowed_sections:[];document.querySelectorAll(`input[name="user-perm"]`).forEach(e=>{e.checked=n.includes(e.value)});let r=document.getElementById(`user-modal-overlay`);r.classList.remove(`hidden`),r.classList.add(`flex`)},window.saveUserSubmit=async()=>{let e=document.getElementById(`user-id-field`).value,n=document.getElementById(`user-username`).value.trim().toLowerCase(),r=document.getElementById(`user-fullname`).value.trim(),l=document.getElementById(`user-password`).value,u=document.getElementById(`user-role`).value,d=Array.from(document.querySelectorAll(`input[name="user-perm"]:checked`)).map(e=>e.value);if(!n||!r){i(`Campos requeridos`,`Por favor llena el nombre de usuario y el nombre completo.`,`error`);return}if(d.length===0){i(`Permisos requeridos`,`Debes seleccionar al menos una sección permitida para el usuario.`,`error`);return}let f=!!e,p=null;l&&(p=await t(l));let m={username:n,full_name:r,role:u,allowed_sections:d,is_active:!0};p&&(m.password_hash=p);try{if(f){let t=o.find(t=>t.id===e||t.username===e);t&&!p&&(m.password_hash=t.password_hash);let{error:r}=await a.from(`portal_users`).update(m).eq(`username`,n);if(r)throw r}else{if(!p){i(`Contraseña requerida`,`Debes ingresar una contraseña para el nuevo usuario.`,`error`);return}m.password_hash=p;let{error:e}=await a.from(`portal_users`).insert([m]);if(e)throw e}window.closeUserModal(),i(`¡Usuario Guardado!`,`El usuario ${n} se ha ${f?`actualizado`:`creado`} correctamente.`,`success`),await s(),c()}catch(t){if(console.error(`Error saving user to Supabase:`,t),f){let t=o.findIndex(t=>t.id===e||t.username===n);t!==-1&&(o[t]={...o[t],...m})}else o.push({id:`local-${Date.now()}`,...m});localStorage.setItem(`cgc_cached_users`,JSON.stringify(o)),window.closeUserModal(),i(`¡Guardado Local!`,`El usuario ${n} se guardó localmente.`,`success`),c()}},window.deleteUserConfirm=(e,t)=>{if(t===`colimagc`){i(`Acción no permitida`,`No puedes eliminar el usuario administrador principal.`,`error`);return}i(`Eliminar Usuario`,`¿Estás seguro de que deseas eliminar al usuario "${t}"?`,`confirm`,async()=>{try{await a.from(`portal_users`).delete().eq(`username`,t)}catch(e){console.warn(e)}o=o.filter(n=>n.username!==t&&n.id!==e),localStorage.setItem(`cgc_cached_users`,JSON.stringify(o)),c(),i(`Eliminado`,`El usuario ${t} ha sido eliminado.`,`success`)})}},i=async(e,t,n,r)=>{let i=sessionStorage.getItem(`cgc_user_data`);e.innerHTML=`
        <div class="space-y-8 max-w-7xl mx-auto animate-fade-in pb-12">
            
            <!-- Hero Welcome Card -->
            <div class="relative overflow-hidden bg-gradient-to-r from-slate-900 via-slate-900 to-slate-800 border border-slate-800 rounded-3xl p-8 sm:p-10 shadow-2xl">
                <div class="absolute -right-10 -bottom-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
                <div class="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div class="space-y-2">
                        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-black uppercase tracking-widest">
                            <span class="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                            Sistema Operativo 2026
                        </div>
                        <h1 class="text-3xl sm:text-4xl font-black text-white tracking-tight uppercase">
                            ¡Hola, ${((i?JSON.parse(i):{full_name:`Administrador`,role:`admin`}).full_name||`Administrador`).split(` `)[0]}!
                        </h1>
                        <p class="text-slate-400 text-xs sm:text-sm max-w-xl font-medium">
                            Bienvenido al panel central de administración de <span class="text-white font-bold">Club de Golf Colima</span>. Selecciona un módulo o revisa el estado operativo en tiempo real.
                        </p>
                    </div>

                    <div class="flex flex-wrap items-center gap-3 shrink-0">
                        ${r(`tournaments`)?`
                        <button onclick="window.renderTournaments()" class="flex items-center gap-2 px-5 py-3.5 bg-primary text-slate-900 rounded-xl font-black text-xs uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-lg shadow-primary/20 cursor-pointer">
                            <span class="material-icons text-base">emoji_events</span> Ir a Torneos
                        </button>`:``}
                        ${r(`casaclub`)?`
                        <button onclick="window.renderReception()" class="flex items-center gap-2 px-5 py-3.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold text-xs uppercase tracking-widest transition-all border border-slate-700 cursor-pointer">
                            <span class="material-icons text-emerald-400 text-base">point_of_sale</span> Recepción
                        </button>`:``}
                    </div>
                </div>
            </div>

            <!-- KPI Metric Cards -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                
                <!-- Torneos Card -->
                <div onclick="window.renderTournaments && window.renderTournaments()" class="bg-slate-900 border border-slate-800 rounded-3xl p-6 hover:border-primary/40 transition-all cursor-pointer group relative overflow-hidden shadow-xl">
                    <div class="flex items-center justify-between">
                        <div class="w-12 h-12 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                            <span class="material-icons">emoji_events</span>
                        </div>
                        <span class="text-[10px] font-black uppercase tracking-wider text-slate-500 bg-slate-800 px-2.5 py-1 rounded-full">Activos</span>
                    </div>
                    <div class="mt-4">
                        <h3 id="dash-kpi-tournaments" class="text-3xl font-black text-white">...</h3>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Torneos Registrados</p>
                    </div>
                </div>

                <!-- Socios Card -->
                <div onclick="window.renderMembers && window.renderMembers()" class="bg-slate-900 border border-slate-800 rounded-3xl p-6 hover:border-blue-500/40 transition-all cursor-pointer group relative overflow-hidden shadow-xl">
                    <div class="flex items-center justify-between">
                        <div class="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                            <span class="material-icons">groups</span>
                        </div>
                        <span class="text-[10px] font-black uppercase tracking-wider text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full">Padrón</span>
                    </div>
                    <div class="mt-4">
                        <h3 id="dash-kpi-members" class="text-3xl font-black text-white">...</h3>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Socios & Titulares</p>
                    </div>
                </div>

                <!-- Salidas Card -->
                <div onclick="window.renderReception && window.renderReception()" class="bg-slate-900 border border-slate-800 rounded-3xl p-6 hover:border-emerald-500/40 transition-all cursor-pointer group relative overflow-hidden shadow-xl">
                    <div class="flex items-center justify-between">
                        <div class="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                            <span class="material-icons">schedule</span>
                        </div>
                        <span class="text-[10px] font-black uppercase tracking-wider text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full">Hoy</span>
                    </div>
                    <div class="mt-4">
                        <h3 id="dash-kpi-today-teetimes" class="text-3xl font-black text-white">...</h3>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Salidas Casa Club</p>
                    </div>
                </div>

                <!-- Handicaps WHS Card -->
                <div onclick="window.renderHandicapHub && window.renderHandicapHub()" class="bg-slate-900 border border-slate-800 rounded-3xl p-6 hover:border-amber-500/40 transition-all cursor-pointer group relative overflow-hidden shadow-xl">
                    <div class="flex items-center justify-between">
                        <div class="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                            <span class="material-icons">analytics</span>
                        </div>
                        <span class="text-[10px] font-black uppercase tracking-wider text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-full">WHS</span>
                    </div>
                    <div class="mt-4">
                        <h3 id="dash-kpi-avg-hcp" class="text-3xl font-black text-white">...</h3>
                        <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Promedio Handicap</p>
                    </div>
                </div>

            </div>

            <!-- Operational Sections Quick Navigation Grid -->
            <div>
                <div class="flex items-center justify-between mb-5">
                    <div>
                        <h2 class="text-xl font-black text-white uppercase tracking-tight">Módulos del Sistema</h2>
                        <p class="text-slate-500 text-xs font-bold uppercase tracking-wider mt-0.5">Acceso rápido a las operaciones del club</p>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    
                    ${r(`tournaments`)?`
                    <div onclick="window.renderTournaments()" class="bg-slate-900 border border-slate-800 hover:border-primary/40 rounded-3xl p-6 transition-all cursor-pointer group flex flex-col justify-between shadow-xl">
                        <div class="flex items-start justify-between">
                            <div class="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                                <span class="material-icons text-2xl">emoji_events</span>
                            </div>
                            <span class="material-icons text-slate-600 group-hover:text-primary group-hover:translate-x-1 transition-all">arrow_forward</span>
                        </div>
                        <div class="mt-6">
                            <h3 class="text-lg font-black text-white uppercase group-hover:text-primary transition-colors">Gestión de Torneos</h3>
                            <p class="text-xs text-slate-400 mt-1 font-medium">Administración de instancias de torneo, tarjetas O'Yes y leaderboard en vivo.</p>
                        </div>
                    </div>`:``}

                    ${r(`members`)?`
                    <div onclick="window.renderMembers()" class="bg-slate-900 border border-slate-800 hover:border-blue-500/40 rounded-3xl p-6 transition-all cursor-pointer group flex flex-col justify-between shadow-xl">
                        <div class="flex items-start justify-between">
                            <div class="w-14 h-14 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                                <span class="material-icons text-2xl">groups</span>
                            </div>
                            <span class="material-icons text-slate-600 group-hover:text-blue-400 group-hover:translate-x-1 transition-all">arrow_forward</span>
                        </div>
                        <div class="mt-6">
                            <h3 class="text-lg font-black text-white uppercase group-hover:text-blue-400 transition-colors">Socios & Membresías</h3>
                            <p class="text-xs text-slate-400 mt-1 font-medium">Padrón de socios, control de pagos, vigencias de cuotas y expedientes de handicap.</p>
                        </div>
                    </div>`:``}

                    ${r(`casaclub`)?`
                    <div onclick="window.renderReception()" class="bg-slate-900 border border-slate-800 hover:border-emerald-500/40 rounded-3xl p-6 transition-all cursor-pointer group flex flex-col justify-between shadow-xl">
                        <div class="flex items-start justify-between">
                            <div class="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                                <span class="material-icons text-2xl">point_of_sale</span>
                            </div>
                            <span class="material-icons text-slate-600 group-hover:text-emerald-400 group-hover:translate-x-1 transition-all">arrow_forward</span>
                        </div>
                        <div class="mt-6">
                            <h3 class="text-lg font-black text-white uppercase group-hover:text-emerald-400 transition-colors">Recepción & Tee Times</h3>
                            <p class="text-xs text-slate-400 mt-1 font-medium">Control de salidas cada 20 min, cobro de Green Fees, renta de carritos y corte de caja.</p>
                        </div>
                    </div>`:``}

                    ${r(`caddiemaster`)?`
                    <div onclick="window.renderCaddieMaster()" class="bg-slate-900 border border-slate-800 hover:border-teal-500/40 rounded-3xl p-6 transition-all cursor-pointer group flex flex-col justify-between shadow-xl">
                        <div class="flex items-start justify-between">
                            <div class="w-14 h-14 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-teal-400 group-hover:scale-110 transition-transform">
                                <span class="material-icons text-2xl">golf_course</span>
                            </div>
                            <span class="material-icons text-slate-600 group-hover:text-teal-400 group-hover:translate-x-1 transition-all">arrow_forward</span>
                        </div>
                        <div class="mt-6">
                            <h3 class="text-lg font-black text-white uppercase group-hover:text-teal-400 transition-colors">Caddie Master & Hoyo 1</h3>
                            <p class="text-xs text-slate-400 mt-1 font-medium">Verificación express de jugadores en campo, asignación de caddies y bitácora.</p>
                        </div>
                    </div>`:``}

                    ${r(`handicaphub`)?`
                    <div onclick="window.renderHandicapHub()" class="bg-slate-900 border border-slate-800 hover:border-amber-500/40 rounded-3xl p-6 transition-all cursor-pointer group flex flex-col justify-between shadow-xl">
                        <div class="flex items-start justify-between">
                            <div class="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                                <span class="material-icons text-2xl">analytics</span>
                            </div>
                            <span class="material-icons text-slate-600 group-hover:text-amber-400 group-hover:translate-x-1 transition-all">arrow_forward</span>
                        </div>
                        <div class="mt-6">
                            <h3 class="text-lg font-black text-white uppercase group-hover:text-amber-400 transition-colors">Handicaps WHS Oficial</h3>
                            <p class="text-xs text-slate-400 mt-1 font-medium">Tabla general por tee (Azul, Blanco, Dorado, Rojo) y cálculo diferencial WHS.</p>
                        </div>
                    </div>`:``}

                    ${r(`reports`)?`
                    <div onclick="window.renderReports()" class="bg-slate-900 border border-slate-800 hover:border-emerald-500/40 rounded-3xl p-6 transition-all cursor-pointer group flex flex-col justify-between shadow-xl">
                        <div class="flex items-start justify-between">
                            <div class="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                                <span class="material-icons text-2xl">insights</span>
                            </div>
                            <span class="material-icons text-slate-600 group-hover:text-emerald-400 group-hover:translate-x-1 transition-all">arrow_forward</span>
                        </div>
                        <div class="mt-6">
                            <h3 class="text-lg font-black text-white uppercase group-hover:text-emerald-400 transition-colors">Reportes & Analíticas</h3>
                            <p class="text-xs text-slate-400 mt-1 font-medium">Afluencia, renta de carritos, horas pico, ranking de socios y exportación a Excel/PDF.</p>
                        </div>
                    </div>`:``}

                </div>
            </div>

        </div>
    `;try{let{count:e}=await t.from(`tournaments`).select(`*`,{count:`exact`,head:!0}),n=document.getElementById(`dash-kpi-tournaments`);n&&(n.textContent=e||0);let{data:r}=await t.from(`members`).select(`current_handicap, status`);if(r){let e=document.getElementById(`dash-kpi-members`);e&&(e.textContent=r.length);let t=r.map(e=>parseFloat(e.current_handicap)).filter(e=>!isNaN(e)),n=t.length>0?(t.reduce((e,t)=>e+t,0)/t.length).toFixed(1):`15.2`,i=document.getElementById(`dash-kpi-avg-hcp`);i&&(i.textContent=n)}let i=new Date().toISOString().split(`T`)[0],{data:a}=await t.from(`tee_times`).select(`id`).eq(`play_date`,i),o=document.getElementById(`dash-kpi-today-teetimes`);o&&(o.textContent=a?a.length:0)}catch(e){console.warn(`Error loading dashboard metrics:`,e)}},a=`modulepreload`,o=function(e){return`/`+e},s={},c=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),c=i?.nonce||i?.getAttribute(`nonce`);function l(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function u(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=l(t.map(t=>{if(t=o(t,n),t=u(t),t in s)return;s[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:a,r||(i.as=`script`),i.crossOrigin=``,i.href=t,c&&i.setAttribute(`nonce`,c),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})};window.location.pathname===`/oyes`||window.location.pathname===`/oyes/`?window.location.href=`/oyes/index.html`+window.location.search:(window.location.pathname===`/torneo`||window.location.pathname===`/torneo/`)&&(window.location.href=`/torneo/index.html`+window.location.search);var l=e(`https://tztolxgsaktqindoimtu.supabase.co`,`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR6dG9seGdzYWt0cWluZG9pbXR1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYyNzQ4ODAsImV4cCI6MjEwMTg1MDg4MH0.E2GABiOMXYb5hEwE9ErIcJa6_LHkj9lJUglQVoiLl0M`),u=l.schema(`colimaGC`),d=l.schema(`usuarios`),f=()=>{let e=sessionStorage.getItem(`cgc_user_data`);if(e)try{return JSON.parse(e)}catch(e){console.warn(e)}let t=sessionStorage.getItem(`cgc_auth`);return t===`admin`||t===`1`?{username:`colimagc`,full_name:`Administrador`,role:`admin`,allowed_sections:[`dashboard`,`tournaments`,`members`,`casaclub`,`caddiemaster`,`handicaphub`,`reports`,`noticias`,`landing`,`users`]}:t===`caddie`?{username:`caddiemaster`,full_name:`Caddie Master`,role:`caddie`,allowed_sections:[`dashboard`,`casaclub`,`caddiemaster`,`landing`]}:null};f(),window.hasPermission=e=>{let t=f();return t?t.role===`admin`||t.username===`colimagc`||(Array.isArray(t.allowed_sections)?t.allowed_sections:[`tournaments`]).includes(e):!1};var p=document.getElementById(`app`);window.showNotification=(e,t,n=`success`,r=null)=>{let i=document.querySelector(`.notification-overlay`);i&&i.remove();let a=document.createElement(`div`);a.className=`notification-overlay`,a.innerHTML=`
        <div class="notification-modal">
            <div class="notify-icon ${{success:`notify-success`,error:`notify-error`,confirm:`notify-confirm`}[n]||`notify-success`}">
                <span class="material-icons" style="font-size:2.5rem">${{success:`check_circle`,error:`warning`,confirm:`help`}[n]||`check_circle`}</span>
            </div>
            <h2 class="text-2xl font-bold mb-2 text-slate-900 dark:text-white">${e}</h2>
            <p class="text-slate-500 mb-8">${t}</p>
            <div class="flex gap-4">
                ${r?`
                    <button class="notify-btn btn-confirm flex-1 font-bold py-3" id="confirm-yes">Sí, Proceder</button>
                    <button class="notify-btn btn-cancel flex-1 font-bold py-3" id="confirm-no">Cancelar</button>
                `:`
                    <button class="notify-btn btn-ok font-bold py-3" id="notify-close">Entendido</button>
                `}
            </div>
        </div>`,document.body.appendChild(a),r?(document.getElementById(`confirm-yes`).onclick=()=>{r(),a.classList.remove(`show`),setTimeout(()=>a.remove(),400)},document.getElementById(`confirm-no`).onclick=()=>{a.classList.remove(`show`),setTimeout(()=>a.remove(),400)}):document.getElementById(`notify-close`).onclick=()=>{a.classList.remove(`show`),setTimeout(()=>a.remove(),400)},setTimeout(()=>a.classList.add(`show`),10)},window.toggleSidebar=()=>{let e=document.getElementById(`sidebar-menu`),t=document.getElementById(`sidebar-overlay`);e&&t&&(e.classList.contains(`translate-x-0`)?(e.classList.replace(`translate-x-0`,`-translate-x-full`),t.classList.add(`hidden`)):(e.classList.replace(`-translate-x-full`,`translate-x-0`),t.classList.remove(`hidden`)))};var m=(e,t)=>{window.hasPermission(e)?t():h(e)},h=e=>{p.innerHTML=g(`
        <div class="py-24 flex flex-col items-center justify-center text-center max-w-md mx-auto space-y-5 animate-fade-in">
            <div class="w-20 h-20 bg-red-500/10 border border-red-500/20 rounded-3xl flex items-center justify-center text-red-400">
                <span class="material-icons" style="font-size:3rem">lock</span>
            </div>
            <div>
                <h2 class="text-2xl font-black text-white uppercase tracking-tight">Acceso Restringido</h2>
                <p class="text-slate-400 text-xs mt-2 leading-relaxed">
                    No tienes permisos suficientes para acceder a la sección <span class="font-bold text-white uppercase">[${e}]</span>. Contacta al Administrador del portal para solicitar acceso.
                </p>
            </div>
            <button onclick="window.renderDashboard()" class="px-6 py-3.5 bg-primary text-slate-900 font-black rounded-xl text-xs uppercase tracking-widest hover:scale-[1.02] transition-all shadow-lg shadow-primary/20">
                Volver al Panel Principal
            </button>
        </div>
    `,e)},g=(e,t=`dashboard`)=>{let n=f();return`
    <div class="flex h-screen overflow-hidden relative bg-background-dark">
        <!-- Sidebar -->
        <aside id="sidebar-menu" class="fixed inset-y-0 left-0 z-50 w-72 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0 transform -translate-x-full transition-transform duration-300 ease-in-out shadow-2xl">
            <div class="p-6 flex items-center justify-between border-b border-slate-800">
                <div onclick="window.renderDashboard && window.renderDashboard(); window.toggleSidebar();" class="flex items-center gap-3 cursor-pointer hover:scale-105 transition-all" title="Ir al Panel Principal">
                    <div class="flex items-center gap-2.5 p-2 bg-white/5 border border-white/10 rounded-2xl shadow-md backdrop-blur-md">
                        <img src="./golcolima.jpg" alt="Club Colima" class="h-14 w-auto object-contain rounded-xl" onerror="this.style.display='none'">
                        <img src="./logoclub.png" alt="Asociación" class="h-14 w-auto object-contain rounded-xl" onerror="this.style.display='none'">
                    </div>
                    <div>
                        <h1 class="font-black text-white text-base leading-tight uppercase">Colima GC</h1>
                        <p class="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Sistema Club</p>
                    </div>
                </div>
                <button class="p-2 text-slate-400 hover:text-primary transition-colors cursor-pointer" onclick="window.toggleSidebar()">
                    <span class="material-icons">close</span>
                </button>
            </div>
            <nav class="flex-1 mt-4 px-3 space-y-1.5 overflow-y-auto">

                ${window.hasPermission(`dashboard`)?`
                <a onclick="window.renderDashboard(); window.toggleSidebar();"
                    class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer font-bold
                    ${t===`dashboard`?`bg-primary/10 border-l-4 border-primary text-white shadow-md`:`text-slate-400 hover:text-white hover:bg-slate-800/60`}">
                    <span class="material-icons ${t===`dashboard`?`text-primary`:``}">dashboard</span>
                    <span class="text-sm">Panel Principal</span>
                </a>
                `:``}

                ${window.hasPermission(`tournaments`)?`
                <a onclick="window.renderTournaments(); window.toggleSidebar();"
                    class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer font-bold
                    ${t===`tournaments`?`bg-primary/10 border-l-4 border-primary text-white shadow-md`:`text-slate-400 hover:text-white hover:bg-slate-800/60`}">
                    <span class="material-icons ${t===`tournaments`?`text-primary`:``}">emoji_events</span>
                    <span class="text-sm">Torneos</span>
                </a>
                `:``}

                ${window.hasPermission(`members`)?`
                <a onclick="window.renderMembers(); window.toggleSidebar();"
                    class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer font-bold
                    ${t===`members`?`bg-primary/10 border-l-4 border-primary text-white shadow-md`:`text-slate-400 hover:text-white hover:bg-slate-800/60`}">
                    <span class="material-icons ${t===`members`?`text-primary`:``}">groups</span>
                    <span class="text-sm">Socios & Membresías</span>
                </a>
                `:``}

                ${window.hasPermission(`casaclub`)?`
                <a onclick="window.renderReception(); window.toggleSidebar();"
                    class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer font-bold
                    ${t===`casaclub`?`bg-emerald-500/10 border-l-4 border-emerald-400 text-white shadow-md`:`text-slate-400 hover:text-white hover:bg-slate-800/60`}">
                    <span class="material-icons ${t===`casaclub`?`text-emerald-400`:``}">point_of_sale</span>
                    <span class="text-sm">Recepción & Tee Times</span>
                </a>
                `:``}

                ${window.hasPermission(`caddiemaster`)?`
                <a onclick="window.renderCaddieMaster(); window.toggleSidebar();"
                    class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer font-bold
                    ${t===`caddiemaster`?`bg-primary/10 border-l-4 border-primary text-white shadow-md`:`text-slate-400 hover:text-white hover:bg-slate-800/60`}">
                    <span class="material-icons ${t===`caddiemaster`?`text-primary`:``}">golf_course</span>
                    <span class="text-sm">Caddie Master</span>
                </a>
                `:``}

                ${window.hasPermission(`handicaphub`)?`
                <a onclick="window.renderHandicapHub(); window.toggleSidebar();"
                    class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer font-bold
                    ${t===`handicaphub`?`bg-primary/10 border-l-4 border-primary text-white shadow-md`:`text-slate-400 hover:text-white hover:bg-slate-800/60`}">
                    <span class="material-icons ${t===`handicaphub`?`text-amber-400`:``}">analytics</span>
                    <span class="text-sm">Handicaps WHS</span>
                </a>
                `:``}

                ${window.hasPermission(`reports`)?`
                <a onclick="window.renderReports(); window.toggleSidebar();"
                    class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer font-bold
                    ${t===`reports`?`bg-emerald-500/10 border-l-4 border-emerald-400 text-white shadow-md`:`text-slate-400 hover:text-white hover:bg-slate-800/60`}">
                    <span class="material-icons ${t===`reports`?`text-emerald-400`:``}">insights</span>
                    <span class="text-sm">Reportes & Métricas</span>
                </a>
                `:``}

                ${window.hasPermission(`noticias`)?`
                <a onclick="window.renderNoticias(); window.toggleSidebar();"
                    class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer font-bold
                    ${t===`noticias`?`bg-amber-500/10 border-l-4 border-amber-500 text-white shadow-md`:`text-slate-400 hover:text-white hover:bg-slate-800/60`}">
                    <span class="material-icons ${t===`noticias`?`text-amber-400`:``}">feed</span>
                    <span class="text-sm">Noticias & Artículos</span>
                </a>
                `:``}

                ${window.hasPermission(`users`)?`
                <a onclick="window.renderUsers(); window.toggleSidebar();"
                    class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer font-bold
                    ${t===`users`?`bg-purple-500/10 border-l-4 border-purple-500 text-white shadow-md`:`text-slate-400 hover:text-white hover:bg-slate-800/60`}">
                    <span class="material-icons ${t===`users`?`text-purple-400`:``}">manage_accounts</span>
                    <span class="text-sm">Gestión Usuarios</span>
                </a>
                `:``}

                <div class="pt-3 border-t border-slate-800/80">
                    <a onclick="window.renderLandingPage(); window.toggleSidebar();"
                        class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer font-bold
                        ${t===`landing`?`bg-primary/10 border-l-4 border-primary text-white shadow-md`:`text-slate-400 hover:text-white hover:bg-slate-800/60`}">
                        <span class="material-icons ${t===`landing`?`text-emerald-400`:``}">language</span>
                        <span class="text-sm">Sitio Web / Landing</span>
                    </a>
                </div>

            </nav>
            <div class="p-4 border-t border-slate-800 space-y-3">
                <div onclick="logout()" class="flex items-center gap-3 px-3 py-3 bg-slate-800/50 rounded-xl cursor-pointer hover:bg-slate-700 transition-colors">
                    <div class="w-9 h-9 rounded-xl bg-primary/20 border border-primary/30 overflow-hidden flex items-center justify-center font-bold text-xs text-primary">
                        <img src="./golcolima.jpg" alt="Usuario" class="w-full h-full object-cover" onerror="this.style.display='none'">
                    </div>
                    <div class="flex-1 overflow-hidden">
                        <p class="text-xs font-bold text-white truncate">${n?.full_name||`Administrador`}</p>
                        <p class="text-[10px] text-slate-500 uppercase tracking-tighter truncate">${n?.role||`Staff`}</p>
                    </div>
                    <span class="material-icons text-slate-400 text-sm">logout</span>
                </div>

                <!-- GooWeb Sidebar Credit -->
                <a href="https://gooweb.click/" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-slate-950/50 hover:bg-slate-800/80 border border-slate-800/80 hover:border-emerald-500/40 transition-all duration-300 group" title="Desarrollado por GooWeb">
                    <span class="text-[9px] text-slate-500 font-bold uppercase tracking-wider group-hover:text-slate-400">Powered by</span>
                    <img src="./gooweb1.png" alt="GooWeb" class="h-4 w-auto object-contain transition-transform group-hover:scale-110">
                    <span class="text-[10px] font-black text-slate-400 group-hover:text-white uppercase tracking-wide">GooWeb</span>
                    <span class="material-icons text-slate-600 group-hover:text-emerald-400 text-[10px] transition-colors">open_in_new</span>
                </a>
            </div>
        </aside>

        <!-- Sidebar Overlay -->
        <div id="sidebar-overlay" class="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40 hidden" onclick="window.toggleSidebar()"></div>

        <!-- Main -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <header class="h-20 border-b border-slate-800 bg-slate-900 px-4 sm:px-8 flex items-center justify-between shrink-0">
                <div class="flex items-center gap-4">
                    <button class="p-2 bg-slate-800 rounded-xl border border-slate-700 text-slate-400 hover:text-primary transition-all" onclick="window.toggleSidebar()">
                        <span class="material-icons">menu</span>
                    </button>
                    <div class="flex items-center gap-3">
                        <div onclick="window.renderDashboard && window.renderDashboard()" class="flex items-center gap-2.5 p-2 bg-white/5 border border-white/10 rounded-2xl shadow-md backdrop-blur-md cursor-pointer hover:scale-105 transition-all" title="Ir al Panel Principal">
                            <img src="./golcolima.jpg" alt="Club Colima" class="h-14 w-auto object-contain rounded-xl" onerror="this.style.display='none'">
                            <img src="./logoclub.png" alt="Asociación" class="h-14 w-auto object-contain rounded-xl" onerror="this.style.display='none'">
                        </div>
                        <div class="hidden sm:block">
                            <p class="text-base font-black text-white leading-tight uppercase">${{dashboard:`Panel Principal`,tournaments:`Gestión de Torneos`,members:`Gestión de Socios & Membresías`,casaclub:`Recepción & Tee Times (Casa Club)`,caddiemaster:`Caddie Master`,handicaphub:`Handicaps WHS`,reports:`Reportes & Métricas Operativas`,noticias:`Gestión de Noticias & Artículos`,users:`Gestión de Usuarios & Permisos`,landing:`Sitio Web / Landing`}[t]||`Portal Colima GC`}</p>
                            <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Club de Golf Colima</p>
                        </div>
                    </div>
                </div>
                <div class="flex items-center gap-3">
                    <button onclick="window.renderDashboard()" class="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center justify-center text-slate-300 hover:text-white transition-all shadow-md" title="Ir al Panel Principal">
                        <span class="material-icons text-lg">dashboard</span>
                    </button>
                    <div onclick="window.renderDashboard()" class="w-11 h-11 rounded-2xl bg-primary/20 border border-primary/30 flex items-center justify-center overflow-hidden cursor-pointer hover:scale-105 transition-all shadow-md" title="Panel Principal">
                        <img src="./golcolima.jpg" alt="Colima Golf" class="w-full h-full object-cover rounded-2xl">
                    </div>
                </div>
            </header>
            <div class="flex-1 overflow-y-auto p-6 sm:p-8 view-container bg-background-dark">
                ${e}
            </div>
        </main>
    </div>`},_=()=>{p.innerHTML=`
    <div class="relative min-h-screen flex items-center justify-center bg-golf-hero px-4 py-12">
        <div class="w-full max-w-md animate-fade-in relative z-10">
            <div class="flex flex-col items-center mb-8">
                <div class="p-3 bg-white/5 border border-white/10 rounded-3xl shadow-2xl backdrop-blur-md mb-3">
                    <img src="./golcolima.jpg" alt="Club Colima" class="h-20 w-auto object-contain rounded-2xl" onerror="this.style.display='none'">
                </div>
                <h1 class="text-2xl font-black text-white tracking-tight text-center uppercase">Club de Golf Colima</h1>
                <p class="text-primary font-bold text-[10px] uppercase tracking-[0.4em] mt-1">Sistema de Torneos & Club</p>
            </div>

            <div class="bg-slate-900/95 backdrop-blur-md rounded-[2.5rem] shadow-2xl overflow-hidden border border-slate-700/50">
                <div class="p-10">
                    <div class="mb-8 text-center">
                        <h2 class="text-xl font-black text-white">Portal Administrativo</h2>
                        <p class="text-slate-400 text-[10px] mt-1 font-bold uppercase tracking-wider">Ingresa con tus credenciales asignadas</p>
                    </div>
                    <form id="login-form" class="space-y-5">
                        <div class="space-y-2">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Usuario</label>
                            <div class="relative group">
                                <span class="material-icons absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors text-xl">person</span>
                                <input id="username" class="block w-full pl-12 pr-4 py-4 border-2 border-slate-800 rounded-2xl bg-slate-800/50 text-white placeholder:text-slate-600 focus:outline-none focus:border-primary transition-all text-sm font-bold" placeholder="colimagc" required type="text">
                            </div>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Contraseña</label>
                            <div class="relative group">
                                <span class="material-icons absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors text-xl">lock</span>
                                <input id="password" class="block w-full pl-12 pr-4 py-4 border-2 border-slate-800 rounded-2xl bg-slate-800/50 text-white placeholder:text-slate-600 focus:outline-none focus:border-primary transition-all text-sm font-bold" placeholder="••••••••" required type="password">
                            </div>
                        </div>
                        <div id="login-error" class="hidden text-red-400 text-xs font-bold text-center pt-1">Usuario o contraseña incorrectos.</div>
                        <div class="pt-2">
                            <button type="submit" id="login-submit-btn" class="w-full h-14 bg-primary hover:bg-primary/90 text-slate-900 font-black rounded-2xl shadow-lg shadow-primary/20 transition-all uppercase tracking-widest text-xs flex items-center justify-center gap-3">
                                <span class="material-icons text-sm">login</span> Ingresar al Sistema
                            </button>
                        </div>
                    </form>

                    <!-- LOGO ASOCIACION ABAJO DEL BOTON -->
                    <div class="mt-6 pt-4 border-t border-slate-800/80 flex flex-col items-center justify-center gap-1.5">
                        <div class="p-2 bg-white/5 border border-white/10 rounded-2xl shadow-lg backdrop-blur-md">
                            <img src="./logoclub.png" alt="Asociación" class="h-14 w-auto object-contain rounded-xl" onerror="this.style.display='none'">
                        </div>
                    </div>
                </div>
                <div class="px-10 py-5 bg-slate-800/40 border-t border-slate-700 flex flex-col items-center justify-center gap-2">
                    <div class="flex items-center gap-2">
                        <span class="material-icons text-xs text-primary">verified_user</span>
                        <p class="text-[9px] text-slate-500 font-black uppercase tracking-widest">Conexión Segura · Colima GC · 2026</p>
                    </div>
                    <a href="https://gooweb.click/" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1.5 text-[10px] font-bold text-slate-500 hover:text-emerald-400 transition-colors group">
                        <span>Sistema desarrollado por</span>
                        <img src="./gooweb1.png" alt="GooWeb" class="h-3.5 w-auto object-contain opacity-80 group-hover:opacity-100 transition-opacity">
                        <span class="font-black text-slate-400 group-hover:text-white uppercase">GooWeb</span>
                    </a>
                </div>
            </div>
        </div>
    </div>`,document.getElementById(`login-form`).addEventListener(`submit`,async e=>{e.preventDefault();let n=document.getElementById(`username`).value.trim().toLowerCase(),r=document.getElementById(`password`).value,i=document.getElementById(`login-error`);i.classList.add(`hidden`);let a=document.getElementById(`login-submit-btn`);a.disabled=!0,a.innerHTML=`<span class="w-5 h-5 border-2 border-slate-900 border-t-transparent rounded-full animate-spin"></span> Verificando...`;try{let e=await t(r),o=null;try{let{data:t,error:i}=await d.from(`portal_users`).select(`*`).eq(`username`,n).eq(`is_active`,!0).single();!i&&t&&(t.password_hash===e||t.password_hash===r)&&(o=t)}catch(e){console.warn(`DB auth check failed:`,e)}if(!o){let t=localStorage.getItem(`cgc_cached_users`);if(t){let i=JSON.parse(t).find(e=>e.username.toLowerCase()===n&&e.is_active!==!1);i&&(i.password_hash===e||i.password_hash===r)&&(o=i)}}o||(n===`colimagc`&&(r===`colimagc2026`||e===`8c49f828dbbc919041b9ef2b0eb58afac2f53c5699d60e9ef544f9a4eb501603`)?o={username:`colimagc`,full_name:`Administrador`,role:`admin`,allowed_sections:[`dashboard`,`tournaments`,`members`,`caddiemaster`,`handicaphub`,`noticias`,`landing`,`users`]}:n===`caddiemaster`&&r===`caddiemaster2026`&&(o={username:`caddiemaster`,full_name:`Caddie Master`,role:`caddie`,allowed_sections:[`dashboard`,`caddiemaster`,`landing`]})),o?(sessionStorage.setItem(`cgc_user_data`,JSON.stringify(o)),sessionStorage.setItem(`cgc_auth`,o.role),b()):(i.classList.remove(`hidden`),a.disabled=!1,a.innerHTML=`<span class="material-icons text-sm">login</span> Ingresar al Sistema`)}catch(e){console.error(`Login error:`,e),i.classList.remove(`hidden`),a.disabled=!1,a.innerHTML=`<span class="material-icons text-sm">login</span> Ingresar al Sistema`}})};window.logout=()=>{sessionStorage.removeItem(`cgc_auth`),sessionStorage.removeItem(`cgc_user_data`),_()},window.renderDashboard=async()=>{m(`dashboard`,async()=>{p.innerHTML=g(`<div id="dashboard-app-root"></div>`,`dashboard`);let e=document.getElementById(`dashboard-app-root`);e&&i(e,u,l,window.hasPermission)})};var v=async()=>{m(`tournaments`,async()=>{p.innerHTML=g(`
            <div class="animate-fade-in space-y-6">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h2 class="text-3xl font-black tracking-tight text-white">Gestión de Torneos</h2>
                        <p class="text-slate-500 mt-1">Administración de instancias de Golf Target.</p>
                    </div>
                    <button onclick="renderNewTournament()" class="flex items-center gap-2 px-6 py-3 bg-primary text-slate-900 rounded-xl text-[10px] font-black uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-lg shadow-primary/20">
                        <span class="material-icons text-lg">add</span> Nuevo Proyecto
                    </button>
                </div>
                <div id="tournaments-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                    <div class="col-span-full flex items-center justify-center py-16">
                        <div class="w-10 h-10 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
                    </div>
                </div>
            </div>`,`tournaments`);let{data:e,error:t}=await u.from(`tournaments`).select(`*`),n=document.getElementById(`tournaments-grid`);if(!n)return;if(t||!e||e.length===0){n.innerHTML=`
                <div class="col-span-full py-24 flex flex-col items-center justify-center gap-4 text-center">
                    <div class="w-16 h-16 bg-slate-800 rounded-2xl flex items-center justify-center">
                        <span class="material-icons text-slate-600" style="font-size:2rem">emoji_events</span>
                    </div>
                    <p class="text-slate-500 font-bold uppercase tracking-widest text-xs">No hay torneos aún.</p>
                    <button onclick="renderNewTournament()" class="mt-2 px-5 py-2.5 bg-primary text-slate-900 rounded-xl text-[10px] font-black uppercase tracking-widest">
                        Crear el primer torneo
                    </button>
                </div>`;return}function r(e){if(e.date)return new Date(e.date);if(e.config?.date)return new Date(e.config.date);let t=e.name||``,n={ene:0,enero:0,feb:1,febrero:1,mar:2,marzo:2,abr:3,abril:3,may:4,mayo:4,jun:5,junio:5,jul:6,julio:6,ago:7,agosto:7,sep:8,sept:8,septiembre:8,oct:9,octubre:9,nov:10,noviembre:10,dic:11,diciembre:11},r=t.match(/(\d{1,2})\s*[\/\-]?\s*(ene|enero|feb|febrero|mar|marzo|abr|abril|may|mayo|jun|junio|jul|julio|ago|agosto|sep|sept|septiembre|oct|octubre|nov|noviembre|dic|diciembre)/i);if(r){let e=parseInt(r[1]),i=r[2].toLowerCase(),a=n[i]===void 0?0:n[i],o=t.match(/(?:20)?(2[5-9])/),s=o?2e3+parseInt(o[1]):2026;return new Date(s,a,e)}return new Date(e.created_at||Date.now())}let i=new Date;i.setHours(0,0,0,0),n.innerHTML=[...e].sort((e,t)=>r(e)-r(t)).map(e=>{let t=e.courses||`—`,n=r(e),a=n<i,o=n.toLocaleDateString(`es-MX`,{day:`2-digit`,month:`short`,year:`numeric`}),s=`${window.location.origin}/torneo/?id=${e.id}`;return`
                <div class="group bg-slate-900 border ${a?`border-slate-800 hover:border-amber-500/40`:`border-emerald-500/30 hover:border-emerald-400 shadow-lg shadow-emerald-500/5`} rounded-2xl p-6 transition-all cursor-pointer flex flex-col gap-5" onclick="renderTournamentDetail('${e.id}')">
                    <div class="flex items-start justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-12 h-12 ${a?`bg-amber-500/10 border border-amber-500/20 text-amber-400`:`bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 shadow-md shadow-emerald-500/20`} rounded-2xl flex items-center justify-center">
                                <span class="material-icons">${a?`history`:`emoji_events`}</span>
                            </div>
                            <span class="px-2.5 py-0.5 rounded-full ${a?`bg-amber-500/15 border border-amber-500/30 text-amber-300`:`bg-emerald-500/20 border border-emerald-500/40 text-emerald-300`} text-[9px] font-black uppercase tracking-wider flex items-center gap-1.5">
                                <span class="w-1.5 h-1.5 rounded-full ${a?`bg-amber-400`:`bg-emerald-400 animate-pulse`}"></span>
                                ${a?`Finalizado`:`Próximo Torneo`}
                            </span>
                        </div>
                        <div class="flex gap-1.5 shrink-0">
                            <button onclick="event.stopPropagation(); renderEditTournament('${e.id}')" class="w-8 h-8 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors text-slate-400 hover:text-white cursor-pointer" title="Editar">
                                <span class="material-icons" style="font-size:16px">edit</span>
                            </button>
                            <button onclick="event.stopPropagation(); deleteTournament('${e.id}', '${e.name}')" class="w-8 h-8 bg-slate-800 hover:bg-red-900/40 rounded-lg flex items-center justify-center transition-colors text-slate-400 hover:text-red-400 cursor-pointer" title="Eliminar">
                                <span class="material-icons" style="font-size:16px">delete</span>
                            </button>
                        </div>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-lg font-black uppercase tracking-tight text-white leading-tight">${e.name}</h3>
                        <p class="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1 mt-1">
                            <span class="material-icons" style="font-size:12px">location_on</span> ${t}
                        </p>
                        <p class="text-[11px] font-bold ${a?`text-amber-400/90`:`text-emerald-400`} mt-2 flex items-center gap-1.5">
                            <span class="material-icons" style="font-size:14px">${a?`event_available`:`event`}</span>
                            <span>Fecha: ${o}</span>
                        </p>
                    </div>
                    <div class="border-t border-slate-800 pt-4 flex items-center justify-between">
                        <span class="text-[10px] font-black uppercase tracking-widest ${a?`text-amber-400 hover:text-amber-300`:`text-emerald-400 hover:text-emerald-300`} flex items-center gap-1 cursor-pointer hover:underline" onclick="event.stopPropagation(); renderTournamentDetail('${e.id}')">
                            Master Console <span class="material-icons" style="font-size:14px">arrow_forward</span>
                        </span>
                        <a href="${s}" target="_blank" onclick="event.stopPropagation()" class="text-[10px] font-black uppercase tracking-widest text-slate-500 hover:text-white flex items-center gap-1 transition-colors">
                            <span class="material-icons" style="font-size:14px">open_in_new</span> Visor
                        </a>
                    </div>
                </div>`}).join(``)})},y=async(e=null)=>{let t=!!e,n=e||{name:``,courses:``};window._editConfig=t&&n.config?n.config:null,window._editId=n.id||``,p.innerHTML=g(`
        <div class="animate-fade-in max-w-xl mx-auto space-y-6">
            <div class="flex items-center gap-4">
                <button onclick="renderTournaments()" class="w-10 h-10 bg-slate-800 hover:bg-slate-700 rounded-xl flex items-center justify-center transition-colors">
                    <span class="material-icons text-slate-400">arrow_back</span>
                </button>
                <div>
                    <h2 class="text-2xl font-black text-white">${t?`Editar Torneo`:`Nuevo Torneo`}</h2>
                    <p class="text-slate-500 text-sm">${t?`Modifica los datos del torneo.`:`Crea una nueva instancia de torneo.`}</p>
                </div>
            </div>

            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-8 space-y-6">
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Nombre del Torneo *</label>
                    <input id="t-name" value="${n.name||``}" class="w-full px-4 py-3 bg-slate-800 border-2 border-slate-700 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:border-primary transition-all font-bold text-lg" placeholder="Ej. Torneo Día del Padre 2026" type="text">
                </div>
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Campo(s) / Sede</label>
                    <input id="t-courses" value="${n.courses||``}" class="w-full px-4 py-3 bg-slate-800 border-2 border-slate-700 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:border-primary transition-all font-bold" placeholder="Ej. Club de Golf Colima, Altozano Colima" type="text">
                    <p class="text-[10px] text-slate-600">Separa múltiples campos con coma.</p>
                </div>
            </div>

            <div class="flex gap-4">
                <button onclick="renderTournaments()" class="flex-1 py-4 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-black uppercase tracking-widest text-xs transition-all">
                    Cancelar
                </button>
                <button onclick="saveTournament()"
                    class="flex-1 py-4 bg-primary text-slate-900 rounded-xl font-black uppercase tracking-widest text-xs hover:scale-[1.02] active:scale-95 transition-all shadow-lg shadow-primary/20">
                    ${t?`Guardar Cambios`:`Crear Torneo`}
                </button>
            </div>
        </div>`,`tournaments`)};window.renderNewTournament=()=>y(null),window.renderEditTournament=async e=>{let{data:t}=await u.from(`tournaments`).select(`*`).eq(`id`,e).single();t&&y(t)},window.saveTournament=async()=>{let e=document.getElementById(`t-name`)?.value.trim(),t=document.getElementById(`t-courses`)?.value.trim(),n=window._editId||``;if(!e){window.showNotification(`Campo requerido`,`Por favor ingresa el nombre del torneo.`,`error`);return}let r={name:e.toUpperCase(),courses:t||``,config:n&&window._editConfig?window._editConfig:{teamSize:1,categories:[],modalidad:`A GO GO`}},i;n?{error:i}=await u.from(`tournaments`).update(r).eq(`id`,n):{error:i}=await u.from(`tournaments`).insert([r]),i?(console.error(i),window.showNotification(`Error`,i.message,`error`)):(window.showNotification(`¡Listo!`,n?`Torneo actualizado.`:`Torneo creado exitosamente.`,`success`),window._editConfig=null,window._editId=``,setTimeout(()=>v(),1200))},window.deleteTournament=(e,t)=>{window.showNotification(`Eliminar Torneo`,`¿Estás seguro de que quieres eliminar "${t}"? Esta acción no se puede deshacer.`,`confirm`,async()=>{await u.from(`tournaments`).delete().eq(`id`,e),v()})},window.renderTournamentDetail=async e=>{let{renderTournamentSection:t}=await c(async()=>{let{renderTournamentSection:e}=await import(`./tournaments_detail-Ct_Wjtz7.js`);return{renderTournamentSection:e}},__vite__mapDeps([0,1]));t(e,p,g,u,l,window.showNotification)},window.renderMembers=async()=>{m(`members`,async()=>{p.innerHTML=g(`<div id="members-app-root"></div>`,`members`);let e=document.getElementById(`members-app-root`);if(e){let{renderMembersModule:t}=await c(async()=>{let{renderMembersModule:e}=await import(`./members-Ca0vDt4M.js`);return{renderMembersModule:e}},__vite__mapDeps([2,1]));t(e)}})},window.renderReception=async()=>{m(`casaclub`,async()=>{p.innerHTML=g(`<div id="reception-app-root"></div>`,`casaclub`);let e=document.getElementById(`reception-app-root`);if(e){let{renderReceptionModule:t}=await c(async()=>{let{renderReceptionModule:e}=await import(`./reception-39jnCKvT.js`);return{renderReceptionModule:e}},__vite__mapDeps([3,1]));t(e)}})},window.renderCaddieMaster=async()=>{m(`caddiemaster`,async()=>{p.innerHTML=g(`<div id="caddie-app-root"></div>`,`caddiemaster`);let e=document.getElementById(`caddie-app-root`);if(e){let{renderCaddieMasterModule:t}=await c(async()=>{let{renderCaddieMasterModule:e}=await import(`./caddiemaster-DtO27y1w.js`);return{renderCaddieMasterModule:e}},__vite__mapDeps([4,1]));t(e)}})},window.renderHandicapHub=async()=>{m(`handicaphub`,async()=>{p.innerHTML=g(`<div id="handicap-app-root"></div>`,`handicaphub`);let e=document.getElementById(`handicap-app-root`);if(e){let{renderHandicapHubModule:t}=await c(async()=>{let{renderHandicapHubModule:e}=await import(`./handicap_hub-CFAUupxZ.js`);return{renderHandicapHubModule:e}},__vite__mapDeps([5,1]));t(e)}})},window.renderReports=async()=>{m(`reports`,async()=>{p.innerHTML=g(`<div id="reports-app-root"></div>`,`reports`);let e=document.getElementById(`reports-app-root`);if(e){let{renderReportsModule:t}=await c(async()=>{let{renderReportsModule:e}=await import(`./reports-Bj9vO51Y.js`);return{renderReportsModule:e}},__vite__mapDeps([6,1]));t(e)}})},window.renderNoticias=async()=>{m(`noticias`,async()=>{p.innerHTML=g(`<div id="noticias-app-root"></div>`,`noticias`);let e=document.getElementById(`noticias-app-root`);if(e){let{renderNoticiasModule:t}=await c(async()=>{let{renderNoticiasModule:e}=await import(`./noticias-BFG1D3Jp.js`);return{renderNoticiasModule:e}},[]);t(e,u,l,window.showNotification)}})},window.renderUsers=async()=>{m(`users`,async()=>{p.innerHTML=g(`<div id="users-app-root"></div>`,`users`);let e=document.getElementById(`users-app-root`);e&&r(e,l,window.showNotification)})},window.renderLandingPage=async()=>{p.innerHTML=`<div id="landing-app-root"></div>`;let e=document.getElementById(`landing-app-root`);if(e){let{renderLandingPageModule:t}=await c(async()=>{let{renderLandingPageModule:e}=await import(`./landing_page-BO_c4zTM.js`);return{renderLandingPageModule:e}},__vite__mapDeps([7,1]));t(e)}},window.renderLogin=_;var b=()=>{window.hasPermission(`dashboard`)?window.renderDashboard():window.hasPermission(`casaclub`)?window.renderReception():window.hasPermission(`caddiemaster`)?window.renderCaddieMaster():window.hasPermission(`reports`)?window.renderReports():window.hasPermission(`noticias`)?window.renderNoticias():window.hasPermission(`tournaments`)?window.renderTournaments():window.hasPermission(`members`)?window.renderMembers():window.hasPermission(`handicaphub`)?window.renderHandicapHub():window.hasPermission(`users`)?window.renderUsers():window.renderDashboard()};f()?b():window.location.hash===`#admin`||window.location.hash===`#login`?_():window.renderLandingPage(),window.renderTournaments=v,window.renderNewTournament=()=>y(null),window.renderReception=window.renderReception,window.renderReports=window.renderReports;