import{t as e}from"./dist-BN2bhVnw.js";var t=null,n=null,r=`TODAS`,i=``;function a(e,n){t=n,typeof window<`u`&&(window.openRankingAcumuladoModal=d,window.closeRankingAcumuladoModal=p,window.setRankingCategoryFilter=h,window.filterRankingBySearch=g,window.printRankingAcumulado=v,window.refreshRankingAcumuladoData=m)}function o(e){return e?e.trim().toUpperCase().normalize(`NFD`).replace(/[\u0300-\u036f]/g,``).replace(/\s+/g,` `):``}function s(e){return e.toUpperCase().normalize(`NFD`).replace(/[\u0300-\u036f]/g,``).replace(/[^A-Z0-9\s]/g,` `).split(/\s+/).filter(e=>e.length>2&&![`DEL`,`LOS`,`LAS`,`SAN`,`JOSE`,`LUIS`,`FRANCISCO`,`JESUS`,`MARIA`].includes(e))}function c(e){if(!e)return`CATEGORIA B`;let t=e.replace(/\s+/g,` `).trim().toUpperCase();return t.endsWith(` A`)||t===`A`||t===`CATEGORIA A`||t.includes(`CAT A`)||t.includes(`CATEGORIA A`)?`CATEGORIA A`:t.endsWith(` B`)||t===`B`||t===`CATEGORIA B`||t.includes(`CAT B`)||t.includes(`CATEGORIA B`)?`CATEGORIA B`:t.endsWith(` C`)||t===`C`||t===`CATEGORIA C`||t.includes(`CAT C`)||t.includes(`CATEGORIA C`)?`CATEGORIA C`:`CATEGORIA B`}function l(e){if(!e||!e.name)return!1;if([`b73a7380-589d-4986-84c4-7618d805fced`,`291bcd9c-674b-431e-9fd4-5690ce2b7b94`,`69452b77-44c7-400a-bb88-a763da03196b`,`dfecb440-d4ee-485f-b6d1-ad27f5032fc7`].includes(e.id))return!0;let t=e.name.toLowerCase();return t.includes(`nov`)||t.includes(`pavo`)||t.includes(`ramos`)||t.includes(`mecate`)?!1:(t.includes(`agosto`)||t.includes(`sept`)||t.includes(`ranking`))&&(t.includes(`8`)||t.includes(`22`)||t.includes(`5`)||t.includes(`26`))}async function u(e=!1){if(n&&!e)return n;try{let{data:e,error:r}=await t.from(`tournaments`).select(`id, name, created_at`).order(`created_at`,{ascending:!0});if(r||!e)return console.error(`Error fetching tournaments for ranking:`,r),null;let i=e.filter(l),a=i.length>0?i:e.slice(-4),u=[];a.forEach(e=>{let t=e.name.toLowerCase(),n=e.name,r=``,i=99;e.id===`b73a7380-589d-4986-84c4-7618d805fced`||(t.includes(`8`)||t.includes(`1ª`)||t.includes(`1a`))&&t.includes(`ago`)&&!t.includes(`nov`)?(n=`1ª Fecha (8 Ago)`,r=`8 AGO`,i=1):e.id===`291bcd9c-674b-431e-9fd4-5690ce2b7b94`||t.includes(`22`)&&t.includes(`ago`)?(n=`2ª Fecha (22 Ago)`,r=`22 AGO`,i=2):e.id===`69452b77-44c7-400a-bb88-a763da03196b`||(t.includes(`5`)||t.includes(`3ª`)||t.includes(`3a`))&&(t.includes(`sep`)||t.includes(`sept`))&&!t.includes(`nov`)?(n=`3ª Fecha (5 Sept)`,r=`5 SEPT`,i=3):e.id===`dfecb440-d4ee-485f-b6d1-ad27f5032fc7`||(t.includes(`26`)||t.includes(`4ª`)||t.includes(`4a`))&&(t.includes(`sep`)||t.includes(`sept`))&&!t.includes(`nov`)?(n=`4ª Fecha · Final (26 Sept)`,r=`26 SEPT`,i=4):(i=u.length+1,r=e.name.slice(0,10)),u.push({id:e.id,name:e.name,label:n,shortDate:r,order:i,created_at:e.created_at})}),u.sort((e,t)=>e.order-t.order||new Date(e.created_at)-new Date(t.created_at)),!u.some(e=>e.order===4||e.shortDate.includes(`26`)||e.name.toLowerCase().includes(`26`))&&u.length<=3&&u.push({id:`tourney-4-placeholder`,name:`4ª FECHA (26 SEPT)`,label:`4ª Fecha · Gran Final (26 Sept)`,shortDate:`26 SEPT`,order:4,isPending:!0});let d=u.filter(e=>!e.isPending).map(e=>e.id),[f,p]=await Promise.all([t.from(`teams`).select(`*`).in(`eventid`,d),t.from(`scores`).select(`*`).in(`eventid`,d)]),m=f.data||[],h=p.data||[],g=[];m.forEach(e=>{let t=(e.teamname||``).trim();if(!t)return;let n=c(e.category),r=s(t),i=g.find(e=>{if(e.category!==n)return!1;let t=s(e.name);if(r.filter(e=>t.includes(e)).length>=2)return!0;let i=r.filter(e=>e.length>=4),a=t.filter(e=>e.length>=4);return!!i.filter(e=>a.includes(e)).some(e=>[`INDALECIO`,`CUAUHTEMOC`,`CUAHUTEMOC`,`SHIAN`,`AYEN`,`LUPITA`,`CAIN`,`HOFFMAN`].includes(e))});i?t.split(` `).length<i.name.split(` `).length&&t.split(` `).length>=2&&(i.name=t):(i={key:o(t),name:t,category:n,scoresByFecha:{}},g.push(i));let a=h.filter(t=>String(t.teamid)===String(e.id));if(a.length>0){let t=a.reduce((e,t)=>e+(t.total||0),0),n=e.ventaja||0,r=t-n*a.length,o=a[0];i.scoresByFecha[e.eventid]={gross:t,neto:r,ventaja:n,rounds:a.length,in_score:o.in_score||0,out_score:o.out_score||0}}});let _=g.map(e=>{let t=[];u.forEach(n=>{!n.isPending&&e.scoresByFecha[n.id]&&t.push({fechaId:n.id,fechaOrder:n.order,fechaLabel:n.shortDate,...e.scoresByFecha[n.id]})}),t.sort((e,t)=>e.neto-t.neto);let n=t.length,r=n>=2,i=[],a=[],o=0;n>=2?(i=t.slice(0,2),a=t.slice(2),o=i.reduce((e,t)=>e+t.neto,0)):n===1&&(i=[t[0]],o=t[0].neto);let s=new Set(i.map(e=>e.fechaId)),c=new Set(a.map(e=>e.fechaId)),l=i.length>0?i[0].neto:999,d=i.length>0?Math.min(...i.map(e=>e.out_score||999)):999,f=i.length>0?Math.min(...i.map(e=>e.in_score||999)):999;return{...e,roundsPlayed:n,isQualified:r,bestTwo:i,discarded:a,bestTwoFechaIds:s,discardedFechaIds:c,accumulatedNeto:o,bestSingleNeto:l,bestOut:d,bestIn:f}}),v={"CATEGORIA A":[],"CATEGORIA B":[],"CATEGORIA C":[]};return _.forEach(e=>{let t=e.category;v[t]||(t=t.includes(`A`)?`CATEGORIA A`:t.includes(`B`)?`CATEGORIA B`:t.includes(`C`)?`CATEGORIA C`:`CATEGORIA B`),v[t].push(e)}),Object.keys(v).forEach(e=>{v[e].sort((e,t)=>e.isQualified&&!t.isQualified?-1:!e.isQualified&&t.isQualified?1:e.isQualified&&t.isQualified&&e.accumulatedNeto===t.accumulatedNeto?e.bestSingleNeto===t.bestSingleNeto?e.bestOut===t.bestOut?e.bestIn-t.bestIn:e.bestOut-t.bestOut:e.bestSingleNeto-t.bestSingleNeto:e.accumulatedNeto-t.accumulatedNeto)}),n={tourFechas:u,categories:v,allPlayers:_,totalPlayers:_.length,totalQualified:_.filter(e=>e.isQualified).length,lastUpdated:new Date},n}catch(e){return console.error(`Error calculating ranking acumulado:`,e),null}}async function d(e=`TODAS`){r=e,i=``;let t=document.getElementById(`ranking-acumulado-modal`);t||(t=document.createElement(`div`),t.id=`ranking-acumulado-modal`,t.className=`fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-4 md:p-6 bg-slate-950/95 backdrop-blur-2xl transition-all duration-300 opacity-0`,document.body.appendChild(t)),document.body.style.overflow=`hidden`,t.innerHTML=`
        <div class="relative w-full max-w-6xl h-[95vh] max-h-[96vh] bg-slate-950/95 border-2 border-amber-500/40 rounded-[2rem] sm:rounded-[2.5rem] shadow-2xl shadow-amber-500/10 overflow-hidden flex flex-col transform scale-95 transition-all duration-300" id="ranking-modal-content">
            
            <!-- Glow background accents -->
            <div class="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] bg-amber-500/15 blur-[120px] rounded-full pointer-events-none"></div>
            <div class="absolute -bottom-[20%] -right-[10%] w-[50%] h-[50%] bg-emerald-500/15 blur-[120px] rounded-full pointer-events-none"></div>

            <!-- 1. MODAL HEADER -->
            <div class="relative z-10 px-4 sm:px-8 py-4 sm:py-5 border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-xl flex flex-col gap-3">
                <div class="flex items-center justify-between gap-3">
                    <!-- Left: Logos & Title -->
                    <div class="flex items-center gap-3 min-w-0">
                        <div class="flex items-center gap-2 p-1.5 bg-white/5 border border-white/10 rounded-2xl shadow-md shrink-0">
                            <img src="./golcolima.jpg" alt="Club Colima" class="h-9 sm:h-12 w-auto object-contain rounded-xl" onerror="this.style.display='none'">
                            <img src="./logoclub.png" alt="Asociación" class="h-9 sm:h-12 w-auto object-contain rounded-xl" onerror="this.style.display='none'">
                        </div>
                        <div class="min-w-0">
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="px-3 py-0.5 rounded-full bg-gradient-to-r from-amber-500/20 to-emerald-500/20 border border-amber-500/40 text-amber-300 text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5">
                                    <span class="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                                    TEMPORADA OFICIAL 2026
                                </span>
                                <span class="text-[9px] font-bold text-slate-400 uppercase tracking-wider hidden sm:inline">
                                    4 Fechas · 2 Tarjetas · 1 Campeón
                                </span>
                            </div>
                            <h2 class="text-base sm:text-2xl font-black uppercase tracking-tight text-white truncate leading-tight mt-0.5">
                                I RANKING STROKE PLAY INTERCLUBES
                            </h2>
                            <p class="text-[9.5px] sm:text-[10.5px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5 truncate">
                                <span class="material-icons text-xs">emoji_events</span>
                                <span>TABLA GENERAL ACUMULADA · RUMBO A LA GRAN FINAL</span>
                            </p>
                        </div>
                    </div>

                    <!-- Right: Quick Actions + Close -->
                    <div class="flex items-center gap-2 shrink-0">
                        <button onclick="refreshRankingAcumuladoData()" title="Actualizar datos" class="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white transition-all cursor-pointer">
                            <span class="material-icons text-sm sm:text-base">refresh</span>
                        </button>
                        <button onclick="printRankingAcumulado()" title="Imprimir / Exportar PDF" class="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white transition-all cursor-pointer">
                            <span class="material-icons text-sm sm:text-base">print</span>
                        </button>
                        <button onclick="closeRankingAcumuladoModal()" title="Cerrar (Esc)" class="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-amber-500/15 hover:bg-red-500/20 border border-amber-500/30 hover:border-red-500/40 flex items-center justify-center text-amber-400 hover:text-red-400 transition-all cursor-pointer">
                            <span class="material-icons text-base sm:text-lg">close</span>
                        </button>
                    </div>
                </div>

                <!-- 2. CATEGORY SELECTOR + SEARCH BAR -->
                <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-1">
                    <!-- Category Tabs -->
                    <div class="flex items-center gap-1.5 overflow-x-auto pb-1 custom-scrollbar shrink-0">
                        <button onclick="setRankingCategoryFilter('TODAS')" id="ranking-tab-TODAS"
                            class="px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${r===`TODAS`?`bg-amber-400 text-slate-950 font-black shadow-lg shadow-amber-400/20`:`bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700`}">
                            🏆 Todas
                        </button>
                        <button onclick="setRankingCategoryFilter('CATEGORIA A')" id="ranking-tab-CATEGORIA A"
                            class="px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${r===`CATEGORIA A`?`bg-amber-400 text-slate-950 font-black shadow-lg shadow-amber-400/20`:`bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700`}">
                            Cat A (0-10)
                        </button>
                        <button onclick="setRankingCategoryFilter('CATEGORIA B')" id="ranking-tab-CATEGORIA B"
                            class="px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${r===`CATEGORIA B`?`bg-amber-400 text-slate-950 font-black shadow-lg shadow-amber-400/20`:`bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700`}">
                            Cat B (11-20)
                        </button>
                        <button onclick="setRankingCategoryFilter('CATEGORIA C')" id="ranking-tab-CATEGORIA C"
                            class="px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${r===`CATEGORIA C`?`bg-amber-400 text-slate-950 font-black shadow-lg shadow-amber-400/20`:`bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700`}">
                            Cat C (21-36)
                        </button>
                    </div>

                    <!-- Search Input -->
                    <div class="relative min-w-[200px] sm:w-64">
                        <span class="material-icons absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm">search</span>
                        <input type="text" id="ranking-player-search" oninput="filterRankingBySearch(this.value)"
                            placeholder="Buscar jugador..."
                            class="w-full pl-9 pr-3 py-1.5 bg-slate-900/90 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/40 transition-all">
                    </div>
                </div>
            </div>

            <!-- 2. SCROLLABLE CONTENT BODY -->
            <div id="ranking-modal-body" class="relative z-10 flex-1 overflow-y-auto p-3 sm:p-6 custom-scrollbar space-y-6">
                <div class="flex flex-col items-center justify-center py-24 gap-4">
                    <div class="w-12 h-12 border-4 border-amber-500/20 border-t-amber-400 rounded-full animate-spin"></div>
                    <p class="text-xs font-black text-amber-300 uppercase tracking-widest">Calculando Ranking Acumulado Oficial...</p>
                </div>
            </div>

            <!-- 3. FOOTER INFO -->
            <div class="relative z-10 px-4 sm:px-6 py-2.5 border-t border-slate-800/80 bg-slate-950/90 backdrop-blur-md flex flex-wrap items-center justify-between gap-2 text-[9.5px] text-slate-400 font-bold uppercase tracking-wider">
                <div class="flex items-center gap-3">
                    <span class="flex items-center gap-1 text-amber-400">
                        <span class="material-icons text-xs">verified</span>
                        Regla Oficial: Suma de las 2 mejores tarjetas netas
                    </span>
                    <span class="hidden sm:inline text-slate-600">|</span>
                    <span class="hidden sm:inline text-slate-400">
                        Premiación: 🥇 70% Polla + Trofeo · 🥈 20% Polla + Trofeo
                    </span>
                </div>
                <div class="text-[9px] text-slate-500">
                    Sede Oficial: Club de Golf Colima
                </div>
            </div>
        </div>
    `,setTimeout(()=>{t.classList.remove(`opacity-0`),t.classList.add(`opacity-100`);let e=document.getElementById(`ranking-modal-content`);e&&(e.classList.remove(`scale-95`),e.classList.add(`scale-100`))},10),window.addEventListener(`keydown`,f),await _()}function f(e){e.key===`Escape`&&p()}function p(){let e=document.getElementById(`ranking-acumulado-modal`);if(!e)return;window.removeEventListener(`keydown`,f);let t=document.getElementById(`ranking-modal-content`);t&&(t.classList.remove(`scale-100`),t.classList.add(`scale-95`)),e.classList.remove(`opacity-100`),e.classList.add(`opacity-0`),setTimeout(()=>{e.remove(),document.body.style.overflow=``},300)}async function m(){n=null,await _()}function h(e){r=e,[`TODAS`,`CATEGORIA A`,`CATEGORIA B`,`CATEGORIA C`].forEach(t=>{let n=document.getElementById(`ranking-tab-${t}`);n&&(n.className=t===e?`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer bg-amber-400 text-slate-950 font-black shadow-lg shadow-amber-400/20`:`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700`)}),_()}function g(e){i=(e||``).trim().toLowerCase(),_()}async function _(e=`ranking-modal-body`){let t=document.getElementById(e);if(!t)return;let n=await u();if(!n){t.innerHTML=`
            <div class="py-20 text-center space-y-3">
                <span class="material-icons text-red-400 text-4xl">error_outline</span>
                <p class="text-red-400 text-xs font-black uppercase">No se pudieron cargar los datos del ranking acumulado.</p>
                <button onclick="refreshRankingAcumuladoData()" class="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer">Reintentar</button>
            </div>
        `;return}let{tourFechas:a,categories:o,totalPlayers:s,totalQualified:c}=n,l={};r===`TODAS`?Object.assign(l,o):o[r]?l[r]=o[r]:l[r]=[],i&&Object.keys(l).forEach(e=>{l[e]=l[e].filter(e=>e.name.toLowerCase().includes(i)||e.category.toLowerCase().includes(i))});let d=0;Object.values(l).forEach(e=>{d+=e.length});let f=o[`CATEGORIA A`]?.[0]?.name||`Por definir`,p=o[`CATEGORIA B`]?.[0]?.name||`Por definir`,m=o[`CATEGORIA C`]?.[0]?.name||`Por definir`,h=`
        <!-- STATS BANNER (5 TARJETAS COMPACTAS INCLUYENDO CAT A, B Y C) -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
            <div class="p-3 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-0.5">
                <span class="text-[8.5px] font-bold text-slate-400 uppercase tracking-wider block">Registrados</span>
                <div class="flex items-baseline gap-1.5">
                    <span class="text-xl sm:text-2xl font-black text-white">${s}</span>
                    <span class="text-[8px] font-bold text-slate-500 uppercase">jugadores</span>
                </div>
            </div>

            <div class="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl space-y-0.5">
                <span class="text-[8.5px] font-bold text-emerald-400 uppercase tracking-wider block">Calificados</span>
                <div class="flex items-baseline gap-1.5">
                    <span class="text-xl sm:text-2xl font-black text-emerald-300">${c}</span>
                    <span class="text-[8px] font-bold text-emerald-400/80 uppercase">con 2+ rds</span>
                </div>
            </div>

            <div class="p-3 bg-amber-500/10 border border-amber-500/30 rounded-2xl space-y-0.5">
                <span class="text-[8.5px] font-bold text-amber-400 uppercase tracking-wider block">Líder Cat A (0-10)</span>
                <p class="text-xs sm:text-sm font-black text-white truncate">${f}</p>
                <span class="text-[8px] font-bold text-amber-400/90 uppercase block">${o[`CATEGORIA A`]?.[0]?.accumulatedNeto?o[`CATEGORIA A`][0].accumulatedNeto+` Neto (2 Rds)`:`En juego`}</span>
            </div>

            <div class="p-3 bg-purple-500/10 border border-purple-500/30 rounded-2xl space-y-0.5">
                <span class="text-[8.5px] font-bold text-purple-400 uppercase tracking-wider block">Líder Cat B (11-20)</span>
                <p class="text-xs sm:text-sm font-black text-white truncate">${p}</p>
                <span class="text-[8px] font-bold text-purple-400/90 uppercase block">${o[`CATEGORIA B`]?.[0]?.accumulatedNeto?o[`CATEGORIA B`][0].accumulatedNeto+` Neto (2 Rds)`:`En juego`}</span>
            </div>

            <div class="p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-2xl space-y-0.5 col-span-2 sm:col-span-1">
                <span class="text-[8.5px] font-bold text-cyan-400 uppercase tracking-wider block">Líder Cat C (21-36)</span>
                <p class="text-xs sm:text-sm font-black text-white truncate">${m}</p>
                <span class="text-[8px] font-bold text-cyan-400/90 uppercase block">${o[`CATEGORIA C`]?.[0]?.accumulatedNeto?o[`CATEGORIA C`][0].accumulatedNeto+` Neto (2 Rds)`:`En juego`}</span>
            </div>
        </div>

        <!-- EXPLICACIÓN REGLA OFICIAL BANNER -->
        <div class="p-3.5 bg-gradient-to-r from-amber-500/10 via-slate-900/60 to-emerald-500/10 border border-amber-500/30 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5">
            <div class="flex items-center gap-2.5">
                <div class="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-sm shrink-0 shadow-md">
                    2/4
                </div>
                <div>
                    <h4 class="text-xs font-black uppercase text-white tracking-wide">Cómputo Automático de las 2 Mejores Tarjetas</h4>
                    <p class="text-[10px] text-slate-300 font-medium">
                        El sistema suma automáticamente los dos scores netos más bajos de cada jugador. Las tarjetas descartadas aparecen atenuadas con <span class="line-through text-slate-400">tachado</span>.
                    </p>
                </div>
            </div>
            <span class="px-2.5 py-1 rounded-xl bg-slate-950/80 border border-slate-700 text-emerald-400 text-[9px] font-black uppercase tracking-wider shrink-0">
                ★ Marca = Ronda Computada
            </span>
        </div>
    `;if(d===0){h+=`
            <div class="py-16 text-center space-y-3">
                <span class="material-icons text-slate-600 text-5xl">person_off</span>
                <p class="text-xs font-black uppercase tracking-widest text-slate-400">
                    ${i?`No se encontraron jugadores que coincidan con "${i}"`:`No hay jugadores registrados en esta categoría`}
                </p>
            </div>
        `,t.innerHTML=h;return}Object.keys(l).forEach(e=>{let t=l[e];if(t.length===0)return;let n=`0 - 10`;e.endsWith(` B`)||e.includes(`CAT B`)||e.includes(`CATEGORIA B`)?n=`11 - 20`:e.endsWith(` C`)||e.includes(`CAT C`)||e.includes(`CATEGORIA C`)?n=`21 - 36`:(e.endsWith(` A`)||e.includes(`CAT A`)||e.includes(`CATEGORIA A`))&&(n=`0 - 10`),h+=`
            <div class="space-y-3 pt-2">
                <!-- Header Categoría -->
                <div class="flex items-center justify-between gap-2 px-1">
                    <div class="flex items-center gap-2.5">
                        <div class="w-2 h-6 bg-gradient-to-b from-amber-400 to-emerald-400 rounded-full shadow-lg"></div>
                        <h3 class="text-base sm:text-lg font-black uppercase tracking-tight text-white">${e}</h3>
                        <span class="px-2.5 py-0.5 bg-slate-800 border border-slate-700 text-slate-300 text-[9px] font-bold rounded-full uppercase">
                            HCP ${n} (al 80%)
                        </span>
                    </div>
                    <span class="text-[10px] font-black text-amber-400 uppercase tracking-wider">
                        ${t.length} Jugadores
                    </span>
                </div>

                <!-- Tabla de Posiciones Acumuladas -->
                <div class="bg-slate-900/90 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
                    <div class="overflow-x-auto custom-scrollbar">
                        <table class="w-full text-left min-w-[700px]">
                            <thead>
                                <tr class="bg-slate-950/80 text-slate-400 text-[9px] font-black uppercase tracking-widest border-b border-slate-800">
                                    <th class="px-3 sm:px-4 py-3.5 w-12 text-center">POS</th>
                                    <th class="px-3 sm:px-4 py-3.5 min-w-[160px]">JUGADOR</th>
                                    ${a.map(e=>`
                                        <th class="px-2.5 sm:px-3 py-3.5 text-center whitespace-nowrap">
                                            <span>${e.shortDate}</span>
                                            ${e.isPending?`<span class="block text-[7.5px] text-slate-500 font-normal">Próxima</span>`:``}
                                        </th>
                                    `).join(``)}
                                    <th class="px-3 py-3.5 text-center text-slate-300 bg-slate-950/40">2 MEJORES</th>
                                    <th class="px-3 py-3.5 text-center bg-amber-500/10 text-amber-300 font-black">ACUMULADO</th>
                                    <th class="px-3 py-3.5 text-center w-28">ESTATUS</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-800/60">
                                ${t.map((e,t)=>{let n=t<3&&e.isQualified,r=`bg-slate-800 text-slate-300`,i=`#${t+1}`;return t===0&&e.isQualified?(r=`bg-amber-400 text-slate-950 shadow-md shadow-amber-400/30 ring-2 ring-amber-400/50`,i=`🥇 1`):t===1&&e.isQualified?(r=`bg-slate-200 text-slate-950 shadow-md shadow-slate-200/20`,i=`🥈 2`):t===2&&e.isQualified&&(r=`bg-amber-700 text-white shadow-md shadow-amber-700/20`,i=`🥉 3`),`
                                        <tr class="hover:bg-white/[0.02] transition-colors ${n?`bg-amber-500/[0.02]`:``}">
                                            <!-- Posición -->
                                            <td class="px-3 sm:px-4 py-3 text-center">
                                                <span class="w-8 h-8 flex items-center justify-center rounded-xl font-black text-xs mx-auto ${r}">
                                                    ${i}
                                                </span>
                                            </td>

                                            <!-- Jugador -->
                                            <td class="px-3 sm:px-4 py-3">
                                                <p class="font-black text-xs sm:text-sm uppercase text-white truncate max-w-[180px] sm:max-w-[220px]">
                                                    ${e.name}
                                                </p>
                                                <span class="text-[8.5px] font-bold text-slate-400 uppercase">
                                                    ${e.roundsPlayed} ${e.roundsPlayed===1?`ronda jugada`:`rondas jugadas`}
                                                </span>
                                            </td>

                                            <!-- Fechas individuales -->
                                            ${a.map(t=>{if(t.isPending)return`
                                                        <td class="px-2.5 sm:px-3 py-3 text-center">
                                                            <span class="text-slate-600 text-[10px] font-bold block">—</span>
                                                        </td>
                                                    `;let n=e.scoresByFecha[t.id];if(!n)return`
                                                        <td class="px-2.5 sm:px-3 py-3 text-center">
                                                            <span class="text-slate-600 text-xs font-bold block" title="No participó en esta fecha">—</span>
                                                        </td>
                                                    `;let r=e.bestTwoFechaIds.has(t.id),i=e.discardedFechaIds.has(t.id);return`
                                                    <td class="px-2.5 sm:px-3 py-3 text-center">
                                                        <div class="inline-flex flex-col items-center">
                                                            <span class="text-xs sm:text-sm font-black ${r?`text-emerald-400 font-black`:i?`text-slate-500 line-through`:`text-slate-200`}">
                                                                ${n.neto}
                                                            </span>
                                                            <span class="text-[7.5px] font-bold ${r?`text-emerald-400/80`:`text-slate-500`}">
                                                                ${r?`★ Mejor`:i?`descartada`:`G:${n.gross}`}
                                                            </span>
                                                        </div>
                                                    </td>
                                                `}).join(``)}

                                            <!-- 2 Mejores Rondas Desglose -->
                                            <td class="px-3 py-3 text-center bg-slate-950/40">
                                                ${e.isQualified?`
                                                    <span class="text-[11px] font-bold text-slate-300">
                                                        ${e.bestTwo.map(e=>e.neto).join(` + `)}
                                                    </span>
                                                `:`
                                                    <span class="text-[10px] text-slate-500 font-medium">
                                                        ${e.bestTwo.length===1?e.bestTwo[0].neto+` (1 sola)`:`Sin rondas`}
                                                    </span>
                                                `}
                                            </td>

                                            <!-- Acumulado Neto -->
                                            <td class="px-3 py-3 text-center bg-amber-500/10">
                                                <div class="inline-flex flex-col items-center">
                                                    <span class="text-sm sm:text-base font-black ${e.isQualified?`text-amber-300`:`text-slate-400`}">
                                                        ${e.accumulatedNeto||`—`}
                                                    </span>
                                                    ${e.isQualified?`
                                                        <span class="text-[7.5px] font-bold text-amber-400/80 uppercase">Neto Total</span>
                                                    `:`
                                                        <span class="text-[7.5px] font-bold text-slate-500 uppercase">Incompleto</span>
                                                    `}
                                                </div>
                                            </td>

                                            <!-- Estatus Oficial -->
                                            <td class="px-3 py-3 text-center">
                                                ${e.isQualified?`
                                                    <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[8px] font-black uppercase tracking-wider">
                                                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                                                        Calificado
                                                    </span>
                                                `:`
                                                    <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[8px] font-bold uppercase tracking-wider" title="Requiere jugar al menos 2 fechas para competir por el trofeo oficial">
                                                        Requiere F4
                                                    </span>
                                                `}
                                            </td>
                                        </tr>
                                    `}).join(``)}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `}),t.innerHTML=h}function v(){window.print()}var y=[{hole:1,par:4,idx:3},{hole:2,par:3,idx:7},{hole:3,par:4,idx:15},{hole:4,par:4,idx:9},{hole:5,par:3,idx:17},{hole:6,par:5,idx:1},{hole:7,par:3,idx:5},{hole:8,par:4,idx:11},{hole:9,par:4,idx:13},{hole:10,par:4,idx:4},{hole:11,par:3,idx:10},{hole:12,par:4,idx:16},{hole:13,par:4,idx:14},{hole:14,par:3,idx:18},{hole:15,par:5,idx:2},{hole:16,par:3,idx:8},{hole:17,par:4,idx:6},{hole:18,par:4,idx:12}],b=null,x=null,S=null,C=`posiciones`,w=null,T=null,E=null,D=null,O=null;function k(e,t){x=e,b=t,window.openLiveLeaderboardModal=M,window.closeLiveLeaderboardModal=P,window.switchLiveModalView=I,window.showLiveScorecard=V,window.closeLiveScorecard=H,window.printLiveModal=K,window.shareLiveLeaderboard=G}function A(e){if(!e)return{inStrokes:0,outStrokes:0,holeScores:{}};let t={};if(e.hole_scores)try{t=typeof e.hole_scores==`string`?JSON.parse(e.hole_scores):e.hole_scores}catch{t={}}else Array.isArray(e.holes)&&e.holes.forEach((e,n)=>{t[`h${n+1}`]=e});let n=0;for(let e=1;e<=9;e++){let r=parseInt(t[`h${e}`]);!isNaN(r)&&r>0&&(n+=r)}let r=0;for(let e=10;e<=18;e++){let n=parseInt(t[`h${e}`]);!isNaN(n)&&n>0&&(r+=n)}return n===0&&(e.in_score||e.in)&&(n=e.in_score||e.in||0),r===0&&(e.out_score||e.out)&&(r=e.out_score||e.out||0),{inStrokes:n,outStrokes:r,holeScores:t}}function j(e,t){if(e.neto!==t.neto)return e.neto-t.neto;let n=e._tiebreak||A(e.scoreObj||e.latestScore),r=t._tiebreak||A(t.scoreObj||t.latestScore);if(n.outStrokes!==r.outStrokes&&n.outStrokes>0&&r.outStrokes>0)return n.outStrokes-r.outStrokes;if(n.inStrokes!==r.inStrokes&&n.inStrokes>0&&r.inStrokes>0)return n.inStrokes-r.inStrokes;let i=[...y].sort((e,t)=>(e.idx||99)-(t.idx||99));for(let e of i){let t=parseInt(n.holeScores[`h${e.hole}`])||0,i=parseInt(r.holeScores[`h${e.hole}`])||0;if(t>0&&i>0&&t!==i)return t-i}return 0}async function M(e=null){let t=[];try{let{data:e}=await b.from(`tournaments`).select(`*`).order(`created_at`,{ascending:!1});e&&e.length>0&&(t=e)}catch{}let n=`b73a7380-589d-4986-84c4-7618d805fced`,r=`291bcd9c-674b-431e-9fd4-5690ce2b7b94`,i=`69452b77-44c7-400a-bb88-a763da03196b`,a=`dfecb440-d4ee-485f-b6d1-ad27f5032fc7`,o=e=>e&&(e.id===n||(e.name?.toLowerCase().includes(`8`)||e.name?.toLowerCase().includes(`1ª`)||e.name?.toLowerCase().includes(`1a`))&&e.name?.toLowerCase().includes(`ago`)&&!e.name?.toLowerCase().includes(`nov`)),s=e=>e&&(e.id===r||e.name?.toLowerCase().includes(`22`)&&e.name?.toLowerCase().includes(`ago`)),c=e=>e&&(e.id===i||(e.name?.toLowerCase().includes(`5`)||e.name?.toLowerCase().includes(`3ª`)||e.name?.toLowerCase().includes(`3a`))&&(e.name?.toLowerCase().includes(`sep`)||e.name?.toLowerCase().includes(`sept`))&&!e.name?.toLowerCase().includes(`nov`)),l=e=>e&&(e.id===a||(e.name?.toLowerCase().includes(`26`)||e.name?.toLowerCase().includes(`4ª`)||e.name?.toLowerCase().includes(`4a`))&&(e.name?.toLowerCase().includes(`sep`)||e.name?.toLowerCase().includes(`sept`))&&!e.name?.toLowerCase().includes(`nov`)),u=t.find(o),d=t.find(s),f=t.find(c),p=t.find(l),m=u?u.id:n,h=d?d.id:r,g=f?f.id:i,_=p?p.id:a,v=!1;if(_&&_!==`tourney-4-pending`)try{let{count:e}=await b.from(`scores`).select(`id`,{count:`exact`,head:!0}).eq(`eventid`,_);e&&e>0&&(v=!0)}catch{}!e||e===`5-sept-pending`||e===`69452b77-44c7-400a-bb88-a763da03196b`?(!e&&new Date<=new Date(2026,8,20,23,59,59)&&(e=x),(e===`69452b77-44c7-400a-bb88-a763da03196b`||!e||e===`5-sept-pending`)&&(e===`69452b77-44c7-400a-bb88-a763da03196b`?(S=g,w=f||t.find(e=>e.id===g)||null):v&&p?(S=_,w=p):f?(S=g,w=f):(S=g,w={id:g,name:`5 SEPTIEMBRE`,courses:`Club de Golf Colima`,config:{categories:[{name:`CATEGORIA A`,pct:80},{name:`CATEGORIA B`,pct:80},{name:`CATEGORIA C`,pct:80}]}}))):(S=e,w=t.find(t=>t.id===e)||null);let y=t.find(e=>e.id===`f116975d-d521-4001-91b5-2e21510f6be7`||e.name?.toLowerCase().includes(`mecate`)),x=y?y.id:`f116975d-d521-4001-91b5-2e21510f6be7`,C=w?.name&&o(w)||S===m,T=w?.name&&s(w)||S===h,E=w?.name&&c(w)||S===g,D=w?.name&&l(w)||S===_,O=S===x||w?.name?.toLowerCase().includes(`mecate`),k=!O&&(C||T||E||D),A=!O&&(C||T||E),j=document.getElementById(`live-leaderboard-modal`);j||(j=document.createElement(`div`),j.id=`live-leaderboard-modal`,j.className=`fixed inset-0 z-[90] flex items-center justify-center p-2 sm:p-4 md:p-6 bg-slate-950/95 backdrop-blur-2xl transition-all duration-300 opacity-0`,document.body.appendChild(j)),document.body.style.overflow=`hidden`,j.innerHTML=`
        <div class="relative w-full max-w-5xl h-[94vh] max-h-[95vh] bg-slate-950/95 border border-slate-800 rounded-[2rem] sm:rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col transform scale-95 transition-all duration-300" id="live-modal-content">
            
            <!-- Glow background accents -->
            <div class="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] ${A?`bg-amber-500/10`:`bg-emerald-500/10`} blur-[100px] rounded-full pointer-events-none"></div>
            <div class="absolute -bottom-[20%] -right-[10%] w-[50%] h-[50%] bg-blue-500/10 blur-[100px] rounded-full pointer-events-none"></div>

            <!-- 1. MODAL HEADER -->
            <div class="relative z-10 px-4 sm:px-8 py-4 sm:py-5 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-xl flex flex-col gap-3">
                <div class="flex items-center justify-between gap-2">
                    <!-- Left: Logos & Title -->
                    <div class="flex items-center gap-3 min-w-0">
                        <div class="flex items-center gap-2 p-1.5 bg-white/5 border border-white/10 rounded-2xl shadow-md shrink-0">
                            <img src="./golcolima.jpg" alt="Club Colima" class="h-9 sm:h-11 w-auto object-contain rounded-xl" onerror="this.style.display='none'">
                            <img src="./logoclub.png" alt="Asociación" class="h-9 sm:h-11 w-auto object-contain rounded-xl" onerror="this.style.display='none'">
                        </div>
                        <div class="min-w-0">
                            <div class="flex items-center gap-2">
                                ${A?`
                                    <div class="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 w-max">
                                        <span class="w-2 h-2 rounded-full bg-amber-400"></span>
                                        <span class="text-[9px] font-black uppercase tracking-wider">Torneo Finalizado · Resultados</span>
                                    </div>
                                `:`
                                    <span class="flex h-2 w-2 relative shrink-0">
                                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                                        <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                                    </span>
                                    <span class="text-[9px] font-black uppercase tracking-[0.25em] text-emerald-400">Torneo en Vivo / Salidas</span>
                                `}
                            </div>
                            <h2 id="live-modal-tournament-name" class="text-base sm:text-2xl font-black uppercase tracking-tight text-white truncate leading-tight mt-0.5">
                                ${w?.name||`Cargando Torneo...`}
                            </h2>
                            <p id="live-modal-location" class="text-[9px] sm:text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1 truncate">
                                <span class="material-icons text-[12px] text-emerald-400">location_on</span>
                                <span>${w?.courses||`Club de Golf Colima`}</span>
                            </p>
                        </div>
                    </div>

                    <!-- Right: Quick Actions + Close -->
                    <div class="flex items-center gap-2 shrink-0">
                        <button onclick="shareLiveLeaderboard()" title="Compartir Leaderboard" class="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white transition-all cursor-pointer">
                            <span class="material-icons text-sm sm:text-base">share</span>
                        </button>
                        <button onclick="printLiveModal()" title="Imprimir / Reporte PDF" class="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white transition-all cursor-pointer">
                            <span class="material-icons text-sm sm:text-base">print</span>
                        </button>
                        <button onclick="closeLiveLeaderboardModal()" title="Cerrar (Esc)" class="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-emerald-500/15 hover:bg-red-500/20 border border-emerald-500/30 hover:border-red-500/40 flex items-center justify-center text-emerald-400 hover:text-red-400 transition-all cursor-pointer">
                            <span class="material-icons text-base sm:text-lg">close</span>
                        </button>
                    </div>
                </div>

                <!-- SWITCHER PILLS (Exclusively for Ranking Tournament) -->
                ${k?`
                <div class="flex items-center gap-2 overflow-x-auto pb-1 pt-1 custom-scrollbar">
                    <span class="text-[9px] font-black uppercase text-slate-400 shrink-0 flex items-center gap-1">
                        <span class="material-icons text-xs text-amber-400">event</span> Fechas Jugadas:
                    </span>
                    <button onclick="openLiveLeaderboardModal('${m}')"
                        class="px-3 py-1.5 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shrink-0
                        ${S===m?`bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/30 ring-2 ring-amber-400`:`bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 hover:border-amber-400`}">
                        <span class="w-2 h-2 rounded-full ${S===m?`bg-slate-950`:`bg-amber-400`}"></span>
                        1ª Fecha · 8 Ago
                    </button>
                    <button onclick="openLiveLeaderboardModal('${h}')"
                        class="px-3 py-1.5 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shrink-0
                        ${S===h?`bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/30 ring-2 ring-amber-400`:`bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 hover:border-amber-400`}">
                        <span class="w-2 h-2 rounded-full ${S===h?`bg-slate-950`:`bg-amber-400`}"></span>
                        2ª Fecha · 22 Ago
                    </button>
                    <button onclick="openLiveLeaderboardModal('${g}')"
                        class="px-3 py-1.5 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shrink-0
                        ${S===g?`bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/30 ring-2 ring-amber-400`:`bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 hover:border-amber-400`}">
                        <span class="w-2 h-2 rounded-full ${S===g?`bg-slate-950`:`bg-amber-400`}"></span>
                        3ª Fecha · 5 Sept
                    </button>
                    ${v?`
                        <button onclick="openLiveLeaderboardModal('${_}')"
                            class="px-3 py-1.5 rounded-xl text-[9px] sm:text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shrink-0
                            ${S===_?`bg-emerald-500 text-slate-950 font-black shadow-lg shadow-emerald-500/30 ring-2 ring-emerald-400`:`bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20 hover:border-emerald-400`}">
                            <span class="w-2 h-2 rounded-full ${S===_?`bg-slate-950`:`bg-emerald-400 animate-pulse`}"></span>
                            4ª Fecha · 26 Sept
                        </button>
                    `:``}
                </div>
                `:``}

                <!-- View Switcher Tabs -->
                <div class="flex p-1 bg-slate-900/80 backdrop-blur-xl rounded-2xl border border-slate-800/80 shadow-inner mt-1 gap-1">
                    <button onclick="switchLiveModalView('posiciones')" id="modal-tab-posiciones"
                        class="flex-1 py-2 sm:py-2.5 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-wider transition-all duration-200 ${A?`bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20`:`bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20`}">
                        🏆 Leaderboard
                    </button>
                    ${k?`
                        <button onclick="switchLiveModalView('ranking-acumulado')" id="modal-tab-ranking-acumulado"
                            class="flex-1 py-2 sm:py-2.5 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-wider transition-all duration-200 text-slate-400 hover:text-white flex items-center justify-center gap-1">
                            <span class="material-icons text-xs sm:text-sm text-amber-400">emoji_events</span>
                            <span>Ranking Acumulado</span>
                        </button>
                    `:``}
                    <button onclick="switchLiveModalView('salidas')" id="modal-tab-salidas"
                        class="flex-1 py-2 sm:py-2.5 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-wider transition-all duration-200 text-slate-400 hover:text-white">
                        🚩 Salidas
                    </button>
                    <button onclick="switchLiveModalView('oyeses')" id="modal-tab-oyeses"
                        class="flex-1 py-2 sm:py-2.5 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-wider transition-all duration-200 text-slate-400 hover:text-white">
                        🎯 Oye's
                    </button>
                </div>
            </div>

            <!-- 2. SCROLLABLE CONTENT BODY -->
            <div id="live-modal-content-area" class="relative z-10 flex-1 overflow-y-auto p-4 sm:p-8 custom-scrollbar space-y-6">
                <div class="flex flex-col items-center justify-center py-24 gap-4">
                    <div class="w-12 h-12 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin"></div>
                    <p class="text-xs font-black text-slate-400 uppercase tracking-widest">Cargando Resultados en Vivo...</p>
                </div>
            </div>

            <!-- 3. FOOTER INFO -->
            <div class="relative z-10 px-6 py-3 border-t border-slate-800/80 bg-slate-950/80 backdrop-blur-md flex items-center justify-between text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                <div class="flex items-center gap-2">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <span>Colima Golf Club &middot; En Vivo</span>
                </div>
                <a href="${window.location.origin}/torneo/?id=${S}" target="_blank" class="hover:text-emerald-400 transition-colors flex items-center gap-1 text-[9px]">
                    <span>Abrir en pestaña completa</span>
                    <span class="material-icons text-[12px]">open_in_new</span>
                </a>
            </div>
        </div>
    `,setTimeout(()=>{j.classList.remove(`opacity-0`),j.classList.add(`opacity-100`);let e=document.getElementById(`live-modal-content`);e&&(e.classList.remove(`scale-95`),e.classList.add(`scale-100`))},10),window.addEventListener(`keydown`,N),await F(),U()}function N(e){e.key===`Escape`&&(document.getElementById(`live-scorecard-modal`)?H():P())}function P(){let e=document.getElementById(`live-leaderboard-modal`);if(!e)return;W(),window.removeEventListener(`keydown`,N);let t=document.getElementById(`live-modal-content`);t&&(t.classList.remove(`scale-100`),t.classList.add(`scale-95`)),e.classList.remove(`opacity-100`),e.classList.add(`opacity-0`),setTimeout(()=>{e.remove(),document.body.style.overflow=``},300)}async function F(){if(S===`5-sept-pending`){w={id:`5-sept-pending`,name:`3ª FECHA · 5 DE SEPTIEMBRE`,courses:`Club de Golf Colima`,config:{categories:[{name:`CATEGORIA A`,pct:80},{name:`CATEGORIA B`,pct:80},{name:`CATEGORIA C`,pct:80}]}},T=[],E=[],D=[],C=`posiciones`;let e=document.getElementById(`live-modal-tournament-name`),t=document.getElementById(`live-modal-location`);e&&(e.textContent=`3ª FECHA · 5 DE SEPTIEMBRE`),t&&(t.innerHTML=`<span class="material-icons text-[12px] text-emerald-400">location_on</span> <span>Club de Golf Colima</span>`),[`posiciones`,`salidas`,`oyeses`].forEach(e=>{let t=document.getElementById(`modal-tab-${e}`);t&&(t.className=e===C?`flex-1 py-2.5 sm:py-3 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-wider transition-all duration-200 bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20`:`flex-1 py-2.5 sm:py-3 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-wider transition-all duration-200 text-slate-400 hover:text-white`)}),L();return}try{let[e,t,n,r]=await Promise.all([b.from(`tournaments`).select(`*`).eq(`id`,S).single(),b.from(`teams`).select(`*`).eq(`eventid`,String(S)),b.from(`scores`).select(`*`).eq(`eventid`,String(S)),b.from(`oyeses`).select(`*`).eq(`eventid`,String(S))]);if(e.data){w=e.data;let t=document.getElementById(`live-modal-tournament-name`),n=document.getElementById(`live-modal-location`);t&&(t.textContent=w.name||`TORNEO DE GOLF`),n&&(n.innerHTML=`<span class="material-icons text-[12px] text-emerald-400">location_on</span> <span>${w.courses||`Club de Golf Colima`}</span>`)}T=t.data||[],E=n.data||[],D=r.data||[],C=E.length===0&&T.length>0?`salidas`:`posiciones`;let i=w?.name?.toLowerCase().includes(`8`)&&w?.name?.toLowerCase().includes(`agosto`)?`bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20`:`bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20`;[`posiciones`,`salidas`,`oyeses`].forEach(e=>{let t=document.getElementById(`modal-tab-${e}`);t&&(t.className=e===C?`flex-1 py-2.5 sm:py-3 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-wider transition-all duration-200 ${i}`:`flex-1 py-2.5 sm:py-3 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-wider transition-all duration-200 text-slate-400 hover:text-white`)}),L()}catch(e){console.error(`Error loading live tournament data:`,e);let t=document.getElementById(`live-modal-content-area`);t&&(t.innerHTML=`
                <div class="py-20 text-center space-y-3">
                    <span class="material-icons text-red-400 text-4xl">error_outline</span>
                    <p class="text-red-400 text-xs font-black uppercase">No se pudieron cargar los datos del torneo.</p>
                    <button onclick="openLiveLeaderboardModal('${S}')" class="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider">Reintentar</button>
                </div>
            `)}}function I(e){C=e;let t=w?.name?.toLowerCase().includes(`8`)&&w?.name?.toLowerCase().includes(`agosto`)?`bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 font-black`:`bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20 font-black`;[`posiciones`,`ranking-acumulado`,`salidas`,`oyeses`].forEach(n=>{let r=document.getElementById(`modal-tab-${n}`);r&&(r.className=n===e?`flex-1 py-2 sm:py-2.5 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-wider transition-all duration-200 ${n===`ranking-acumulado`?`bg-amber-400 text-slate-950 shadow-lg shadow-amber-400/20`:t}`:`flex-1 py-2 sm:py-2.5 rounded-xl text-[10px] sm:text-xs font-black uppercase tracking-wider transition-all duration-200 text-slate-400 hover:text-white`)}),L()}function L(){let e=document.getElementById(`live-modal-content-area`);e&&(C===`posiciones`?R(e):C===`ranking-acumulado`?_(`live-modal-content-area`):C===`salidas`?z(e):C===`oyeses`&&B(e))}function R(e){let t=T||[],n=E||[];if(n.length===0){e.innerHTML=`
            <div class="py-24 text-center space-y-4 max-w-md mx-auto">
                <div class="w-16 h-16 rounded-3xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/10">
                    <span class="material-icons text-3xl">emoji_events</span>
                </div>
                <div class="space-y-2">
                    <h4 class="text-base font-black uppercase tracking-tight text-white">Esperando Registro de Scores</h4>
                    <p class="text-xs text-slate-400 leading-relaxed font-medium">
                        ${t.length>0?`Los jugadores y salidas ya están registrados. En cuanto comiencen a capturarse los scores hoyo por hoyo, el leaderboard se actualizará automáticamente en tiempo real.`:`El torneo "${w?.name||`Torneo`}" se encuentra en preparación. En cuanto se creen los registros y se capturen los primeros scores, la tabla de posiciones aparecerá aquí en tiempo real.`}
                    </p>
                </div>
            </div>`;return}let r={};t.forEach(e=>{let t=(e.category||`GENERAL`).replace(/\s+/g,` `).trim(),i=n.filter(t=>String(t.teamid)===String(e.id));if(i.length>0){let n=i.reduce((e,t)=>e+(t.total||0),0);r[t]||(r[t]=[]);let a=i[0];r[t].push({team:e,total:n,rounds:i.length,scoreObj:a,_tiebreak:A(a)})}});let i=Object.keys(r).sort();if(i.length===0){e.innerHTML=`
            <div class="py-24 text-center space-y-3">
                <span class="material-icons text-slate-600 text-5xl">emoji_events</span>
                <p class="text-xs font-black uppercase tracking-widest text-slate-400">Sin datos de categorías registradas</p>
            </div>`;return}e.innerHTML=i.map(e=>`
        <div class="space-y-4 mb-8">
            <div class="flex items-center gap-3 px-1">
                <div class="w-1.5 h-6 bg-emerald-400 rounded-full shadow-[0_0_10px_rgba(52,211,153,0.4)]"></div>
                <h3 class="text-lg sm:text-xl font-black uppercase tracking-tight text-white">${e}</h3>
                <span class="text-[10px] font-bold text-slate-500 uppercase ml-auto">${r[e].length} JUGADORES</span>
            </div>

            <div class="bg-slate-900/90 rounded-3xl border border-slate-800 overflow-hidden shadow-xl">
                <div class="overflow-x-auto custom-scrollbar">
                    <table class="w-full text-left min-w-[480px] sm:min-w-full">
                        <thead>
                            <tr class="bg-slate-950/70 text-slate-400 text-[9px] font-black uppercase tracking-widest border-b border-slate-800">
                                <th class="px-3 sm:px-5 py-4 w-12 sm:w-16 text-center">POS</th>
                                <th class="px-3 sm:px-5 py-4">EQUIPO / JUGADOR</th>
                                <th class="px-3 sm:px-5 py-4 text-center">RDS</th>
                                <th class="px-3 sm:px-5 py-4 text-center">VTJ</th>
                                <th class="px-3 sm:px-5 py-4 text-center">GROSS</th>
                                <th class="px-3 sm:px-5 py-4 text-center bg-emerald-500/10 text-emerald-400">NETO</th>
                                <th class="px-3 sm:px-5 py-4 text-center w-16">INFO</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-800/60">
                            ${r[e].map(e=>{let t=e.team.ventaja||0,n=e.total,r=n-t*e.rounds;return{...e,gross:n,neto:r,advantage:t}}).sort(j).map((e,t)=>{let n=e.advantage===0?`0`:`-${Math.abs(e.advantage)}`;return`
                                <tr class="hover:bg-white/[0.02] transition-colors">
                                    <td class="px-3 sm:px-5 py-3.5 sm:py-4 text-center">
                                        <span class="w-7 h-7 sm:w-8 sm:h-8 flex items-center justify-center rounded-xl font-black text-xs sm:text-sm mx-auto ${t===0?`bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20`:`bg-slate-800 text-white`}">
                                            #${t+1}
                                        </span>
                                    </td>
                                    <td class="px-3 sm:px-5 py-3.5 sm:py-4">
                                        <p class="font-black text-xs sm:text-sm uppercase text-white truncate max-w-[140px] sm:max-w-none">${e.team.teamname||`JUGADOR`}</p>
                                    </td>
                                    <td class="px-3 sm:px-5 py-3.5 sm:py-4 text-center text-slate-300 font-bold text-xs sm:text-sm">${e.rounds}</td>
                                    <td class="px-3 sm:px-5 py-3.5 sm:py-4 text-center text-blue-400 font-bold text-xs sm:text-sm">${n}</td>
                                    <td class="px-3 sm:px-5 py-3.5 sm:py-4 text-center text-slate-200 font-bold text-xs sm:text-sm">${e.gross}</td>
                                    <td class="px-3 sm:px-5 py-3.5 sm:py-4 text-center bg-emerald-500/10">
                                        <span class="text-base sm:text-lg font-black text-emerald-400">${e.neto}</span>
                                    </td>
                                    <td class="px-3 sm:px-5 py-3.5 sm:py-4 text-center">
                                        <button onclick="showLiveScorecard('${e.team.id}', '${(e.team.teamname||``).replace(/'/g,`\\'`)}')" 
                                            class="w-8 h-8 rounded-xl bg-slate-800 hover:bg-emerald-500 hover:text-slate-950 text-slate-400 flex items-center justify-center mx-auto transition-all cursor-pointer" title="Ver Tarjeta de Score">
                                            <span class="material-icons text-sm">visibility</span>
                                        </button>
                                    </td>
                                </tr>
                                `}).join(``)}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `).join(``)}function z(e){let t=T||[];if(t.length===0){e.innerHTML=`
            <div class="py-24 text-center space-y-3">
                <span class="material-icons text-slate-600 text-5xl">golf_course</span>
                <p class="text-xs font-black uppercase tracking-widest text-slate-400">No hay salidas programadas.</p>
            </div>`;return}let n={};t.forEach(e=>{let t=e.hole!==null&&e.hole!==void 0&&e.hole!==``?e.hole:e.starting_hole||`SIN HOYO`;n[t]||(n[t]=[]),n[t].push(e)}),e.innerHTML=`
        <div class="grid gap-6 pb-6">
            ${Object.keys(n).sort((e,t)=>(parseInt(e)||99)-(parseInt(t)||99)).map(e=>`
                <div class="bg-slate-900/90 rounded-3xl border border-slate-800 overflow-hidden shadow-xl">
                    <div class="bg-slate-950/80 px-6 py-4 flex items-center justify-between border-b border-slate-800">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                                <span class="material-icons text-sm">flag</span>
                            </div>
                            <h3 class="text-base sm:text-lg font-black uppercase text-white tracking-tight">
                                ${isNaN(parseInt(e))?e:`Hoyo ${e}`}
                            </h3>
                        </div>
                        <span class="text-[9px] font-black text-slate-500 uppercase tracking-widest">${n[e].length} EQUIPOS</span>
                    </div>

                    <div class="p-4 sm:p-6 grid gap-4 grid-cols-1 md:grid-cols-2">
                        ${n[e].map(e=>{let t=e.players&&Array.isArray(e.players)?e.players.map(e=>`${e.name} <strong class="text-white">(${e.hdcp||0})</strong>`):[e.player1,e.player2,e.player3,e.player4].filter(e=>e&&e.trim()!==``);return`
                                <div class="p-4 bg-slate-950/60 rounded-2xl border border-slate-800/80 flex flex-col sm:flex-row justify-between items-center gap-4">
                                    <div class="min-w-0 w-full flex-1">
                                        <p class="text-[8px] font-black text-slate-500 uppercase mb-0.5">Equipo #${e.teamnumber||`?`}</p>
                                        <h4 class="font-black text-xs sm:text-sm uppercase text-white truncate mb-2 leading-tight">${e.teamname||`EQUIPO`}</h4>
                                        <div class="grid grid-cols-2 gap-x-2 gap-y-1">
                                            ${t.map(e=>`<div class="text-[9px] font-bold text-slate-400 uppercase truncate">${e}</div>`).join(``)}
                                        </div>
                                    </div>
                                    <div class="shrink-0 flex items-center gap-2">
                                        <div class="flex flex-col items-center px-3 py-1.5 bg-slate-800 rounded-xl border border-slate-700 min-w-[45px]">
                                            <span class="text-[7px] font-black text-slate-400 uppercase">HCP</span>
                                            <span class="text-xs font-black text-white leading-none mt-0.5">${e.hdcp||0}</span>
                                        </div>
                                        <div class="flex flex-col items-center px-3 py-1.5 bg-emerald-500/10 rounded-xl border border-emerald-500/30 min-w-[45px]">
                                            <span class="text-[7px] font-black text-emerald-400 uppercase">VTJ</span>
                                            <span class="text-xs font-black text-emerald-400 leading-none mt-0.5">${e.ventaja||0}</span>
                                        </div>
                                    </div>
                                </div>
                            `}).join(``)}
                    </div>
                </div>
            `).join(``)}
        </div>
    `}function B(e){let t=D||[];if(t.length===0){e.innerHTML=`
            <div class="py-24 text-center space-y-3">
                <span class="material-icons text-slate-600 text-5xl">military_tech</span>
                <p class="text-xs font-black uppercase tracking-widest text-slate-400">No hay registros de Oye's.</p>
                <p class="text-[11px] text-slate-500">Los tiros más cercanos a la bandera se publicarán aquí.</p>
            </div>`;return}let n={};t.forEach(e=>{let t=e.hole||`?`;n[t]||(n[t]=[]),n[t].push(e)}),e.innerHTML=`
        <div class="space-y-8 pb-6">
            <div class="text-center space-y-1">
                <h3 class="text-xl font-black uppercase tracking-tight text-white">Premios Oye's a la Bandera</h3>
                <p class="text-xs font-bold text-slate-400 uppercase tracking-widest">Tiro más cercano al hoyo</p>
            </div>

            ${Object.keys(n).sort((e,t)=>(parseInt(e)||99)-(parseInt(t)||99)).map(e=>`
                <div class="space-y-3">
                    <div class="flex items-center gap-3">
                        <div class="h-px flex-1 bg-slate-800"></div>
                        <span class="text-xs font-black uppercase tracking-[0.25em] px-4 py-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400">
                            🚩 Hoyo ${e}
                        </span>
                        <div class="h-px flex-1 bg-slate-800"></div>
                    </div>

                    <div class="grid gap-2.5">
                        ${n[e].sort((e,t)=>parseFloat(e.distance)-parseFloat(t.distance)).map((e,t)=>`
                            <div class="flex items-center justify-between p-3.5 sm:p-4 rounded-2xl bg-slate-900/80 border ${t===0?`border-amber-500/40 bg-amber-500/5 shadow-lg shadow-amber-500/5`:`border-slate-800`}">
                                <div class="flex items-center gap-3 min-w-0 flex-1">
                                    <div class="w-8 h-8 rounded-xl ${t===0?`bg-amber-400 text-slate-950 font-black`:`bg-slate-800 text-slate-300`} flex items-center justify-center font-black text-xs shrink-0">
                                        ${t===0?`🥇`:t+1}
                                    </div>
                                    <h4 class="text-xs sm:text-sm font-black uppercase text-white truncate">${e.player_name||e.playername}</h4>
                                </div>
                                <div class="px-3.5 py-1.5 rounded-xl bg-slate-950 font-black text-emerald-400 text-xs shrink-0 border border-slate-800">
                                    ${e.distance}
                                </div>
                            </div>
                        `).join(``)}
                    </div>
                </div>`).join(``)}
        </div>
    `}function V(e,t){let n=document.getElementById(`live-scorecard-modal`);n||(n=document.createElement(`div`),n.id=`live-scorecard-modal`,n.className=`fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 backdrop-blur-xl animate-fade-in`,document.body.appendChild(n));let r=(E||[]).filter(t=>String(t.teamid)===String(e)),i=(T||[]).find(t=>String(t.id)===String(e))?.ventaja||0;if(!r||r.length===0){n.innerHTML=`
            <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center max-w-sm w-full space-y-4 shadow-2xl">
                <span class="material-icons text-amber-400 text-4xl">info</span>
                <h3 class="font-black text-white uppercase text-sm">Sin Scorecard</h3>
                <p class="text-slate-400 text-xs font-bold">No hay tarjetas registradas para ${t}.</p>
                <button onclick="closeLiveScorecard()" class="px-6 py-2.5 bg-emerald-500 text-slate-950 rounded-xl font-black text-xs uppercase cursor-pointer">Cerrar</button>
            </div>`;return}let a=r.map(e=>{let t={};if(e.hole_scores)try{t=typeof e.hole_scores==`string`?JSON.parse(e.hole_scores):e.hole_scores}catch{t={}}let n=e.in_score!==void 0&&e.in_score!==null?e.in_score:e.in||0,r=e.out_score!==void 0&&e.out_score!==null?e.out_score:e.out||0,a=e.gross||e.total||0,o=e.net!==void 0&&e.net!==null?e.net:a>0?a-i:0,s=[];for(let e=1;e<=18;e++)s.push(t[`h${e}`]===void 0?`-`:t[`h${e}`]);return`
            <div class="bg-slate-900 rounded-3xl border border-slate-800 shadow-xl overflow-hidden mb-5">
                <div class="bg-emerald-500 px-5 py-3 flex justify-between items-center text-slate-950">
                    <h4 class="font-black uppercase text-[10px] sm:text-xs tracking-widest">${e.coursename||`CLUB DE GOLF COLIMA`}</h4>
                    <div class="flex items-center gap-2">
                        <span class="text-[9px] font-black uppercase bg-slate-950/20 px-2.5 py-1 rounded-full">Gross: ${a}</span>
                        <span class="text-[9px] font-black uppercase bg-slate-950/40 text-blue-300 px-2.5 py-1 rounded-full">VTJ: −${i}</span>
                        <span class="text-[10px] font-black uppercase bg-slate-950 text-emerald-400 px-2.5 py-1 rounded-full">Neto: ${o}</span>
                    </div>
                </div>
                <div class="p-4 sm:p-6">
                    <p class="text-[8px] sm:text-[9px] font-black uppercase text-slate-400 tracking-widest mb-2">VUELTA 1-9 (IN)</p>
                    <div class="grid grid-cols-9 gap-1 sm:gap-1.5 mb-4">
                        ${s.slice(0,9).map((e,t)=>`
                            <div class="flex flex-col items-center">
                                <span class="text-[8px] text-slate-500 font-bold mb-0.5">#${t+1}</span>
                                <div class="w-full py-2 bg-slate-800/80 border border-slate-700/80 rounded-xl text-center font-black text-[11px] sm:text-xs text-white">${e}</div>
                            </div>
                        `).join(``)}
                    </div>

                    <p class="text-[8px] sm:text-[9px] font-black uppercase text-slate-400 tracking-widest mb-2">VUELTA 10-18 (OUT)</p>
                    <div class="grid grid-cols-9 gap-1 sm:gap-1.5 mb-5">
                        ${s.slice(9,18).map((e,t)=>`
                            <div class="flex flex-col items-center">
                                <span class="text-[8px] text-slate-500 font-bold mb-0.5">#${t+10}</span>
                                <div class="w-full py-2 bg-slate-800/80 border border-slate-700/80 rounded-xl text-center font-black text-[11px] sm:text-xs text-white">${e}</div>
                            </div>
                        `).join(``)}
                    </div>

                    <div class="flex justify-between items-center pt-3 border-t border-slate-800">
                        <div class="flex gap-2">
                            <div class="text-center px-3 py-1 bg-slate-800 rounded-xl">
                                <p class="text-[7px] text-slate-400 font-black">IN (1-9)</p>
                                <p class="font-black text-white text-xs sm:text-sm">${n}</p>
                            </div>
                            <div class="text-center px-3 py-1 bg-slate-800 rounded-xl">
                                <p class="text-[7px] text-slate-400 font-black">OUT (10-18)</p>
                                <p class="font-black text-white text-xs sm:text-sm">${r}</p>
                            </div>
                            <div class="text-center px-3 py-1 bg-blue-500/10 border border-blue-500/30 rounded-xl">
                                <p class="text-[7px] text-blue-400 font-black">VENTAJA</p>
                                <p class="font-black text-blue-400 text-xs sm:text-sm">−${i}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="text-[7px] text-slate-400 font-black uppercase">TOTAL NETO</p>
                            <p class="text-xl sm:text-2xl font-black text-emerald-400">${o}</p>
                        </div>
                    </div>
                </div>
            </div>
        `}).join(``);n.innerHTML=`
        <div class="w-full max-w-2xl bg-slate-950/95 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div class="p-4 sm:p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/60">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                        <span class="material-icons">sports_golf</span>
                    </div>
                    <div>
                        <h3 class="font-black uppercase text-white text-sm sm:text-base truncate">${t}</h3>
                        <p class="text-[9px] text-emerald-400 font-black uppercase tracking-widest">Tarjeta Oficial de Score</p>
                    </div>
                </div>
                <button onclick="closeLiveScorecard()" class="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer">
                    <span class="material-icons text-sm">close</span>
                </button>
            </div>
            <div class="p-4 sm:p-6 overflow-y-auto custom-scrollbar flex-1 space-y-3">${a}</div>
        </div>
    `}function H(){let e=document.getElementById(`live-scorecard-modal`);e&&e.remove()}function U(){if(!(!x||!S||S===`5-sept-pending`))try{O&&x.removeChannel(O),O=x.channel(`live-modal-${S}`).on(`postgres_changes`,{event:`*`,schema:`colimaGC`,table:`scores`,filter:`eventid=eq.${S}`},async()=>{let{data:e}=await b.from(`scores`).select(`*`).eq(`eventid`,String(S));e&&(E=e),L()}).on(`postgres_changes`,{event:`*`,schema:`colimaGC`,table:`oyeses`,filter:`eventid=eq.${S}`},async()=>{let{data:e}=await b.from(`oyeses`).select(`*`).eq(`eventid`,String(S));e&&(D=e),L()}).on(`postgres_changes`,{event:`*`,schema:`colimaGC`,table:`teams`,filter:`eventid=eq.${S}`},async()=>{let{data:e}=await b.from(`teams`).select(`*`).eq(`eventid`,String(S));e&&(T=e),L()}).subscribe()}catch(e){console.warn(`Realtime subscription delayed:`,e)}}function W(){if(O&&x)try{x.removeChannel(O),O=null}catch(e){console.warn(e)}}function G(){let e=`${window.location.origin}/torneo/?id=${S}`;navigator.share?navigator.share({title:w?.name||`Leaderboard en Vivo · Club de Golf Colima`,text:`Sigue los resultados en vivo del torneo ${w?.name||``} en Club de Golf Colima:`,url:e}).catch(()=>{}):navigator.clipboard&&navigator.clipboard.writeText(e).then(()=>{alert(`¡Enlace del Leaderboard copiado al portapapeles!`)})}function K(){if(!w)return;let e=`${window.location.origin}/torneo/?id=${S}&view=${C}`;window.open(e,`_blank`)}var q=e(`https://tztolxgsaktqindoimtu.supabase.co`,`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR6dG9seGdzYWt0cWluZG9pbXR1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYyNzQ4ODAsImV4cCI6MjEwMTg1MDg4MH0.E2GABiOMXYb5hEwE9ErIcJa6_LHkj9lJUglQVoiLl0M`),J=q.schema(`colimaGC`);async function Y(e){k(q,J),a(q,J);let t=[`./imagenes/DJI_0001.JPG`,`./imagenes/DJI_0002.JPG`,`./imagenes/DJI_0003.JPG`,`./imagenes/DJI_0004.JPG`,`./imagenes/DJI_0008.JPG`,`./imagenes/DJI_0012.JPG`,`./imagenes/DJI_0013.JPG`,`./imagenes/DJI_0014.JPG`,`./imagenes/DJI_0015.JPG`,`./imagenes/DJI_0016.JPG`,`./imagenes/DJI_0017.JPG`],n=`b73a7380-589d-4986-84c4-7618d805fced`,r=`291bcd9c-674b-431e-9fd4-5690ce2b7b94`,i=`69452b77-44c7-400a-bb88-a763da03196b`,o=`dfecb440-d4ee-485f-b6d1-ad27f5032fc7`,s=`f116975d-d521-4001-91b5-2e21510f6be7`,c=[],l=!1,u=`69452b77-44c7-400a-bb88-a763da03196b`;try{let{data:e}=await J.from(`tournaments`).select(`id, name, created_at`).order(`created_at`,{ascending:!1});if(e&&e.length>0){c=e;let t=e.find(e=>e.id===s||e.name?.toLowerCase().includes(`mecate`));t&&(s=t.id);let a=e=>e&&(e.id===n||(e.name?.toLowerCase().includes(`8`)||e.name?.toLowerCase().includes(`1ª`)||e.name?.toLowerCase().includes(`1a`))&&e.name?.toLowerCase().includes(`ago`)&&!e.name?.toLowerCase().includes(`nov`)),d=e=>e&&(e.id===r||e.name?.toLowerCase().includes(`22`)&&e.name?.toLowerCase().includes(`ago`)),f=e=>e&&(e.id===i||(e.name?.toLowerCase().includes(`5`)||e.name?.toLowerCase().includes(`3ª`)||e.name?.toLowerCase().includes(`3a`))&&(e.name?.toLowerCase().includes(`sep`)||e.name?.toLowerCase().includes(`sept`))&&!e.name?.toLowerCase().includes(`nov`)),p=e=>e&&(e.id===o||(e.name?.toLowerCase().includes(`26`)||e.name?.toLowerCase().includes(`4ª`)||e.name?.toLowerCase().includes(`4a`))&&(e.name?.toLowerCase().includes(`sep`)||e.name?.toLowerCase().includes(`sept`))&&!e.name?.toLowerCase().includes(`nov`)),m=e.find(a),h=e.find(d),g=e.find(f),_=e.find(p);if(m&&(n=m.id),h&&(r=h.id),g&&(i=g.id),_){o=_.id;let{count:e}=await J.from(`scores`).select(`id`,{count:`exact`,head:!0}).eq(`eventid`,_.id);e&&e>0&&(l=!0)}new Date<=new Date(2026,8,20,23,59,59)&&t?(u=t.id,t.name):l&&_?(u=_.id,_.name):g&&(u=g.id,g.name)}}catch(e){console.warn(`Could not fetch tournaments:`,e)}let d=e=>{if(e.galeria&&Array.isArray(e.galeria)&&e.galeria.length>0)return e.galeria.filter(Boolean);if(typeof e.galeria==`string`&&e.galeria.trim())try{let t=JSON.parse(e.galeria);if(Array.isArray(t)&&t.length>0)return t.filter(Boolean)}catch{}if(e.imagen_url&&e.imagen_url.trim()){if(e.imagen_url.startsWith(`[`))try{let t=JSON.parse(e.imagen_url);if(Array.isArray(t)&&t.length>0)return t.filter(Boolean)}catch{}return[e.imagen_url]}return[`./imagenes/feria.jpeg`]},f=e=>e?String(e).replace(/\\/g,`\\\\`).replace(/'/g,`\\'`).replace(/"/g,`&quot;`).replace(/\r?\n/g,` `):``,p=[],m=[];try{let{data:e}=await J.from(`noticias`).select(`*`).eq(`activo`,!0).order(`fecha_publicacion`,{ascending:!1}).order(`created_at`,{ascending:!1});e&&e.length>0&&(m=e.filter(e=>e.subtitulo?.toUpperCase()===`EVENTO`||e.subtitulo?.toUpperCase().includes(`EVENTO`)),p=e.filter(e=>e.subtitulo?.toUpperCase()!==`EVENTO`&&!e.subtitulo?.toUpperCase().includes(`EVENTO`)))}catch(e){console.warn(`Could not fetch active noticias/eventos:`,e)}let h=p.slice(0,9),g=e=>{let t=(e.titulo||``).toLowerCase(),n=(e.contenido||e.descripcion||``).toLowerCase(),r=(e.autor||e.fecha||``).toLowerCase();if(t.includes(`mecate`)||n.includes(`mecate`)||r.includes(`19`))return s;if((t.includes(`3ª`)||t.includes(`3a`)||t.includes(`tercera`))&&(t.includes(`ranking`)||t.includes(`stroke`)))return i;if((t.includes(`4ª`)||t.includes(`4a`)||t.includes(`cuarta`)||t.includes(`final`))&&(t.includes(`ranking`)||t.includes(`stroke`)))return o;if(t.includes(`anual`)||t.includes(`feria`)||r.includes(`noviembre`)){let e=c.find(e=>e.name?.toLowerCase().includes(`anual`));if(e)return e.id}if(t.includes(`ramos`)||r.includes(`octubre`)){let e=c.find(e=>e.name?.toLowerCase().includes(`ramos`));if(e)return e.id}if(t.includes(`pavo`)||r.includes(`diciembre`)){let e=c.find(e=>e.name?.toLowerCase().includes(`pavo`));if(e)return e.id}return null},_=m.length>0?m.map(e=>({id:e.id,imagen:e.imagen_url||e.galeria&&e.galeria[0]||`./imagenes/feria.jpeg`,titulo:e.titulo,descripcion:e.contenido,fecha:e.autor&&e.autor!==`Administrador`&&e.autor!==`Club de Golf Colima`?e.autor:e.fecha_publicacion?new Date(e.fecha_publicacion+`T00:00:00`).toLocaleDateString(`es-MX`,{day:`numeric`,month:`short`,year:`numeric`}):`Próximamente`,tournamentId:g(e)})):[{id:`default-1`,imagen:`./imagenes/feria.jpeg`,titulo:`Torneo Anual de Golf Feria de Todos Los Santos`,descripcion:`Vuelve el gran festejo del golf en el estado. Prepárate para vivirlo como nunca. Premios sin igual. Tradición, Pasión, Amistad.`,fecha:`5 al 8 de Noviembre`},{id:`default-2`,imagen:`./imagenes/3era.jpeg`,titulo:`I Ranking Stroke Play Interclubes 2026 - 3ª Fecha`,descripcion:`¡Arrancamos en grande la 3ª Fecha! Cuatro fechas, dos tarjetas, un campeón. Elige al menos 2 de las 4 mejores rondas para competir por el campeonato de tu categoría.`,fecha:`5 de Septiembre 2026`}],v=[];for(let e=0;e<_.length;e+=4)v.push(_.slice(e,e+4));`${window.location.origin}${u}`,e.innerHTML=`
        <style>
            @keyframes rankingGradientShift {
                0% { background-position: 0% 50%; }
                50% { background-position: 100% 50%; }
                100% { background-position: 0% 50%; }
            }
            @keyframes rankingPulseGlow {
                0%, 100% { box-shadow: 0 0 20px rgba(245, 158, 11, 0.45), 0 0 35px rgba(16, 185, 129, 0.25); }
                50% { box-shadow: 0 0 32px rgba(16, 185, 129, 0.65), 0 0 55px rgba(6, 182, 212, 0.4); }
            }
            .animated-ranking-badge {
                background: linear-gradient(135deg, rgba(2, 6, 23, 0.95), rgba(15, 23, 42, 0.95)) padding-box,
                            linear-gradient(90deg, #f59e0b, #10b981, #06b6d4, #a855f7, #f59e0b) border-box;
                border: 2px solid transparent;
                background-size: 100% 100%, 300% 300%;
                animation: rankingGradientShift 3.5s ease infinite, rankingPulseGlow 2.5s ease-in-out infinite;
            }
        </style>
        <div class="min-h-screen bg-slate-950 text-slate-100 font-display selection:bg-primary selection:text-slate-950">
            <!-- 1. TOP NAVBAR (DESKTOP & MOBILE RESPONSIVE) -->
            <nav class="sticky top-0 z-50 bg-slate-950/85 backdrop-blur-xl border-b border-slate-800/80 px-4 sm:px-8 py-3.5 transition-all">
                <div class="max-w-7xl mx-auto flex items-center justify-between gap-3 sm:gap-4">
                    <!-- Brand Logo -->
                    <div class="flex items-center gap-2.5 sm:gap-3 cursor-pointer" onclick="window.scrollTo({top:0, behavior:'smooth'})">
                        <div class="p-1 sm:p-1.5 bg-white/5 border border-white/10 rounded-2xl shadow-xl backdrop-blur-md shrink-0">
                            <img src="./golcolima.jpg" alt="Club Colima" class="h-9 sm:h-11 w-auto object-contain rounded-xl">
                        </div>
                        <div>
                            <span class="font-black text-white text-sm sm:text-lg tracking-tight uppercase block leading-none">Club de Golf Colima</span>
                            <span class="text-[9px] sm:text-[10px] font-bold text-primary tracking-[0.18em] sm:tracking-[0.25em] uppercase mt-1 block">La Cuna del Golf en Colima</span>
                        </div>
                    </div>

                    <!-- Nav Links Desktop -->
                    <div class="hidden lg:flex items-center gap-7 text-xs font-bold uppercase tracking-wider text-slate-300">
                        <a href="#inicio" class="hover:text-primary transition-colors">Inicio</a>
                        <a href="#eventos" class="hover:text-primary transition-colors">Eventos</a>
                        <a href="#noticias" class="hover:text-primary transition-colors">Noticias</a>
                        
                        <!-- Dropdown El Campo -->
                        <div class="relative group py-2">
                            <button class="flex items-center gap-1 hover:text-primary transition-colors cursor-pointer font-bold uppercase text-xs tracking-wider text-slate-300 group-hover:text-primary">
                                El Campo <span class="material-icons text-sm transition-transform duration-200 group-hover:rotate-180">expand_more</span>
                            </button>
                            <div class="absolute top-full left-0 hidden group-hover:flex flex-col bg-slate-900/95 border border-slate-800 backdrop-blur-xl rounded-2xl p-2 shadow-2xl min-w-[240px] z-50 animate-fade-in space-y-1">
                                <a href="#campo" class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-all">
                                    <span class="material-icons text-emerald-400 text-base">golf_course</span> Recorrido & Hoyos
                                </a>
                                <button onclick="openPublicHandicapModal()" class="flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-bold text-amber-300 hover:text-white hover:bg-amber-500/20 transition-all text-left w-full cursor-pointer">
                                    <span class="material-icons text-amber-400 text-base">analytics</span> HDCP Jugadores (WHS)
                                </button>
                            </div>
                        </div>

                        <a href="#servicios" class="hover:text-primary transition-colors">Servicios</a>
                        <a href="#contacto" class="hover:text-primary transition-colors">Contacto</a>
                    </div>

                    <!-- Quick Action Buttons + Mobile Hamburger Button -->
                    <div class="flex items-center gap-2 sm:gap-3">
                        <button onclick="openPublicHandicapModal()" class="hidden md:flex items-center gap-1.5 px-3.5 py-2 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 rounded-2xl text-xs font-black uppercase tracking-wider transition-all shadow-lg shadow-amber-500/10 cursor-pointer">
                            <span class="material-icons" style="font-size:16px">analytics</span> HDCP
                        </button>
                        <button onclick="openLiveLeaderboardModal('${u}')" class="hidden sm:flex items-center gap-2 px-4 py-2.5 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/40 text-emerald-400 rounded-2xl text-xs font-black uppercase tracking-wider transition-all shadow-lg shadow-emerald-500/10 cursor-pointer">
                            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                            <span class="material-icons" style="font-size:16px">open_in_new</span> Visor Live
                        </button>
                        <button onclick="window.location.hash = '#admin'; if (window.renderLogin) window.renderLogin();"
                            class="hidden sm:flex px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-black rounded-2xl text-xs uppercase tracking-wider border border-slate-700 transition-all items-center gap-1.5 cursor-pointer">
                            <span class="material-icons" style="font-size:16px">lock</span> Portal
                        </button>

                        <!-- Botón Hamburguesa Móvil (Celulares) -->
                        <button id="btn-toggle-mobile-menu" onclick="toggleMobileMenu()" class="lg:hidden p-2.5 rounded-2xl bg-slate-900 border border-slate-750 text-white hover:bg-slate-800 flex items-center justify-center cursor-pointer transition-all shadow-lg focus:outline-none" aria-label="Abrir menú">
                            <span class="material-icons text-xl" id="icon-mobile-toggle">menu</span>
                        </button>
                    </div>
                </div>

                <!-- Menú Desplegable Móvil (Celulares & Tablets) -->
                <div id="mobile-menu-drawer" class="lg:hidden hidden overflow-hidden transition-all duration-300 max-h-0 opacity-0">
                    <div class="pt-4 pb-2 border-t border-slate-800/80 mt-3 space-y-2">
                        <div class="grid grid-cols-2 gap-2">
                            <a href="#inicio" onclick="toggleMobileMenu()" class="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-900/70 border border-slate-800 text-slate-200 hover:text-white hover:bg-slate-800 hover:border-emerald-500/40 text-xs font-bold uppercase tracking-wider transition-all">
                                <span class="material-icons text-emerald-400 text-base">home</span> Inicio
                            </a>
                            <a href="#eventos" onclick="toggleMobileMenu()" class="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-900/70 border border-slate-800 text-slate-200 hover:text-white hover:bg-slate-800 hover:border-emerald-500/40 text-xs font-bold uppercase tracking-wider transition-all">
                                <span class="material-icons text-emerald-400 text-base">event</span> Eventos
                            </a>
                            <a href="#noticias" onclick="toggleMobileMenu()" class="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-900/70 border border-slate-800 text-slate-200 hover:text-white hover:bg-slate-800 hover:border-emerald-500/40 text-xs font-bold uppercase tracking-wider transition-all">
                                <span class="material-icons text-amber-400 text-base">feed</span> Noticias
                            </a>
                            <a href="#campo" onclick="toggleMobileMenu()" class="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-900/70 border border-slate-800 text-slate-200 hover:text-white hover:bg-slate-800 hover:border-emerald-500/40 text-xs font-bold uppercase tracking-wider transition-all">
                                <span class="material-icons text-emerald-400 text-base">golf_course</span> El Campo
                            </a>
                            <button onclick="toggleMobileMenu(); openPublicHandicapModal();" class="flex items-center gap-2.5 p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-amber-300 hover:text-white hover:bg-amber-500/25 text-xs font-black uppercase tracking-wider transition-all col-span-2 text-left cursor-pointer shadow-lg shadow-amber-500/10">
                                <span class="material-icons text-amber-400 text-lg">analytics</span> 🎯 Consultar HDCP Jugadores (WHS)
                            </button>
                            <a href="#servicios" onclick="toggleMobileMenu()" class="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-900/70 border border-slate-800 text-slate-200 hover:text-white hover:bg-slate-800 hover:border-emerald-500/40 text-xs font-bold uppercase tracking-wider transition-all">
                                <span class="material-icons text-emerald-400 text-base">room_service</span> Servicios
                            </a>
                            <a href="#contacto" onclick="toggleMobileMenu()" class="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-900/70 border border-slate-800 text-slate-200 hover:text-white hover:bg-slate-800 hover:border-emerald-500/40 text-xs font-bold uppercase tracking-wider transition-all">
                                <span class="material-icons text-emerald-400 text-base">contact_mail</span> Contacto
                            </a>
                        </div>

                        <!-- Botones de Acción en Móvil -->
                        <div class="pt-2 grid grid-cols-2 gap-2">
                            <button onclick="toggleMobileMenu(); openLiveLeaderboardModal('${u}');" class="flex items-center justify-center gap-2 p-3 bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 rounded-2xl text-xs font-black uppercase tracking-wider cursor-pointer">
                                <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span> Visor Live
                            </button>
                            <button onclick="toggleMobileMenu(); window.location.hash = '#admin'; if (window.renderLogin) window.renderLogin();" class="flex items-center justify-center gap-2 p-3 bg-slate-800 border border-slate-700 text-white rounded-2xl text-xs font-black uppercase tracking-wider cursor-pointer">
                                <span class="material-icons text-sm">lock</span> Portal
                            </button>
                        </div>
                    </div>
                </div>
            </nav>

            <!-- 2. HERO SECTION -->
            <section id="inicio" class="relative min-h-[90vh] flex items-center justify-center overflow-hidden pt-8 pb-16 px-4">
                <!-- Background Drone Photo Carousel -->
                <div id="hero-slider" class="absolute inset-0 z-0">
                    ${t.map((e,t)=>`
                        <div class="hero-slide absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ease-in-out ${t===0?`opacity-100 scale-105`:`opacity-0 scale-100`}"
                            style="background-image: url('${e}'); filter: brightness(0.60) contrast(1.10);"></div>
                    `).join(``)}
                    <!-- Dark Gradient Overlay -->
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-slate-950/60"></div>
                </div>

                <div class="relative z-10 max-w-5xl mx-auto text-center space-y-6 mt-2 animate-fade-in">
                    <!-- Banner Flotante Ranking Acumulado (Animación de colores cambiantes, degradado brillante & pulso) -->
                    <div class="flex justify-center">
                        <button onclick="openRankingAcumuladoModal()" 
                            class="animated-ranking-badge group relative inline-flex items-center gap-2 sm:gap-3 px-5 sm:px-7 py-2.5 sm:py-3 rounded-full text-xs font-black uppercase tracking-widest text-white shadow-2xl transition-all hover:scale-105 active:scale-95 cursor-pointer">
                            <span class="flex h-2.5 w-2.5 relative shrink-0">
                                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                                <span class="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-400"></span>
                            </span>
                            <span class="bg-gradient-to-r from-amber-300 via-emerald-300 to-cyan-300 bg-clip-text text-transparent font-black tracking-wider text-[11px] sm:text-xs">
                                🏆 CONSULTAR RANKING ACUMULADO · RUMBO A LA GRAN FINAL
                            </span>
                            <span class="material-icons text-amber-300 text-sm group-hover:translate-x-1.5 transition-transform">
                                arrow_forward
                            </span>
                        </button>
                    </div>

                    <!-- LOGO EN GRANDE DEL CLUB DE GOLF COLIMA -->
                    <div class="flex justify-center my-2">
                        <div class="p-4 bg-slate-950/70 border border-white/20 rounded-3xl shadow-2xl backdrop-blur-xl hover:scale-105 transition-transform">
                            <img src="./golcolima.jpg" alt="Club de Golf Colima" class="h-28 sm:h-36 w-auto object-contain rounded-2xl shadow-2xl">
                        </div>
                    </div>

                    <!-- Glassmorphism Badge Specs -->
                    <div class="inline-flex items-center gap-2 px-5 py-2 bg-slate-900/80 border border-slate-700/80 rounded-full backdrop-blur-xl shadow-2xl">
                        <span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                        <span class="text-xs font-black text-white uppercase tracking-widest">18 Hoyos · Par 68 · 5,660 Yardas</span>
                    </div>

                    <!-- Main Heading -->
                    <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black text-white uppercase tracking-tight leading-[1.08]">
                        LA CUNA DEL GOLF <br>
                        <span class="bg-gradient-to-r from-emerald-400 via-primary to-amber-300 bg-clip-text text-transparent">EN COLIMA</span>
                    </h1>

                    <p class="text-sm sm:text-base text-slate-300 max-w-3xl mx-auto font-medium leading-relaxed">
                        Disfruta de un campo desafiante rodeado de naturaleza tropical, instalaciones de primera clase y la comunidad golfista más vibrante del estado.
                    </p>

                    <!-- Hero Call to Action Buttons -->
                    <div class="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
                        <button onclick="openLiveLeaderboardModal('${u}')"
                            class="w-full sm:w-auto px-8 py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-2xl text-xs sm:text-sm uppercase tracking-wider shadow-2xl shadow-emerald-500/30 transition-all transform hover:-translate-y-1 flex items-center justify-center gap-3 cursor-pointer">
                            <span class="material-icons">emoji_events</span> Leaderboard en Vivo (Visor Live)
                        </button>
                        <button onclick="openTeeTimeModal()"
                            class="w-full sm:w-auto px-8 py-4 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-white font-black rounded-2xl text-xs sm:text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-2 backdrop-blur-md hover:border-emerald-500/50 shadow-xl cursor-pointer hover:-translate-y-1">
                            <span class="material-icons text-primary">golf_course</span> Reservar Tee Time
                        </button>
                    </div>

                    <!-- Quick Stats Cards -->
                    <div class="space-y-4 pt-6 max-w-4xl mx-auto">
                        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                            <div class="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl backdrop-blur-md text-center space-y-1 shadow-xl">
                                <p class="text-3xl font-black text-amber-400">18</p>
                                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Hoyos de Competición</p>
                            </div>
                            <div class="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl backdrop-blur-md text-center space-y-1 shadow-xl">
                                <p class="text-3xl font-black text-emerald-400">68</p>
                                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Par de Campo</p>
                            </div>
                            <div class="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl backdrop-blur-md text-center space-y-1 shadow-xl">
                                <p class="text-3xl font-black text-blue-400">5,660</p>
                                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Yardas Recorrido</p>
                            </div>
                            <div class="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl backdrop-blur-md text-center space-y-1 shadow-xl">
                                <p class="text-3xl font-black text-rose-400">WHS</p>
                                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Handicaps Oficiales</p>
                            </div>
                        </div>

                        <!-- LOGO DE LA ASOCIACIÓN EN LOS BOTONES INFERIORES -->
                        <div class="flex items-center justify-center gap-3 pt-2">
                            <div class="px-5 py-2.5 bg-slate-900/90 border border-slate-700/80 rounded-2xl backdrop-blur-xl flex items-center gap-3 shadow-2xl hover:border-slate-600 transition-all">
                                <img src="./logoclub.png" alt="Asociación de Golf" class="h-8 w-auto object-contain rounded-lg">
                                <span class="text-[11px] font-black text-slate-300 uppercase tracking-wider">Afiliado a la Asociación Mexicana de Golf & WHS</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- 3. SECCIÓN ESPECIAL DESTACADA: TORNEO EN PUERTA & VISOR LIVE -->
            <section id="torneo-destacado" class="py-16 px-4 sm:px-8 max-w-7xl mx-auto">
                ${(()=>{let e=new Date<=new Date(2026,8,20,23,59,59),t=(m||[]).find(e=>(e.titulo||``).toLowerCase().includes(`mecate`)||(e.contenido||``).toLowerCase().includes(`mecate`)),a=t&&(t.imagen_url||t.galeria&&t.galeria[0])||`https://colimagolf.com/uploads/noticia_20260914_222955_ca6634b3.webp`;return e?`
                        <div class="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border-2 border-emerald-500/40 rounded-[3rem] p-6 sm:p-12 shadow-2xl space-y-10">
                            <!-- Glow decoration -->
                            <div class="absolute -top-24 -right-24 w-96 h-96 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none"></div>
                            <div class="absolute -bottom-24 -left-24 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>

                            <!-- Badge Header -->
                            <div class="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-6 relative z-10">
                                <div class="flex items-center gap-3">
                                    <span class="flex h-3 w-3 relative">
                                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                                        <span class="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                                    </span>
                                    <span class="px-4 py-1.5 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 font-black text-xs uppercase tracking-widest rounded-full">
                                        Torneo en Puerta · Sábado 19 de Septiembre 2026
                                    </span>
                                </div>
                                <span class="text-xs font-black text-slate-400 uppercase tracking-widest">Sede Oficial: Club de Golf Colima</span>
                            </div>

                            <!-- Grid Poster + Details -->
                            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center relative z-10">
                                <!-- Left Poster Image: Flyer Oficial Torneo del Mecate -->
                                <div class="lg:col-span-5 flex justify-center">
                                    <div class="relative group max-w-sm sm:max-w-md w-full rounded-3xl overflow-hidden border-2 border-emerald-500/40 shadow-2xl hover:border-emerald-400 transition-all duration-300 cursor-pointer" onclick="openLiveLeaderboardModal('${s}')">
                                        <img src="${a}" alt="Torneo del Mecate - 19 de Septiembre 2026" class="w-full h-auto object-cover rounded-3xl transition-transform duration-500 group-hover:scale-105" onerror="this.src='./golcolima.jpg'">
                                        <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-6 flex flex-col justify-end">
                                            <span class="text-xs font-black text-emerald-400 uppercase tracking-widest flex items-center gap-1.5">
                                                <span class="material-icons text-sm">visibility</span> Ver Leaderboard y Salidas
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <!-- Right Info & Actions -->
                                <div class="lg:col-span-7 space-y-6 text-left">
                                    <div class="space-y-2">
                                        <span class="px-3.5 py-1 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-black uppercase tracking-widest rounded-full inline-block">
                                            ¡Hoy en Competencia!
                                        </span>
                                        <h2 class="text-3xl sm:text-5xl font-black text-white uppercase tracking-tight leading-tight">
                                            TORNEO DEL MECATE
                                        </h2>
                                        <p class="text-sm sm:text-base font-black text-amber-400 uppercase tracking-[0.2em]">
                                            Una Tradición que nos Une · Sábado 19 de Septiembre
                                        </p>
                                    </div>

                                    <p class="text-slate-300 text-xs sm:text-sm leading-relaxed">
                                        Formato Amateur Individual a 18 hoyos en una sola categoría al 80% del Handicap. ¡Contamos con 20 equipos confirmados en campo! Consulta la lista oficial de salidas por hoyo y el leaderboard en vivo hoyo por hoyo en tiempo real.
                                    </p>

                                    <!-- Quick Stats Grid -->
                                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                                        <div class="p-3.5 bg-slate-950/60 border border-slate-800 rounded-2xl text-center space-y-1">
                                            <p class="text-xs font-black text-emerald-400">8:00 AM</p>
                                            <p class="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Salida Shotgun</p>
                                        </div>
                                        <div class="p-3.5 bg-slate-950/60 border border-slate-800 rounded-2xl text-center space-y-1">
                                            <p class="text-xs font-black text-emerald-400">20 Equipos</p>
                                            <p class="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Confirmados</p>
                                        </div>
                                        <div class="p-3.5 bg-slate-950/60 border border-slate-800 rounded-2xl text-center space-y-1">
                                            <p class="text-xs font-black text-emerald-400">Individual</p>
                                            <p class="text-[9px] font-bold text-slate-400 uppercase tracking-wider">80% Handicap</p>
                                        </div>
                                        <div class="p-3.5 bg-slate-950/60 border border-slate-800 rounded-2xl text-center space-y-1">
                                            <p class="text-xs font-black text-amber-400">Comida</p>
                                            <p class="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Mexicana</p>
                                        </div>
                                    </div>

                                    <!-- Call to Action Buttons -->
                                    <div class="pt-4 flex flex-col sm:flex-row items-center gap-3">
                                        <button onclick="openLiveLeaderboardModal('${s}')"
                                            class="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-emerald-400 via-emerald-500 to-emerald-600 hover:from-emerald-300 hover:to-emerald-500 text-slate-950 font-black rounded-2xl text-xs sm:text-sm uppercase tracking-widest shadow-2xl shadow-emerald-500/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2.5 cursor-pointer">
                                            <span class="material-icons" style="font-size:20px">emoji_events</span>
                                            <span>VER LEADERBOARD Y SALIDAS EN VIVO</span>
                                        </button>
                                        <button onclick="openRankingAcumuladoModal()"
                                            class="w-full sm:w-auto px-6 py-4 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-amber-500/50 text-slate-200 font-bold rounded-2xl text-xs sm:text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl">
                                            <span class="material-icons text-amber-400" style="font-size:18px">leaderboard</span>
                                            <span>Ranking General Acumulado</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        `:`
                        <div class="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border-2 border-emerald-500/30 rounded-[3rem] p-6 sm:p-12 shadow-2xl space-y-10">
                            <!-- Glow decoration -->
                            <div class="absolute -top-24 -right-24 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
                            <div class="absolute -bottom-24 -left-24 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

                            <!-- Badge Header -->
                            <div class="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-6 relative z-10">
                                <div class="flex items-center gap-3">
                                    <span class="flex h-3 w-3 relative">
                                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                                        <span class="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                                    </span>
                                    <span class="px-4 py-1.5 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 font-black text-xs uppercase tracking-widest rounded-full">
                                        Gran Final · 26 de Septiembre 2026
                                    </span>
                                </div>
                                <span class="text-xs font-black text-slate-400 uppercase tracking-widest">Sede Oficial: Club de Golf Colima</span>
                            </div>

                            <!-- Grid Poster + Details -->
                            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
                                <!-- Left Poster Image -->
                                <div class="lg:col-span-5 flex justify-center">
                                    <div class="relative group max-w-sm rounded-3xl overflow-hidden border-2 border-slate-700/80 shadow-2xl hover:border-emerald-500/50 transition-all duration-300">
                                        <img src="./imagenes/3era.jpeg" alt="I Ranking Stroke Play Interclubes 2026 - Gran Final" class="w-full h-auto object-cover rounded-3xl transition-transform duration-500 group-hover:scale-105" onerror="this.src='./golcolima.jpg'">
                                        <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-6 flex flex-col justify-end">
                                            <span class="text-xs font-black text-emerald-400 uppercase tracking-widest">Póster Oficial · Gran Final</span>
                                        </div>
                                    </div>
                                </div>

                                <!-- Right Info & Dates Timeline -->
                                <div class="lg:col-span-7 space-y-6 text-left">
                                    <div class="space-y-2">
                                        <h2 class="text-3xl sm:text-4xl lg:text-5xl font-black text-white uppercase tracking-tight leading-none">
                                            I RANKING STROKE PLAY <br>
                                            <span class="text-emerald-400">INTERCLUBES 2026</span>
                                        </h2>
                                        <p class="text-sm font-black text-amber-400 uppercase tracking-[0.25em] pt-1">
                                            Cuatro Fechas · Dos Tarjetas · Un Campeón
                                        </p>
                                    </div>

                                    <p class="text-slate-300 text-xs sm:text-sm leading-relaxed">
                                        ¡Llega la Gran Final de la 4ª fecha! Consulta la tabla general acumulada con las mejores 2 tarjetas netas de cada jugador y revisa los scores oficiales de cada jornada.
                                    </p>

                                    <!-- Timeline Dates Grid -->
                                    <div class="space-y-3">
                                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                                            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Fechas Oficiales del Ranking:</p>
                                            <span class="text-[9.5px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1">
                                                <span class="material-icons text-xs">touch_app</span> Toca una fecha para consultar resultados
                                            </span>
                                        </div>
                                        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                                            <!-- 1ª FECHA (8 AGOSTO) -->
                                            <button type="button" id="ranking-btn-fecha-1" onclick="selectRankingTournament('${n}', '8 AGOSTO', false, 1)"
                                                class="ranking-date-card p-3.5 bg-amber-500/10 border-2 border-amber-500/50 hover:border-amber-400 hover:bg-amber-500/20 rounded-2xl text-center space-y-1 transition-all cursor-pointer group shadow-lg shadow-amber-500/10 active:scale-95">
                                                <span class="px-2 py-0.5 bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[8px] font-black uppercase tracking-wider rounded-full block mx-auto w-max mb-1">FINALIZADO</span>
                                                <p class="text-[9px] font-bold text-amber-400/90 uppercase">1ª FECHA</p>
                                                <p class="text-sm font-black text-white">8 AGOSTO</p>
                                                <span class="text-[8.5px] font-black text-amber-400 uppercase tracking-wider block mt-1">Ver Resultados ➔</span>
                                            </button>

                                            <!-- 2ª FECHA (22 AGOSTO) -->
                                            <button type="button" id="ranking-btn-fecha-2" onclick="selectRankingTournament('${r}', '22 AGOSTO', false, 2)"
                                                class="ranking-date-card p-3.5 bg-amber-500/10 border-2 border-amber-500/50 hover:border-amber-400 hover:bg-amber-500/20 rounded-2xl text-center space-y-1 transition-all cursor-pointer group shadow-lg shadow-amber-500/10 active:scale-95">
                                                <span class="px-2 py-0.5 bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[8px] font-black uppercase tracking-wider rounded-full block mx-auto w-max mb-1">FINALIZADO</span>
                                                <p class="text-[9px] font-bold text-amber-400/90 uppercase">2ª FECHA</p>
                                                <p class="text-sm font-black text-white">22 AGOSTO</p>
                                                <span class="text-[8.5px] font-black text-amber-400 uppercase tracking-wider block mt-1">Ver Resultados ➔</span>
                                            </button>

                                            <!-- 3ª FECHA (5 SEPT) -->
                                            <button type="button" id="ranking-btn-fecha-3" onclick="selectRankingTournament('${i}', '5 SEPT', false, 3)"
                                                class="ranking-date-card p-3.5 bg-amber-500/10 border-2 border-amber-500/50 hover:border-amber-400 hover:bg-amber-500/20 rounded-2xl text-center space-y-1 transition-all cursor-pointer group shadow-lg shadow-amber-500/10 active:scale-95">
                                                <span class="px-2 py-0.5 bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[8px] font-black uppercase tracking-wider rounded-full block mx-auto w-max mb-1">FINALIZADO</span>
                                                <p class="text-[9px] font-bold text-amber-400/90 uppercase">3ª FECHA</p>
                                                <p class="text-sm font-black text-white">5 SEPT</p>
                                                <span class="text-[8.5px] font-black text-amber-400 uppercase tracking-wider block mt-1">Ver Resultados ➔</span>
                                            </button>

                                            <!-- 4ª FECHA (26 SEPT) -->
                                            ${l?`
                                                <button type="button" id="ranking-btn-fecha-4" onclick="selectRankingTournament('${o}', '26 SEPT', true, 4)"
                                                    class="ranking-date-card p-3.5 bg-emerald-500/20 border-2 border-emerald-500 rounded-2xl text-center space-y-1 transition-all cursor-pointer group shadow-xl shadow-emerald-500/20 ring-2 ring-emerald-500/40 active:scale-95">
                                                    <span class="px-2 py-0.5 bg-emerald-500 text-slate-950 text-[8px] font-black uppercase tracking-wider rounded-full block mx-auto w-max mb-1 animate-pulse">EN VIVO</span>
                                                    <p class="text-[9px] font-bold text-emerald-400 uppercase">4ª FECHA</p>
                                                    <p class="text-sm font-black text-emerald-400">26 SEPT</p>
                                                    <span class="text-[8.5px] font-black text-emerald-300 uppercase tracking-wider block mt-1">En Competencia ➔</span>
                                                </button>
                                            `:`
                                                <button type="button" id="ranking-btn-fecha-4" onclick="${o?`selectRankingTournament('${o}', '26 SEPT', false, 4)`:`openRankingAcumuladoModal()`}"
                                                    class="ranking-date-card p-3.5 bg-slate-900/90 border border-amber-500/40 hover:border-amber-400 rounded-2xl text-center space-y-1 transition-all cursor-pointer group hover:bg-slate-800/80 active:scale-95">
                                                    <span class="px-2 py-0.5 bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[8px] font-black uppercase tracking-wider rounded-full block mx-auto w-max mb-1">GRAN FINAL</span>
                                                    <p class="text-[9px] font-bold text-slate-400 uppercase">4ª FECHA</p>
                                                    <p class="text-sm font-black text-white">26 SEPT</p>
                                                    <span class="text-[8.5px] font-bold text-amber-400/90 uppercase tracking-wider block mt-1">Por Iniciar</span>
                                                </button>
                                            `}
                                        </div>
                                    </div>

                                    <!-- Call to Action Buttons -->
                                    <div class="pt-4 flex flex-col sm:flex-row items-center gap-3">
                                        <button onclick="openRankingAcumuladoModal()"
                                            class="w-full sm:w-auto px-7 py-4 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 font-black rounded-2xl text-xs sm:text-sm uppercase tracking-widest shadow-2xl shadow-amber-500/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2.5 cursor-pointer">
                                            <span class="material-icons" style="font-size:20px">emoji_events</span>
                                            <span>VER RANKING GENERAL ACUMULADO</span>
                                        </button>
                                        <button id="ranking-main-cta-btn" onclick="openLiveLeaderboardModal('${i||u}')"
                                            class="w-full sm:w-auto px-6 py-4 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-amber-500/50 text-white font-bold rounded-2xl text-xs sm:text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl">
                                            <span id="ranking-cta-icon" class="material-icons text-amber-400" style="font-size:18px">history</span>
                                            <span id="ranking-cta-text">Resultados 3ª Fecha (5 Sept)</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        `})()}
            </section>

            <!-- 3.5 SECCIÓN EVENTOS -->
            <section id="eventos" class="py-20 px-4 sm:px-8 max-w-7xl mx-auto space-y-12">
                <div class="text-center space-y-3">
                    <span class="px-4 py-1 bg-purple-500/10 border border-purple-500/30 text-purple-400 font-black text-[10px] uppercase tracking-widest rounded-full">Calendario</span>
                    <h2 class="text-3xl sm:text-5xl font-black text-white uppercase tracking-tight">PRÓXIMOS EVENTOS</h2>
                    <p class="text-slate-400 text-sm max-w-2xl mx-auto font-medium">No te pierdas los mejores torneos y celebraciones en el Club de Golf Colima.</p>
                </div>
                
                <!-- Eventos Container (2 cols x 2 rows = 4 por vista, deslizable si hay más de 4) -->
                <div class="relative max-w-4xl mx-auto">
                    ${v.length>1?`
                        <!-- Carousel Nav Controls -->
                        <div class="flex items-center justify-between mb-4 px-2">
                            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider" id="eventos-page-indicator">
                                Mostrando 1 de ${v.length}
                            </span>
                            <div class="flex items-center gap-2">
                                <button type="button" onclick="navigateEventos(-1)" id="btn-eventos-prev" class="w-10 h-10 rounded-2xl bg-slate-900 border border-slate-700/80 hover:border-purple-500 text-white flex items-center justify-center transition-all cursor-pointer shadow-lg active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed">
                                    <span class="material-icons text-sm">chevron_left</span>
                                </button>
                                <button type="button" onclick="navigateEventos(1)" id="btn-eventos-next" class="w-10 h-10 rounded-2xl bg-slate-900 border border-slate-700/80 hover:border-purple-500 text-white flex items-center justify-center transition-all cursor-pointer shadow-lg active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed">
                                    <span class="material-icons text-sm">chevron_right</span>
                                </button>
                            </div>
                        </div>
                    `:``}

                    <div id="eventos-slider-container" class="relative overflow-hidden w-full">
                        <div id="eventos-slides-track" class="flex transition-transform duration-500 ease-out" style="transform: translateX(0%);">
                            ${v.map(e=>`
                                <div class="w-full flex-shrink-0 grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8">
                                    ${e.map(e=>`
                                        <div class="group relative rounded-3xl overflow-hidden border border-slate-800 bg-slate-900 shadow-xl cursor-pointer hover:border-emerald-500/50 transition-all aspect-[4/5] sm:aspect-[3/4]"
                                            onclick="openEventModal('${f(e.imagen)}', '${f(e.titulo)}', '${f(e.descripcion)}', '${f(e.fecha)}', '${f(e.tournamentId)}')">
                                            <img src="${e.imagen}" alt="${e.titulo}" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" onerror="this.src='./golcolima.jpg'">
                                            <div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-6 flex flex-col justify-end items-center text-center">
                                                <span class="px-3 py-1 bg-purple-500/30 border border-purple-400/40 text-purple-300 rounded-full text-[9px] font-black uppercase tracking-wider mb-2 backdrop-blur-md shadow-lg">
                                                    ${e.fecha}
                                                </span>
                                                <h4 class="text-base sm:text-lg font-black text-white uppercase tracking-tight line-clamp-2 mb-3">
                                                    ${e.titulo}
                                                </h4>
                                                <div class="w-14 h-14 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center mb-3 shadow-2xl transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                                                    <span class="material-icons">zoom_in</span>
                                                </div>
                                                <span class="text-xs font-black text-white uppercase tracking-widest">Ver Detalles</span>
                                            </div>
                                        </div>
                                    `).join(``)}
                                </div>
                            `).join(``)}
                        </div>
                    </div>

                    ${v.length>1?`
                        <!-- Dots pagination -->
                        <div class="flex items-center justify-center gap-2 mt-6">
                            ${v.map((e,t)=>`
                                <button type="button" onclick="goToEventPage(${t})" class="evento-dot w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${t===0?`bg-purple-500 w-8`:`bg-slate-700 hover:bg-slate-500`}" data-page="${t}">
                                </button>
                            `).join(``)}
                        </div>
                    `:``}
                </div>
            </section>

            <!-- 3.6 SECCIÓN NOTICIAS (EXACTAMENTE ABAJO DE EVENTOS Y ARRIBA DEL CAMPO) -->
            <section id="noticias" class="py-20 px-4 sm:px-8 max-w-7xl mx-auto space-y-10">
                <div class="text-center">
                    <h2 class="text-3xl sm:text-5xl font-black text-white uppercase tracking-tight">NOTICIAS</h2>
                </div>

                <!-- Grid de 3 Columnas (Hasta 9 noticias en vista principal) -->
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    ${p.length===0?`
                        <div class="col-span-full py-12 px-6 bg-slate-900/60 border border-slate-800 rounded-3xl text-center space-y-3 max-w-2xl mx-auto">
                            <div class="w-14 h-14 bg-amber-500/10 text-amber-400 rounded-2xl flex items-center justify-center mx-auto">
                                <span class="material-icons text-2xl">feed</span>
                            </div>
                            <h4 class="text-lg font-black text-white uppercase">Próximamente más notas y artículos</h4>
                            <p class="text-xs text-slate-400 leading-relaxed">
                                Estamos preparando nuevas noticias y coberturas especiales de nuestros torneos para compartirlas con toda la comunidad golfista.
                            </p>
                        </div>
                    `:h.map(e=>{let t=d(e),n=t[0]||`./imagenes/feria.jpeg`;return`
                            <div class="group relative rounded-3xl overflow-hidden border border-slate-800 hover:border-amber-500/60 aspect-[4/3] bg-slate-900 shadow-2xl cursor-pointer transition-all duration-300 transform hover:-translate-y-1.5" onclick="openNoticiaModal('${e.id}')">
                                <img src="${n}" alt="${e.titulo}" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" onerror="this.src='./golcolima.jpg'" loading="lazy">
                                <div class="absolute inset-0 bg-gradient-to-t from-slate-950/95 via-slate-950/30 to-transparent p-6 flex flex-col justify-end">
                                    ${t.length>1?`
                                        <div class="absolute top-4 right-4">
                                            <span class="px-2.5 py-1 bg-slate-950/85 border border-slate-700/80 text-amber-300 rounded-xl text-[9px] font-black uppercase flex items-center gap-1 backdrop-blur-md shadow-lg">
                                                <span class="material-icons" style="font-size:12px">collections</span> ${t.length} fotos
                                            </span>
                                        </div>
                                    `:``}
                                    
                                    <h4 class="text-base sm:text-lg font-black text-white uppercase tracking-tight leading-snug group-hover:text-amber-400 transition-colors line-clamp-2">
                                        ${e.titulo}
                                    </h4>
                                </div>
                            </div>
                        `}).join(``)}
                </div>

                <!-- Botón Ver Todas las Noticias si hay más de 9 -->
                ${p.length>9?`
                    <div class="flex justify-center pt-4">
                        <button onclick="openAllNoticiasModal()" class="inline-flex items-center gap-2.5 px-8 py-4 bg-slate-900/90 hover:bg-amber-500 hover:text-slate-950 text-white font-black rounded-2xl text-xs uppercase tracking-widest border border-slate-800 hover:border-amber-400 transition-all shadow-2xl hover:scale-[1.02] active:scale-95 cursor-pointer">
                            <span class="material-icons text-base">grid_view</span>
                            <span>Ver Todas las Noticias (${p.length})</span>
                        </button>
                    </div>
                `:``}
            </section>

            <!-- 4. SECCIÓN EL CAMPO (DRONE GALLERY & CARD SPECS) -->
            <section id="campo" class="py-20 px-4 sm:px-8 max-w-7xl mx-auto space-y-12">
                <div class="text-center space-y-3">
                    <span class="px-4 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-400 font-black text-[10px] uppercase tracking-widest rounded-full">Recorrido Aéreo HD</span>
                    <h2 class="text-3xl sm:text-5xl font-black text-white uppercase tracking-tight">NUESTRO CAMPO DE GOLF</h2>
                    <p class="text-slate-400 text-sm max-w-2xl mx-auto font-medium">
                        Diseñado para ofrecer una experiencia única de tiro con fairways amplios, trampas estratégicas y greens perfectamente cuidados.
                    </p>
                </div>

                <!-- Specs per Tee Grid -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="p-6 bg-slate-900 border border-slate-800 rounded-3xl space-y-3 relative overflow-hidden group hover:border-slate-700 transition-all">
                        <div class="w-12 h-12 rounded-2xl bg-slate-200 text-slate-950 font-black flex items-center justify-center text-xl shadow-lg">B</div>
                        <h3 class="font-black text-white text-lg uppercase">Tee Blanco (White)</h3>
                        <p class="text-xs text-slate-400 font-bold uppercase">Distancia: <span class="text-white">5,660 Yds</span> · Rating: <span class="text-amber-400">66.5</span> · Slope: <span class="text-amber-400">125</span></p>
                        <p class="text-xs text-slate-500 leading-relaxed">Marca de salida principal para caballeros. Exige precisión en las salidas y buen control de distancia.</p>
                    </div>

                    <div class="p-6 bg-slate-900 border border-slate-800 rounded-3xl space-y-3 relative overflow-hidden group hover:border-slate-700 transition-all">
                        <div class="w-12 h-12 rounded-2xl bg-amber-400 text-slate-950 font-black flex items-center justify-center text-xl shadow-lg">D</div>
                        <h3 class="font-black text-white text-lg uppercase">Tee Dorado (Gold)</h3>
                        <p class="text-xs text-slate-400 font-bold uppercase">Distancia: <span class="text-white">5,158 Yds</span> · Rating: <span class="text-amber-400">65.7</span> · Slope: <span class="text-amber-400">122</span></p>
                        <p class="text-xs text-slate-500 leading-relaxed">Ideal para jugadores sénior e intermedios buscando equilibrio entre reto y distancia justa.</p>
                    </div>

                    <div class="p-6 bg-slate-900 border border-slate-800 rounded-3xl space-y-3 relative overflow-hidden group hover:border-slate-700 transition-all">
                        <div class="w-12 h-12 rounded-2xl bg-rose-600 text-white font-black flex items-center justify-center text-xl shadow-lg">P</div>
                        <h3 class="font-black text-white text-lg uppercase">Tee Plateada (Silver)</h3>
                        <p class="text-xs text-slate-400 font-bold uppercase">Distancia: <span class="text-white">4,768 Yds</span> · Rating: <span class="text-rose-400">65.5</span> · Slope: <span class="text-rose-400">121</span></p>
                        <p class="text-xs text-slate-500 leading-relaxed">Marca de salida para damas y juveniles. Excelente configuración para estrategia y colocación.</p>
                    </div>
                </div>

                <!-- Drone Photography Masonry / Grid -->
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
                    ${t.slice(0,6).map((e,t)=>`
                        <div class="group relative rounded-3xl overflow-hidden border border-slate-800 aspect-[4/3] bg-slate-900 shadow-xl">
                            <img src="${e}" alt="Club de Golf Colima Dron" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy">
                            <div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-6 flex flex-col justify-end">
                                <span class="text-xs font-black text-primary uppercase tracking-widest">Vista Aérea HD</span>
                                <h4 class="text-lg font-black text-white uppercase">Campo de Golf Colima</h4>
                            </div>
                        </div>
                    `).join(``)}
                </div>
            </section>

            <!-- 5. SECCIÓN SERVICIOS E INSTALACIONES -->
            <section id="servicios" class="py-20 bg-slate-900/60 border-y border-slate-800 px-4 sm:px-8">
                <div class="max-w-7xl mx-auto space-y-12">
                    <div class="text-center space-y-3">
                        <span class="px-4 py-1 bg-primary/10 border border-primary/30 text-primary font-black text-[10px] uppercase tracking-widest rounded-full">Experiencia Integral</span>
                        <h2 class="text-3xl sm:text-5xl font-black text-white uppercase tracking-tight">SERVICIOS & INSTALACIONES</h2>
                        <p class="text-slate-400 text-sm max-w-2xl mx-auto font-medium"> Todo lo necesario para que tu jornada de golf sea perfecta de principio a fin.</p>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                        <div class="p-8 bg-slate-950 border border-slate-800 rounded-3xl space-y-4 hover:border-emerald-500/50 transition-all group">
                            <div class="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                                <span class="material-icons" style="font-size:28px">golf_course</span>
                            </div>
                            <h3 class="font-black text-white text-xl uppercase">Caddie Master & Starter</h3>
                            <p class="text-xs text-slate-400 leading-relaxed font-medium">Control de salidas express, asignación de caddies experimentados y seguimiento de tiempos de juego en el campo.</p>
                        </div>

                        <div class="p-8 bg-slate-950 border border-slate-800 rounded-3xl space-y-4 hover:border-amber-500/50 transition-all group">
                            <div class="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                                <span class="material-icons" style="font-size:28px">emoji_events</span>
                            </div>
                            <h3 class="font-black text-white text-xl uppercase">Torneos & Competencias</h3>
                            <p class="text-xs text-slate-400 leading-relaxed font-medium">Organización de torneos semanales, eventos empresariales, competencia Oyeses y leaderboard en tiempo real.</p>
                        </div>

                        <div onclick="openPublicHandicapModal()" class="p-8 bg-slate-950 border border-slate-800 rounded-3xl space-y-4 hover:border-amber-500/60 transition-all group cursor-pointer hover:shadow-2xl hover:shadow-amber-500/10 relative overflow-hidden">
                            <div class="flex items-center justify-between">
                                <div class="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                                    <span class="material-icons" style="font-size:28px">analytics</span>
                                </div>
                                <span class="px-3 py-1 bg-amber-500/15 border border-amber-500/30 text-amber-300 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1 group-hover:bg-amber-500 group-hover:text-slate-950 transition-all">
                                    Consultar <span class="material-icons text-xs">arrow_forward</span>
                                </span>
                            </div>
                            <h3 class="font-black text-white text-xl uppercase">Handicaps WHS Jugadores</h3>
                            <p class="text-xs text-slate-400 leading-relaxed font-medium">Consulta el listado actualizado de Handicap Index oficial y el cálculo de golpes por Tee de salida para cada socio.</p>
                        </div>

                        <div class="p-8 bg-slate-950 border border-slate-800 rounded-3xl space-y-4 hover:border-purple-500/50 transition-all group">
                            <div class="w-14 h-14 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform">
                                <span class="material-icons" style="font-size:28px">sports_golf</span>
                            </div>
                            <h3 class="font-black text-white text-xl uppercase">Renta de Carritos & Equipo</h3>
                            <p class="text-xs text-slate-400 leading-relaxed font-medium">Flotilla de carritos de golf bien mantenidos y alquiler de bolsas de palos de alta calidad para invitados.</p>
                        </div>

                        <div class="p-8 bg-slate-950 border border-slate-800 rounded-3xl space-y-4 hover:border-rose-500/50 transition-all group">
                            <div class="w-14 h-14 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 group-hover:scale-110 transition-transform">
                                <span class="material-icons" style="font-size:28px">groups</span>
                            </div>
                            <h3 class="font-black text-white text-xl uppercase">Padrón & Cuotas de Socios</h3>
                            <p class="text-xs text-slate-400 leading-relaxed font-medium">Gestión transparente de membresías, estado de cuotas al corriente e historial de beneficios exclusivos.</p>
                        </div>

                        <div class="p-8 bg-slate-950 border border-slate-800 rounded-3xl space-y-4 hover:border-emerald-500/50 transition-all group">
                            <div class="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                                <span class="material-icons" style="font-size:28px">restaurant</span>
                            </div>
                            <h3 class="font-black text-white text-xl uppercase">Casa Club & Restobar</h3>
                            <p class="text-xs text-slate-400 leading-relaxed font-medium">Espacio de convivencia con servicio de alimentos, bebidas frías y vista panorámica a la llegada del hoyo 18.</p>
                        </div>
                    </div>
                </div>
            </section>

            <!-- 6. SECCIÓN INFORMACIÓN DE CONTACTO & UBICACIÓN -->
            <section id="contacto" class="py-20 px-4 sm:px-8 max-w-7xl mx-auto space-y-12">
                <div class="text-center space-y-3">
                    <span class="px-4 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-400 font-black text-[10px] uppercase tracking-widest rounded-full">Visítanos</span>
                    <h2 class="text-3xl sm:text-5xl font-black text-white uppercase tracking-tight">UBICACIÓN & CONTACTO</h2>
                    <p class="text-slate-400 text-sm max-w-2xl mx-auto font-medium">Estamos listos para recibirte en las mejores instalaciones de golf de la región.</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
                    <!-- Contact Cards -->
                    <div class="lg:col-span-5 space-y-4">
                        <div class="p-6 bg-slate-900 border border-slate-800 rounded-3xl flex items-center gap-5">
                            <div class="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                                <span class="material-icons">location_on</span>
                            </div>
                            <div>
                                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Dirección Oficial</p>
                                <p class="text-sm font-black text-white mt-0.5 leading-snug">Autopista Colima Manzanillo Km. 4, Colima, México, CP 28060</p>
                            </div>
                        </div>

                        <div class="p-6 bg-slate-900 border border-slate-800 rounded-3xl flex items-center gap-5">
                            <div class="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
                                <span class="material-icons">call</span>
                            </div>
                            <div>
                                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Teléfono de Atención</p>
                                <a href="tel:+13123070233" class="text-sm font-black text-white hover:text-primary transition-colors mt-0.5 block">+1 312-307-0233</a>
                            </div>
                        </div>

                        <div class="p-6 bg-slate-900 border border-slate-800 rounded-3xl flex items-center gap-5">
                            <div class="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                                <span class="material-icons">chat</span>
                            </div>
                            <div>
                                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">WhatsApp Directo</p>
                                <a href="https://wa.me/5213121942559" target="_blank" class="text-sm font-black text-emerald-400 hover:underline mt-0.5 block">+52 1 312 194 2559</a>
                            </div>
                        </div>

                        <div class="p-6 bg-slate-900 border border-slate-800 rounded-3xl flex items-center gap-5">
                            <div class="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                                <span class="material-icons">email</span>
                            </div>
                            <div>
                                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Correo Electrónico</p>
                                <a href="mailto:golf.colima@gmail.com" class="text-sm font-black text-white hover:text-amber-400 transition-colors mt-0.5 block">golf.colima@gmail.com</a>
                            </div>
                        </div>
                    </div>

                    <!-- Map / Location Showcase -->
                    <div class="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-4 overflow-hidden relative min-h-[350px] flex flex-col justify-between">
                        <div class="relative w-full h-full min-h-[300px] rounded-2xl overflow-hidden">
                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15064.912384747285!2d-103.7383125!3d19.2721875!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x84255aa0a66d0001%3A0x8849b294c65db55b!2sClub%20de%20Golf%20de%20Colima!5e0!3m2!1ses!2smx!4v1700000000000!5m2!1ses!2smx"
                                class="w-full h-full border-0 absolute inset-0 filter invert opacity-80 contrast-125"
                                allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                        <div class="pt-4 flex items-center justify-between gap-4">
                            <span class="text-xs font-bold text-slate-400">Autopista Colima Manzanillo Km. 4</span>
                            <a href="https://maps.google.com/?q=Club+de+Golf+de+Colima" target="_blank" class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-black uppercase transition-all">
                                Abrir en Google Maps ➔
                            </a>
                        </div>
                    </div>
                </div>
            </section>

            <!-- 7. FOOTER -->
            <footer class="border-t border-slate-800/80 bg-slate-950 py-12 px-4 sm:px-8 text-center text-xs text-slate-500 font-bold uppercase tracking-wider">
                <div class="max-w-7xl mx-auto space-y-8">
                    <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
                        <div class="flex items-center gap-3">
                            <img src="./golcolima.jpg" alt="Logo Colima GC" class="h-8 w-auto rounded-lg">
                            <span>© 2026 Club de Golf Colima. Todos los derechos reservados.</span>
                        </div>
                        <div class="flex items-center gap-6">
                            <a href="https://clubdegolfdecolima.com" target="_blank" class="hover:text-primary transition-colors">clubdegolfdecolima.com</a>
                            <a href="#admin" onclick="if (window.renderLogin) window.renderLogin();" class="hover:text-amber-400 transition-colors">Acceso Administrador</a>
                        </div>
                    </div>

                    <!-- GooWeb Branding Badge -->
                    <div class="pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-center gap-3">
                        <span class="text-[11px] text-slate-500 font-semibold normal-case tracking-normal">Diseño y Desarrollo Web por</span>
                        <a href="https://gooweb.click/" target="_blank" rel="noopener noreferrer"
                           class="inline-flex items-center gap-2.5 px-4 py-2 bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 hover:border-emerald-500/50 rounded-2xl transition-all duration-300 group shadow-lg hover:shadow-emerald-500/10 hover:scale-105"
                           title="Visitar GooWeb">
                            <img src="./gooweb1.png" alt="GooWeb" class="h-6 w-auto object-contain transition-transform group-hover:scale-110">
                            <span class="text-xs font-black text-slate-300 group-hover:text-white tracking-wide uppercase">GooWeb</span>
                            <span class="material-icons text-slate-500 group-hover:text-emerald-400 text-xs transition-colors">open_in_new</span>
                        </a>
                    </div>
                </div>
            </footer>

            <!-- EVENT MODAL -->
            <div id="event-modal" class="hidden fixed inset-0 z-[100] items-center justify-center p-4 sm:p-6 opacity-0 transition-opacity duration-300">
                <!-- Backdrop -->
                <div class="absolute inset-0 bg-slate-950/90 backdrop-blur-sm cursor-pointer" onclick="closeEventModal()"></div>
                
                <!-- Modal Content -->
                <div class="relative w-full max-w-5xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row transform scale-95 transition-transform duration-300" id="event-modal-content">
                    
                    <!-- Close button -->
                    <button onclick="closeEventModal()" class="absolute top-4 right-4 z-10 w-10 h-10 bg-slate-950/50 hover:bg-slate-800 text-white rounded-full flex items-center justify-center backdrop-blur-md border border-white/10 transition-all">
                        <span class="material-icons">close</span>
                    </button>

                    <!-- Image Section -->
                    <div class="w-full md:w-3/5 lg:w-2/3 bg-black flex items-center justify-center max-h-[50vh] md:max-h-[85vh] overflow-hidden">
                        <img id="modal-img" src="" alt="Evento" class="w-full h-full object-contain">
                    </div>

                    <!-- Details Section -->
                    <div class="w-full md:w-2/5 lg:w-1/3 p-6 sm:p-8 flex flex-col justify-center max-h-[40vh] md:max-h-[85vh] overflow-y-auto">
                        <div class="space-y-6">
                            <div>
                                <span class="px-3 py-1 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 font-black text-[10px] uppercase tracking-widest rounded-full inline-block mb-4">Detalles del Evento</span>
                                <h3 id="modal-title" class="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight leading-tight"></h3>
                            </div>
                            
                            <div class="flex items-center gap-3 p-4 bg-slate-950/50 rounded-2xl border border-slate-800">
                                <div class="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-primary shrink-0">
                                    <span class="material-icons">event</span>
                                </div>
                                <div>
                                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Fecha</p>
                                    <p id="modal-date" class="text-sm font-black text-white"></p>
                                </div>
                            </div>

                            <p id="modal-desc" class="text-sm text-slate-300 leading-relaxed font-medium"></p>
                            
                            <div class="pt-4 mt-auto space-y-3">
                                <!-- Boton Leaderboard en Vivo si el evento tiene torneo vinculado -->
                                <button id="modal-leaderboard-btn" onclick="openEventTournamentLeaderboard()"
                                    class="hidden w-full px-6 py-4 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 font-black rounded-xl text-xs sm:text-sm uppercase tracking-wider shadow-xl shadow-amber-500/20 transition-all items-center justify-center text-center gap-2 hover:-translate-y-1 cursor-pointer">
                                    <span class="material-icons text-lg">emoji_events</span>
                                    <span>VER LEADERBOARD Y SALIDAS EN VIVO</span>
                                </button>

                                <a href="https://wa.me/5213121942559?text=Hola,%20me%20gustar%C3%ADa%20m%C3%A1s%20informaci%C3%B3n%20sobre%20los%20eventos" target="_blank"
                                    class="w-full px-6 py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs sm:text-sm uppercase tracking-wider shadow-xl shadow-emerald-500/20 transition-all flex items-center justify-center text-center gap-2 hover:-translate-y-1">
                                    <svg class="w-5 h-5 fill-current shrink-0" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
                                    <span>Solicitar Información</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TEE TIME BOOKING MODAL -->
            <div id="teetime-modal" class="hidden fixed inset-0 z-[100] items-center justify-center p-4 sm:p-6 opacity-0 transition-opacity duration-300">
                <!-- Backdrop -->
                <div class="absolute inset-0 bg-slate-950/90 backdrop-blur-md cursor-pointer" onclick="closeTeeTimeModal()"></div>
                
                <!-- Modal Content -->
                <div class="relative w-full max-w-2xl bg-slate-900 border border-emerald-500/30 rounded-3xl shadow-2xl overflow-hidden flex flex-col transform scale-95 transition-transform duration-300 my-auto max-h-[92vh]" id="teetime-modal-content">
                    
                    <!-- Header -->
                    <div class="p-6 pb-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                                <span class="material-icons">golf_course</span>
                            </div>
                            <div>
                                <h3 class="text-xl sm:text-2xl font-black text-white uppercase tracking-tight">Reservar Salida / Tee Time</h3>
                                <p class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Club de Golf Colima · Campo de 18 Hoyos</p>
                            </div>
                        </div>
                        <button onclick="closeTeeTimeModal()" class="w-9 h-9 bg-slate-800 hover:bg-slate-700 text-white rounded-full flex items-center justify-center border border-white/10 transition-all cursor-pointer">
                            <span class="material-icons text-sm">close</span>
                        </button>
                    </div>

                    <!-- Scrollable Form Body -->
                    <form id="teetime-form" onsubmit="handleTeeTimeSubmit(event)" class="p-6 space-y-5 overflow-y-auto max-h-[75vh]">
                        
                        <!-- Socio vs Invitado selector -->
                        <div class="space-y-1.5">
                            <label class="text-[11px] font-black text-slate-300 uppercase tracking-wider">Tipo de Jugador</label>
                            <div class="grid grid-cols-2 gap-3">
                                <label class="cursor-pointer">
                                    <input type="radio" name="tipo_jugador" value="Socio" checked class="peer hidden">
                                    <div class="p-3 text-center rounded-2xl border border-slate-700 bg-slate-800/60 peer-checked:bg-emerald-500 peer-checked:text-slate-950 peer-checked:border-emerald-400 font-black text-xs uppercase tracking-wider transition-all">
                                        ⭐ Socio del Club
                                    </div>
                                </label>
                                <label class="cursor-pointer">
                                    <input type="radio" name="tipo_jugador" value="Invitado / No Socio" class="peer hidden">
                                    <div class="p-3 text-center rounded-2xl border border-slate-700 bg-slate-800/60 peer-checked:bg-emerald-500 peer-checked:text-slate-950 peer-checked:border-emerald-400 font-black text-xs uppercase tracking-wider transition-all">
                                        🏌️ Invitado / No Socio
                                    </div>
                                </label>
                            </div>
                        </div>

                        <!-- Nombre & Teléfono -->
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div class="space-y-1.5">
                                <label class="text-[11px] font-black text-slate-300 uppercase tracking-wider">Nombre Completo *</label>
                                <input type="text" id="tt-nombre" required placeholder="Tu nombre y apellido"
                                    class="w-full px-4 py-3 bg-slate-950 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl text-sm font-medium text-white placeholder-slate-500 outline-none transition-all">
                            </div>
                            <div class="space-y-1.5">
                                <label class="text-[11px] font-black text-slate-300 uppercase tracking-wider">Teléfono / WhatsApp *</label>
                                <input type="tel" id="tt-telefono" required placeholder="Ej: 312 123 4567"
                                    class="w-full px-4 py-3 bg-slate-950 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl text-sm font-medium text-white placeholder-slate-500 outline-none transition-all">
                            </div>
                        </div>

                        <!-- Fecha & Horario -->
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div class="space-y-1.5">
                                <label class="text-[11px] font-black text-slate-300 uppercase tracking-wider">Fecha de Juego *</label>
                                <input type="date" id="tt-fecha" required
                                    class="w-full px-4 py-3 bg-slate-950 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl text-sm font-medium text-white outline-none transition-all">
                            </div>
                            <div class="space-y-1.5">
                                <label class="text-[11px] font-black text-slate-300 uppercase tracking-wider">Horario Deseado *</label>
                                <select id="tt-hora" required
                                    class="w-full px-4 py-3 bg-slate-950 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl text-sm font-medium text-white outline-none transition-all">
                                    <option value="07:00 AM">07:00 AM (Primera Salida)</option>
                                    <option value="07:30 AM">07:30 AM</option>
                                    <option value="08:00 AM" selected>08:00 AM</option>
                                    <option value="08:30 AM">08:30 AM</option>
                                    <option value="09:00 AM">09:00 AM</option>
                                    <option value="09:30 AM">09:30 AM</option>
                                    <option value="10:00 AM">10:00 AM</option>
                                    <option value="10:30 AM">10:30 AM</option>
                                    <option value="11:00 AM">11:00 AM</option>
                                    <option value="12:00 PM">12:00 PM</option>
                                    <option value="01:00 PM">01:00 PM</option>
                                    <option value="02:00 PM">02:00 PM</option>
                                    <option value="03:00 PM">03:00 PM (Tarde)</option>
                                    <option value="04:00 PM">04:00 PM (Tarde 9 Hoyos)</option>
                                </select>
                            </div>
                        </div>

                        <!-- Número de Jugadores & Salida -->
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div class="space-y-1.5">
                                <label class="text-[11px] font-black text-slate-300 uppercase tracking-wider">Número de Jugadores</label>
                                <select id="tt-jugadores"
                                    class="w-full px-4 py-3 bg-slate-950 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl text-sm font-medium text-white outline-none transition-all">
                                    <option value="1">1 Jugador (Individual)</option>
                                    <option value="2">2 Jugadores (Pareja)</option>
                                    <option value="3">3 Jugadores (Trío)</option>
                                    <option value="4" selected>4 Jugadores (Foursome)</option>
                                </select>
                            </div>
                            <div class="space-y-1.5">
                                <label class="text-[11px] font-black text-slate-300 uppercase tracking-wider">Hoyo de Salida</label>
                                <select id="tt-hoyo"
                                    class="w-full px-4 py-3 bg-slate-950 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl text-sm font-medium text-white outline-none transition-all">
                                    <option value="1" selected>Hoyo 1 (Salida Principal)</option>
                                    <option value="10">Hoyo 10 (Segunda Vuelta)</option>
                                </select>
                            </div>
                        </div>

                        <!-- Servicios Adicionales -->
                        <div class="space-y-2 p-4 bg-slate-950/70 rounded-2xl border border-slate-800">
                            <label class="text-[11px] font-black text-slate-300 uppercase tracking-wider block">Servicios Adicionales Requeridos</label>
                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                                <label class="flex items-center gap-2 text-xs font-bold text-slate-300 cursor-pointer p-2 rounded-xl hover:bg-slate-900 transition-colors">
                                    <input type="checkbox" id="tt-carrito" class="w-4 h-4 rounded text-emerald-500 focus:ring-0 bg-slate-900 border-slate-700">
                                    <span>🚗 Carrito de Golf</span>
                                </label>
                                <label class="flex items-center gap-2 text-xs font-bold text-slate-300 cursor-pointer p-2 rounded-xl hover:bg-slate-900 transition-colors">
                                    <input type="checkbox" id="tt-caddie" class="w-4 h-4 rounded text-emerald-500 focus:ring-0 bg-slate-900 border-slate-700">
                                    <span>🏌️‍♂️ Caddie</span>
                                </label>
                                <label class="flex items-center gap-2 text-xs font-bold text-slate-300 cursor-pointer p-2 rounded-xl hover:bg-slate-900 transition-colors">
                                    <input type="checkbox" id="tt-palos" class="w-4 h-4 rounded text-emerald-500 focus:ring-0 bg-slate-900 border-slate-700">
                                    <span>⛳ Renta de Palos</span>
                                </label>
                            </div>
                        </div>

                        <!-- Comentarios / Notas -->
                        <div class="space-y-1.5">
                            <label class="text-[11px] font-black text-slate-300 uppercase tracking-wider">Notas o Peticiones Especiales (Opcional)</label>
                            <textarea id="tt-comentarios" rows="2" placeholder="Nombres de acompañantes, requerimientos especiales, etc."
                                class="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl text-xs font-medium text-white placeholder-slate-500 outline-none transition-all"></textarea>
                        </div>

                        <!-- Submit Button -->
                        <div class="pt-2">
                            <button type="submit" id="tt-submit-btn"
                                class="w-full px-6 py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-sm uppercase tracking-wider shadow-xl shadow-emerald-500/20 transition-all flex items-center justify-center gap-3 hover:-translate-y-0.5 cursor-pointer">
                                <svg class="w-5 h-5 fill-current shrink-0" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
                                <span>Confirmar Reserva & Enviar</span>
                            </button>
                            <p class="text-[10px] text-slate-500 font-bold text-center mt-2 uppercase tracking-wider">
                                🔒 Notifica de inmediato al Caddie Master / Starter del club
                            </p>
                        </div>
                    </form>
                </div>
            </div>

            <!-- 6. NOTICIA COMPLETA MODAL (READER & MULTI-PHOTO GALLERY) -->
            <div id="noticia-modal" class="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md items-center justify-center p-4 hidden opacity-0 transition-opacity duration-300">
                <div id="noticia-modal-content" class="bg-slate-900 border border-slate-800 w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] scale-95 transition-transform duration-300">
                    <!-- Photo Gallery Carousel Header -->
                    <div class="relative aspect-video sm:aspect-[21/9] w-full bg-slate-950 overflow-hidden border-b border-slate-800 group select-none">
                        <img id="noticia-modal-img" src="" alt="Noticia" class="w-full h-full object-cover transition-all duration-300 cursor-pointer" onclick="openLightboxImage()" title="Clic para ampliar foto">
                        <div class="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent pointer-events-none"></div>
                        
                        <!-- Close Button -->
                        <button onclick="closeNoticiaModal()" class="absolute top-4 right-4 w-10 h-10 rounded-full bg-slate-950/80 hover:bg-slate-900 border border-white/20 text-white flex items-center justify-center backdrop-blur-md transition-transform hover:scale-110 cursor-pointer z-10">
                            <span class="material-icons">close</span>
                        </button>

                        <!-- Lightbox expand button -->
                        <button onclick="openLightboxImage()" class="absolute top-4 left-4 px-3 py-1.5 rounded-xl bg-slate-950/80 hover:bg-slate-900 border border-white/20 text-white flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider backdrop-blur-md transition-transform hover:scale-105 cursor-pointer z-10">
                            <span class="material-icons text-xs">fullscreen</span> Ampliar
                        </button>

                        <!-- Prev / Next Carousel Arrows -->
                        <button id="btn-gallery-prev" onclick="prevGalleryImage()" class="absolute left-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-slate-950/80 hover:bg-amber-500 hover:text-slate-950 border border-white/20 text-white flex items-center justify-center backdrop-blur-md transition-all hover:scale-110 cursor-pointer z-10 hidden">
                            <span class="material-icons">chevron_left</span>
                        </button>
                        <button id="btn-gallery-next" onclick="nextGalleryImage()" class="absolute right-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-slate-950/80 hover:bg-amber-500 hover:text-slate-950 border border-white/20 text-white flex items-center justify-center backdrop-blur-md transition-all hover:scale-110 cursor-pointer z-10 hidden">
                            <span class="material-icons">chevron_right</span>
                        </button>

                        <!-- Bottom Badges: Photo Counter -->
                        <div class="absolute bottom-4 right-6 flex items-center justify-end z-10 pointer-events-none">
                            <span id="noticia-modal-counter" class="px-3 py-1 bg-slate-950/80 border border-slate-700 text-white rounded-xl text-[10px] font-black uppercase tracking-wider hidden backdrop-blur-md"></span>
                        </div>
                    </div>

                    <!-- Thumbnails Strip (if multiple photos) -->
                    <div id="noticia-modal-thumbnails" class="px-6 py-3 bg-slate-950/90 border-b border-slate-800 flex items-center gap-2.5 overflow-x-auto hidden">
                        <!-- Dynamic thumbnails -->
                    </div>

                    <!-- Content Body -->
                    <div class="p-6 sm:p-8 overflow-y-auto space-y-4 flex-1">
                        <div class="flex items-center gap-3 text-xs font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 pb-3">
                            <span class="flex items-center gap-1"><span class="material-icons text-sm text-amber-400">event</span> <span id="noticia-modal-date"></span></span>
                            <span>·</span>
                            <span class="flex items-center gap-1"><span class="material-icons text-sm text-slate-500">person</span> <span id="noticia-modal-author"></span></span>
                        </div>
                        <h2 id="noticia-modal-title" class="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight leading-snug"></h2>
                        <div id="noticia-modal-body" class="text-slate-300 text-sm leading-relaxed whitespace-pre-line font-medium pt-2"></div>
                    </div>

                    <!-- Footer -->
                    <div class="p-4 px-8 border-t border-slate-800 bg-slate-950/50 flex justify-end">
                        <button onclick="closeNoticiaModal()" class="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-xs uppercase tracking-wider transition-colors cursor-pointer">
                            Cerrar
                        </button>
                    </div>
                </div>
            </div>

            <!-- 7. MODAL VER TODAS LAS NOTICIAS -->
            <div id="all-noticias-modal" class="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl items-center justify-center p-4 sm:p-6 hidden opacity-0 transition-opacity duration-300">
                <div id="all-noticias-modal-content" class="bg-slate-900 border border-slate-800 w-full max-w-6xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] scale-95 transition-transform duration-300">
                    <!-- Header -->
                    <div class="p-6 sm:p-8 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-950/80">
                        <div>
                            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[10px] font-black uppercase tracking-widest mb-1.5">
                                <span class="material-icons text-xs">collections_bookmark</span> Hemeroteca Oficial
                            </div>
                            <h3 class="text-2xl font-black text-white uppercase tracking-tight">Todas las Noticias</h3>
                            <p class="text-xs text-slate-400 mt-0.5">Explora el historial completo de comunicados y notas del Club de Golf Colima.</p>
                        </div>
                        <div class="flex items-center gap-3">
                            <div class="relative">
                                <span class="material-icons absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm">search</span>
                                <input type="text" id="input-search-all-noticias" placeholder="Buscar por título o contenido..." class="pl-9 pr-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-all font-medium w-48 sm:w-72">
                            </div>
                            <button onclick="closeAllNoticiasModal()" class="w-10 h-10 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer">
                                <span class="material-icons">close</span>
                            </button>
                        </div>
                    </div>

                    <!-- Grid de Todas las Noticias -->
                    <div class="p-6 sm:p-8 overflow-y-auto flex-1">
                        <div id="all-noticias-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                            <!-- Rendered dynamically -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- 8. VISOR FULLSCREEN LIGHTBOX (AMPLIAR FOTO HD CON NAVEGACIÓN Y FLECHAS) -->
            <div id="lightbox-modal" class="fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl items-center justify-center p-4 hidden opacity-0 transition-opacity duration-300 select-none" onclick="closeLightboxImage()">
                <!-- Close Button -->
                <button onclick="closeLightboxImage()" class="absolute top-6 right-6 w-12 h-12 rounded-full bg-white/10 hover:bg-white/25 text-white flex items-center justify-center transition-all cursor-pointer z-50 backdrop-blur-md">
                    <span class="material-icons text-2xl">close</span>
                </button>

                <!-- Prev Arrow Fullscreen -->
                <button id="btn-lightbox-prev" onclick="event.stopPropagation(); prevGalleryImage(); updateLightboxImage();" class="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 w-14 h-14 rounded-full bg-slate-900/80 hover:bg-amber-500 hover:text-slate-950 text-white border border-white/20 flex items-center justify-center backdrop-blur-md transition-all hover:scale-110 cursor-pointer z-50 shadow-2xl hidden">
                    <span class="material-icons text-3xl">chevron_left</span>
                </button>

                <!-- Next Arrow Fullscreen -->
                <button id="btn-lightbox-next" onclick="event.stopPropagation(); nextGalleryImage(); updateLightboxImage();" class="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 w-14 h-14 rounded-full bg-slate-900/80 hover:bg-amber-500 hover:text-slate-950 text-white border border-white/20 flex items-center justify-center backdrop-blur-md transition-all hover:scale-110 cursor-pointer z-50 shadow-2xl hidden">
                    <span class="material-icons text-3xl">chevron_right</span>
                </button>

                <!-- Main Image Container -->
                <div class="relative flex flex-col items-center justify-center max-h-[90vh] max-w-[95vw]" onclick="event.stopPropagation()">
                    <img id="lightbox-img" src="" alt="Foto en alta resolución" class="max-h-[85vh] max-w-[92vw] object-contain rounded-2xl shadow-2xl transition-all duration-300">
                    <div class="mt-4 flex items-center gap-3">
                        <span id="lightbox-counter" class="px-4 py-1.5 bg-slate-900/90 border border-slate-700 text-amber-400 rounded-full text-xs font-black uppercase tracking-wider backdrop-blur-md shadow-lg hidden"></span>
                    </div>
                </div>
            </div>
        </div>
    `,X(),window.toggleMobileMenu=function(){let e=document.getElementById(`mobile-menu-drawer`),t=document.getElementById(`icon-mobile-toggle`);e&&(e.classList.contains(`hidden`)?(e.classList.remove(`hidden`),setTimeout(()=>{e.classList.remove(`max-h-0`,`opacity-0`),e.classList.add(`max-h-96`,`opacity-100`)},10),t&&(t.textContent=`close`)):(e.classList.remove(`max-h-96`,`opacity-100`),e.classList.add(`max-h-0`,`opacity-0`),t&&(t.textContent=`menu`),setTimeout(()=>{e.classList.add(`hidden`)},300)))},window.selectRankingTournament=function(e,t,n,r){let i=document.getElementById(`ranking-main-cta-btn`),a=document.getElementById(`ranking-cta-text`),o=document.getElementById(`ranking-cta-icon`),s=document.getElementById(`ranking-btn-fecha-1`),c=document.getElementById(`ranking-btn-fecha-2`),l=document.getElementById(`ranking-btn-fecha-3`);[s,c,l,document.getElementById(`ranking-btn-fecha-4`)].forEach(e=>{e&&e.classList.remove(`ring-2`,`ring-emerald-500/60`,`ring-amber-500/80`,`ring-emerald-500/40`,`ring-amber-500/40`)});let u=r?document.getElementById(`ranking-btn-fecha-${r}`):n?l:s;n?(i&&(i.className=`w-full sm:w-auto px-8 py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-2xl text-xs sm:text-sm uppercase tracking-widest shadow-2xl shadow-emerald-500/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3 cursor-pointer`,i.onclick=()=>window.openLiveLeaderboardModal(e)),a&&(a.textContent=`VER LEADERBOARD EN VIVO (${t})`),o&&(o.textContent=`emoji_events`),u&&u.classList.add(`ring-2`,`ring-emerald-500/60`)):(i&&(i.className=`w-full sm:w-auto px-8 py-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-2xl text-xs sm:text-sm uppercase tracking-widest shadow-2xl shadow-amber-500/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3 cursor-pointer`,i.onclick=()=>window.openLiveLeaderboardModal(e)),a&&(a.textContent=`VER RESULTADOS OFICIALES (${t} · FINALIZADO)`),o&&(o.textContent=`history`),u&&u.classList.add(`ring-2`,`ring-amber-500/80`)),window.openLiveLeaderboardModal&&window.openLiveLeaderboardModal(e)};let y=0,b=v.length;window.goToEventPage=function(e){if(e<0||e>=b)return;y=e;let t=document.getElementById(`eventos-slides-track`),n=document.getElementById(`eventos-page-indicator`),r=document.getElementById(`btn-eventos-prev`),i=document.getElementById(`btn-eventos-next`),a=document.querySelectorAll(`.evento-dot`);t&&(t.style.transform=`translateX(-${y*100}%)`),n&&(n.textContent=`Mostrando ${y+1} de ${b}`),r&&(r.disabled=y===0),i&&(i.disabled=y===b-1),a.forEach((e,t)=>{e.className=t===y?`evento-dot w-8 h-2.5 rounded-full bg-purple-500 transition-all cursor-pointer`:`evento-dot w-2.5 h-2.5 rounded-full bg-slate-700 hover:bg-slate-500 transition-all cursor-pointer`})},window.navigateEventos=function(e){window.goToEventPage(y+e)};let x=null;window.openEventModal=function(e,t,n,r,i){document.getElementById(`modal-img`).src=e,document.getElementById(`modal-title`).innerText=t,document.getElementById(`modal-desc`).innerText=n,document.getElementById(`modal-date`).innerText=r,x=i||null;let a=document.getElementById(`modal-leaderboard-btn`);a&&(x?(a.classList.remove(`hidden`),a.classList.add(`flex`)):(a.classList.add(`hidden`),a.classList.remove(`flex`)));let o=document.getElementById(`event-modal`),s=document.getElementById(`event-modal-content`);o.classList.remove(`hidden`),o.classList.add(`flex`),setTimeout(()=>{o.classList.remove(`opacity-0`),o.classList.add(`opacity-100`),s.classList.remove(`scale-95`),s.classList.add(`scale-100`)},10),document.body.style.overflow=`hidden`},window.openEventTournamentLeaderboard=function(){x&&window.openLiveLeaderboardModal&&(window.closeEventModal(),setTimeout(()=>{window.openLiveLeaderboardModal(x)},300))},window.closeEventModal=function(){let e=document.getElementById(`event-modal`),t=document.getElementById(`event-modal-content`);e.classList.remove(`opacity-100`),e.classList.add(`opacity-0`),t.classList.remove(`scale-100`),t.classList.add(`scale-95`),setTimeout(()=>{e.classList.add(`hidden`),e.classList.remove(`flex`),document.body.style.overflow=``},300)};let S=[],C=0,w=()=>{let e=document.getElementById(`noticia-modal-img`),t=document.getElementById(`noticia-modal-counter`),n=document.getElementById(`btn-gallery-prev`),r=document.getElementById(`btn-gallery-next`),i=document.getElementById(`noticia-modal-thumbnails`);!e||S.length===0||(e.src=S[C],S.length>1?(n.classList.remove(`hidden`),r.classList.remove(`hidden`),t.classList.remove(`hidden`),t.innerText=`Foto ${C+1} de ${S.length}`,i.classList.remove(`hidden`),i.innerHTML=S.map((e,t)=>`
                <button onclick="selectGalleryImage(${t})" class="relative w-16 h-12 rounded-xl overflow-hidden border-2 shrink-0 transition-all cursor-pointer ${t===C?`border-amber-400 scale-105 shadow-md shadow-amber-500/20`:`border-slate-800 opacity-60 hover:opacity-100`}">
                    <img src="${e}" alt="Miniatura ${t+1}" class="w-full h-full object-cover">
                </button>
            `).join(``)):(n.classList.add(`hidden`),r.classList.add(`hidden`),t.classList.add(`hidden`),i.classList.add(`hidden`)))};window.prevGalleryImage=function(){S.length<=1||(C=(C-1+S.length)%S.length,w(),updateLightboxImage())},window.nextGalleryImage=function(){S.length<=1||(C=(C+1)%S.length,w(),updateLightboxImage())},window.selectGalleryImage=function(e){e>=0&&e<S.length&&(C=e,w(),updateLightboxImage())},window.updateLightboxImage=function(){let e=document.getElementById(`lightbox-img`),t=document.getElementById(`lightbox-counter`),n=document.getElementById(`btn-lightbox-prev`),r=document.getElementById(`btn-lightbox-next`);!e||S.length===0||(e.src=S[C],S.length>1?(n&&n.classList.remove(`hidden`),r&&r.classList.remove(`hidden`),t&&(t.classList.remove(`hidden`),t.innerText=`Foto ${C+1} de ${S.length}`)):(n&&n.classList.add(`hidden`),r&&r.classList.add(`hidden`),t&&t.classList.add(`hidden`)))},window.openLightboxImage=function(){if(S.length===0)return;let e=document.getElementById(`lightbox-modal`);e&&(window.updateLightboxImage(),e.classList.remove(`hidden`),e.classList.add(`flex`),setTimeout(()=>{e.classList.remove(`opacity-0`),e.classList.add(`opacity-100`)},10))},window.closeLightboxImage=function(){let e=document.getElementById(`lightbox-modal`);e&&(e.classList.remove(`opacity-100`),e.classList.add(`opacity-0`),setTimeout(()=>{e.classList.add(`hidden`),e.classList.remove(`flex`)},300))},window._lightboxKeydownBound||(window._lightboxKeydownBound=!0,document.addEventListener(`keydown`,e=>{let t=document.getElementById(`lightbox-modal`);t&&!t.classList.contains(`hidden`)&&(e.key===`ArrowLeft`?window.prevGalleryImage():e.key===`ArrowRight`?window.nextGalleryImage():e.key===`Escape`&&window.closeLightboxImage())})),window.openNoticiaModal=function(e){let t=p.find(t=>t.id===e);if(!t)return;let n=document.getElementById(`noticia-modal`),r=document.getElementById(`noticia-modal-content`);S=d(t),C=0,document.getElementById(`noticia-modal-title`).innerText=t.titulo,document.getElementById(`noticia-modal-date`).innerText=t.fecha_publicacion?new Date(t.fecha_publicacion+`T00:00:00`).toLocaleDateString(`es-MX`,{day:`2-digit`,month:`long`,year:`numeric`}):``,document.getElementById(`noticia-modal-author`).innerText=t.autor||`Club de Golf Colima`,document.getElementById(`noticia-modal-body`).innerText=t.contenido||``,w(),n.classList.remove(`hidden`),n.classList.add(`flex`),setTimeout(()=>{n.classList.remove(`opacity-0`),n.classList.add(`opacity-100`),r.classList.remove(`scale-95`),r.classList.add(`scale-100`)},10),document.body.style.overflow=`hidden`},window.closeNoticiaModal=function(){let e=document.getElementById(`noticia-modal`),t=document.getElementById(`noticia-modal-content`);e&&(e.classList.remove(`opacity-100`),e.classList.add(`opacity-0`),t.classList.remove(`scale-100`),t.classList.add(`scale-95`),setTimeout(()=>{e.classList.add(`hidden`),e.classList.remove(`flex`),document.body.style.overflow=``},300))};let T=(e=``)=>{let t=document.getElementById(`all-noticias-grid`);if(!t)return;let n=e.toLowerCase().trim(),r=p.filter(e=>!n||e.titulo&&e.titulo.toLowerCase().includes(n)||e.contenido&&e.contenido.toLowerCase().includes(n));if(r.length===0){t.innerHTML=`
                <div class="col-span-full py-16 text-center text-slate-500 space-y-2">
                    <span class="material-icons text-3xl">search_off</span>
                    <p class="text-xs font-bold uppercase tracking-wider">No se encontraron noticias con "${e}"</p>
                </div>
            `;return}t.innerHTML=r.map(e=>{let t=d(e),n=t[0]||`./imagenes/feria.jpeg`;return`
                <div class="group relative rounded-3xl overflow-hidden border border-slate-800 hover:border-amber-500/60 aspect-[4/3] bg-slate-900 shadow-xl cursor-pointer transition-all duration-300 transform hover:-translate-y-1.5" onclick="openNoticiaModal('${e.id}')">
                    <img src="${n}" alt="${e.titulo}" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" onerror="this.src='./golcolima.jpg'" loading="lazy">
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-950/95 via-slate-950/30 to-transparent p-6 flex flex-col justify-end">
                        ${t.length>1?`
                            <div class="absolute top-4 right-4">
                                <span class="px-2.5 py-1 bg-slate-950/85 border border-slate-700/80 text-amber-300 rounded-xl text-[9px] font-black uppercase flex items-center gap-1 backdrop-blur-md shadow-lg">
                                    <span class="material-icons" style="font-size:12px">collections</span> ${t.length} fotos
                                </span>
                            </div>
                        `:``}
                        
                        <h4 class="text-base sm:text-lg font-black text-white uppercase tracking-tight leading-snug group-hover:text-amber-400 transition-colors line-clamp-2">
                            ${e.titulo}
                        </h4>
                    </div>
                </div>
            `}).join(``)};window.openAllNoticiasModal=function(){let e=document.getElementById(`all-noticias-modal`),t=document.getElementById(`all-noticias-modal-content`),n=document.getElementById(`input-search-all-noticias`);e&&(n&&(n.value=``,n.oninput=e=>T(e.target.value)),T(),e.classList.remove(`hidden`),e.classList.add(`flex`),setTimeout(()=>{e.classList.remove(`opacity-0`),e.classList.add(`opacity-100`),t.classList.remove(`scale-95`),t.classList.add(`scale-100`)},10),document.body.style.overflow=`hidden`)},window.closeAllNoticiasModal=function(){let e=document.getElementById(`all-noticias-modal`),t=document.getElementById(`all-noticias-modal-content`);e&&(e.classList.remove(`opacity-100`),e.classList.add(`opacity-0`),t.classList.remove(`scale-100`),t.classList.add(`scale-95`),setTimeout(()=>{e.classList.add(`hidden`),e.classList.remove(`flex`),document.body.style.overflow=``},300))},window.openTeeTimeModal=function(){let e=document.getElementById(`teetime-modal`),t=document.getElementById(`teetime-modal-content`),n=document.getElementById(`tt-fecha`);if(n&&!n.value){let e=new Date().toISOString().split(`T`)[0];n.min=e,n.value=e}e.classList.remove(`hidden`),e.classList.add(`flex`),setTimeout(()=>{e.classList.remove(`opacity-0`),e.classList.add(`opacity-100`),t.classList.remove(`scale-95`),t.classList.add(`scale-100`)},10),document.body.style.overflow=`hidden`},window.closeTeeTimeModal=function(){let e=document.getElementById(`teetime-modal`),t=document.getElementById(`teetime-modal-content`);e.classList.remove(`opacity-100`),e.classList.add(`opacity-0`),t.classList.remove(`scale-100`),t.classList.add(`scale-95`),setTimeout(()=>{e.classList.add(`hidden`),e.classList.remove(`flex`),document.body.style.overflow=``},300)},window.handleTeeTimeSubmit=async function(e){e.preventDefault();let t=document.getElementById(`tt-submit-btn`),n=t.innerHTML;t.disabled=!0,t.innerHTML=`<span class="material-icons animate-spin" style="font-size:18px">refresh</span> Guardando Solicitud...`;let r=document.querySelector(`input[name="tipo_jugador"]:checked`)?.value||`Socio`,i=document.getElementById(`tt-nombre`)?.value?.trim()||``,a=document.getElementById(`tt-telefono`)?.value?.trim()||``,o=document.getElementById(`tt-fecha`)?.value||``,s=document.getElementById(`tt-hora`)?.value||`08:00 AM`,c=document.getElementById(`tt-jugadores`)?.value||`1`,l=document.getElementById(`tt-hoyo`)?.value||`1`,u=document.getElementById(`tt-carrito`)?.checked||!1,d=document.getElementById(`tt-caddie`)?.checked||!1,f=document.getElementById(`tt-palos`)?.checked||!1,p=document.getElementById(`tt-comentarios`)?.value?.trim()||`Ninguno`;try{await J.from(`reservas_tee_time`).insert([{nombre_jugador:i,telefono:a,tipo_jugador:r,fecha_reserva:o,hora_reserva:s,num_jugadores:parseInt(c,10)||1,hoyo_salida:parseInt(l,10)||1,requiere_carrito:u,requiere_caddie:d,requiere_palos:f,comentarios:p===`Ninguno`?null:p,estado:`pendiente`}])}catch(e){console.warn(`Nota inserción Supabase:`,e)}let m=[];u&&m.push(`Carrito de Golf`),d&&m.push(`Caddie`),f&&m.push(`Renta de Palos`);let h=`⛳ *SOLICITUD DE TEE TIME - CLUB DE GOLF COLIMA*
━━━━━━━━━━━━━━━━━━━━━
👤 *Nombre:* ${i}
📱 *Teléfono:* ${a}
🏷️ *Condición:* ${r}
📅 *Fecha:* ${o}
⏰ *Hora:* ${s}
👥 *Jugadores:* ${c} persona(s)
🚩 *Salida:* Hoyo ${l}
🛒 *Adicionales:* ${m.length>0?m.join(`, `):`Ninguno`}
💬 *Notas:* ${p}
━━━━━━━━━━━━━━━━━━━━━
_Enviado desde el portal oficial Club de Golf Colima_`,g=`https://wa.me/5213121942559?text=${encodeURIComponent(h)}`;window.open(g,`_blank`),t.innerHTML=`<span class="material-icons text-base">check_circle</span> ¡Solicitud Enviada!`,setTimeout(()=>{t.innerHTML=n,t.disabled=!1,document.getElementById(`teetime-form`).reset(),closeTeeTimeModal()},1200)}}function X(){let e=0;setInterval(()=>{let t=document.querySelectorAll(`.hero-slide`);!t||t.length===0||(t[e].classList.remove(`opacity-100`,`scale-105`),t[e].classList.add(`opacity-0`,`scale-100`),e=(e+1)%t.length,t[e].classList.remove(`opacity-0`,`scale-100`),t[e].classList.add(`opacity-100`,`scale-105`))},4500)}var Z=[{name:`Blancas (B)`,rating:66.5,slope:125,par:68},{name:`Doradas (D)`,rating:65.7,slope:122,par:68},{name:`Plata/Rojo (P)`,rating:65.5,slope:121,par:68},{name:`Azul (A)`,rating:68,slope:128,par:68}];function Q(e,t){let n=Math.max(0,parseFloat(e)||0),r=(t.rating||68)-(t.par||68),i=n*(t.slope/113)+r;return Math.max(0,Math.round(i))}window.openPublicHandicapModal=async()=>{let e=document.getElementById(`public-handicap-modal`);e||(e=document.createElement(`div`),e.id=`public-handicap-modal`,document.body.appendChild(e)),e.className=`fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-6 overflow-y-auto animate-fade-in`,e.innerHTML=`
        <div class="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-5xl p-12 flex flex-col items-center justify-center gap-4 text-center shadow-2xl">
            <span class="material-icons text-amber-400 animate-spin text-5xl">sync</span>
            <p class="text-white font-black uppercase text-sm tracking-widest">Cargando Padrón Oficial WHS...</p>
        </div>
    `;try{let{data:e,error:t}=await J.from(`members`).select(`*`).order(`name`,{ascending:!0});if(t)throw t;window._publicMembersList=e||[],window._publicHandicapSearch=``,window._publicHandicapCat=`ALL`,$()}catch(t){console.error(`Error loading public handicaps:`,t),e.innerHTML=`
            <div class="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-8 text-center space-y-4 shadow-2xl">
                <span class="material-icons text-rose-500 text-5xl">error_outline</span>
                <h3 class="text-white font-black text-lg uppercase">Error de Conexión</h3>
                <p class="text-slate-400 text-xs">${t.message||`No se pudieron consultar los handicaps.`}</p>
                <button onclick="closePublicHandicapModal()" class="w-full py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold uppercase text-xs">Cerrar</button>
            </div>
        `}},window.closePublicHandicapModal=()=>{let e=document.getElementById(`public-handicap-modal`);e&&(e.classList.add(`hidden`),e.remove())};function $(){let e=document.getElementById(`public-handicap-modal`);if(!e)return;let t=window._publicMembersList||[],n=(window._publicHandicapSearch||``).toLowerCase().trim(),r=window._publicHandicapCat||`ALL`,i=t.filter(e=>{let t=!n||`${e.name} ${e.member_number}`.toLowerCase().includes(n),i=r===`ALL`||e.category===r;return t&&i}),a=Array.from(new Set(t.map(e=>e.category).filter(Boolean)));e.innerHTML=`
        <div class="bg-slate-900 border border-slate-800 rounded-[2rem] w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-fade-in relative" onclick="event.stopPropagation()">
            
            <!-- HEADER -->
            <div class="p-5 sm:p-6 border-b border-slate-800 bg-slate-950/60 flex flex-wrap items-center justify-between gap-4 shrink-0">
                <div class="flex items-center gap-3">
                    <div class="p-2 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center justify-center text-amber-400">
                        <span class="material-icons text-2xl">analytics</span>
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <h2 class="text-base sm:text-lg font-black text-white uppercase tracking-tight">Padrón de Handicaps Oficial WHS</h2>
                            <span class="hidden sm:inline px-2.5 py-0.5 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 rounded-full text-[9px] font-black uppercase">En Vivo</span>
                        </div>
                        <p class="text-[11px] text-slate-400 font-bold uppercase tracking-wider mt-0.5">Club de Golf Colima · USGA World Handicap System · ${new Date().toLocaleDateString(`es-MX`,{year:`numeric`,month:`long`,day:`numeric`})}</p>
                    </div>
                </div>

                <div class="flex items-center gap-2">
                    <button onclick="printPublicHandicaps()" title="Imprimir o Guardar PDF"
                        class="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-black uppercase transition-all shadow-md cursor-pointer">
                        <span class="material-icons text-sm">print</span> <span class="hidden sm:inline">Imprimir</span>
                    </button>
                    <button onclick="closePublicHandicapModal()" class="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-all cursor-pointer">
                        <span class="material-icons text-lg">close</span>
                    </button>
                </div>
            </div>

            <!-- CONTROLS & SEARCH -->
            <div class="p-4 sm:p-5 border-b border-slate-800 bg-slate-900/90 space-y-3 shrink-0">
                <div class="flex flex-col sm:flex-row gap-3">
                    <!-- Search Input -->
                    <div class="relative flex-1">
                        <input id="public-hdcp-search" type="text" value="${window._publicHandicapSearch||``}"
                            placeholder="BUSCAR JUGADOR POR NOMBRE O # SOCIO..."
                            oninput="onPublicHandicapSearch(this.value)"
                            class="w-full pl-10 pr-4 py-3 bg-slate-800/90 border border-slate-700 rounded-2xl text-white text-xs sm:text-sm font-bold uppercase placeholder:text-slate-500 focus:outline-none focus:border-amber-400 transition-all">
                        <span class="material-icons absolute left-3.5 top-3 text-slate-500 text-lg">search</span>
                    </div>

                    <!-- Category Pills -->
                    <div class="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
                        <button onclick="filterPublicHandicapCat('ALL')"
                            class="px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all shrink-0 ${r===`ALL`?`bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/20`:`bg-slate-800 text-slate-400 hover:text-white border border-slate-700`}">
                            Todos (${t.length})
                        </button>
                        ${a.map(e=>`
                            <button onclick="filterPublicHandicapCat('${e}')"
                                class="px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all shrink-0 ${r===e?`bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/20`:`bg-slate-800 text-slate-400 hover:text-white border border-slate-700`}">
                                ${e}
                            </button>
                        `).join(``)}
                    </div>
                </div>
            </div>

            <!-- CONTENT BODY -->
            <div class="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
                ${i.length===0?`
                    <div class="py-16 text-center text-slate-500 space-y-2">
                        <span class="material-icons text-5xl text-slate-600">search_off</span>
                        <p class="font-black text-xs uppercase tracking-widest">No se encontraron jugadores con ese criterio.</p>
                    </div>
                `:`
                    <!-- TABLA DESKTOP (md:block) -->
                    <div class="hidden md:block overflow-hidden rounded-2xl border border-slate-800 bg-slate-950/40">
                        <table class="w-full text-left border-collapse text-xs">
                            <thead>
                                <tr class="bg-slate-800/80 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-700/80">
                                    <th class="px-4 py-3.5"># Socio</th>
                                    <th class="px-4 py-3.5">Jugador / Socio</th>
                                    <th class="px-4 py-3.5">Categoría</th>
                                    <th class="px-4 py-3.5 text-center bg-amber-500/10 text-amber-300">HDCP Index (WHS)</th>
                                    <th class="px-3 py-3.5 text-center">⚪ Blancas</th>
                                    <th class="px-3 py-3.5 text-center">🟡 Doradas</th>
                                    <th class="px-3 py-3.5 text-center">🔘 Plata</th>
                                    <th class="px-3 py-3.5 text-center">🔵 Azul</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-800/60 font-bold">
                                ${i.map(e=>{let t=e.current_handicap!==void 0&&e.current_handicap!==null?parseFloat(e.current_handicap).toFixed(1):`0.0`,n=Q(t,Z[0]),r=Q(t,Z[1]),i=Q(t,Z[2]),a=Q(t,Z[3]);return`
                                    <tr class="hover:bg-slate-800/40 transition-colors">
                                        <td class="px-4 py-3 text-slate-400 font-mono text-[11px]">${e.member_number||`—`}</td>
                                        <td class="px-4 py-3 text-white font-black uppercase text-sm">${e.name}</td>
                                        <td class="px-4 py-3">
                                            <span class="px-2.5 py-0.5 bg-slate-800 border border-slate-700 text-slate-300 rounded-full text-[9px] font-black uppercase">
                                                ${e.category||`SOCIO`}
                                            </span>
                                        </td>
                                        <td class="px-4 py-3 text-center bg-amber-500/5">
                                            <span class="inline-block px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-xl font-black text-sm shadow-sm">
                                                ${t}
                                            </span>
                                        </td>
                                        <td class="px-3 py-3 text-center text-slate-200 font-black text-sm">${n}</td>
                                        <td class="px-3 py-3 text-center text-amber-300 font-black text-sm">${r}</td>
                                        <td class="px-3 py-3 text-center text-rose-300 font-black text-sm">${i}</td>
                                        <td class="px-3 py-3 text-center text-blue-300 font-black text-sm">${a}</td>
                                    </tr>
                                    `}).join(``)}
                            </tbody>
                        </table>
                    </div>

                    <!-- CARDS MOBILE (md:hidden) -->
                    <div class="md:hidden space-y-3">
                        ${i.map(e=>{let t=e.current_handicap!==void 0&&e.current_handicap!==null?parseFloat(e.current_handicap).toFixed(1):`0.0`,n=Q(t,Z[0]),r=Q(t,Z[1]),i=Q(t,Z[2]),a=Q(t,Z[3]);return`
                            <div class="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3 shadow-lg">
                                <div class="flex items-start justify-between gap-2">
                                    <div class="min-w-0 flex-1">
                                        <p class="text-sm font-black text-white uppercase truncate">${e.name}</p>
                                        <div class="flex items-center gap-2 mt-1">
                                            <span class="text-[10px] font-mono text-slate-400 font-bold">${e.member_number||`SOCIO`}</span>
                                            <span class="px-2 py-0.5 bg-slate-800 text-slate-300 rounded text-[9px] font-black uppercase">${e.category||`SOCIO`}</span>
                                        </div>
                                    </div>
                                    <div class="text-right shrink-0">
                                        <span class="text-[8px] font-black uppercase text-amber-400 tracking-wider block">INDEX WHS</span>
                                        <span class="inline-block px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-xl font-black text-base mt-0.5">
                                            ${t}
                                        </span>
                                    </div>
                                </div>

                                <!-- Mini Grid de Golpes por Tee -->
                                <div class="grid grid-cols-4 gap-1.5 pt-2 border-t border-slate-800/80 text-center">
                                    <div class="p-1.5 rounded-xl bg-slate-900 border border-slate-800">
                                        <span class="text-[8px] font-black text-slate-400 uppercase block truncate">⚪ Blancas</span>
                                        <span class="text-xs font-black text-white">${n}</span>
                                    </div>
                                    <div class="p-1.5 rounded-xl bg-slate-900 border border-slate-800">
                                        <span class="text-[8px] font-black text-amber-400 uppercase block truncate">🟡 Doradas</span>
                                        <span class="text-xs font-black text-amber-300">${r}</span>
                                    </div>
                                    <div class="p-1.5 rounded-xl bg-slate-900 border border-slate-800">
                                        <span class="text-[8px] font-black text-rose-400 uppercase block truncate">🔘 Plata</span>
                                        <span class="text-xs font-black text-rose-300">${i}</span>
                                    </div>
                                    <div class="p-1.5 rounded-xl bg-slate-900 border border-slate-800">
                                        <span class="text-[8px] font-black text-blue-400 uppercase block truncate">🔵 Azul</span>
                                        <span class="text-xs font-black text-blue-300">${a}</span>
                                    </div>
                                </div>
                            </div>
                            `}).join(``)}
                    </div>
                `}
            </div>

            <!-- FOOTER INFO -->
            <div class="p-4 border-t border-slate-800 bg-slate-950/80 flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-500 font-bold uppercase tracking-wider shrink-0">
                <span class="flex items-center gap-1.5">
                    <span class="w-2 h-2 rounded-full bg-emerald-400"></span> Par de Campo: 68 Golpes (IN 34 · OUT 34)
                </span>
                <span>Fórmula Oficial: HCP = Index × (Slope / 113) + (Rating − Par)</span>
            </div>
        </div>
    `}window.onPublicHandicapSearch=e=>{window._publicHandicapSearch=e,$();let t=document.getElementById(`public-hdcp-search`);t&&(t.focus(),t.setSelectionRange(e.length,e.length))},window.filterPublicHandicapCat=e=>{window._publicHandicapCat=e,$()},window.printPublicHandicaps=()=>{let e=window._publicMembersList||[],t=new Date().toLocaleDateString(`es-MX`,{year:`numeric`,month:`long`,day:`numeric`}),n=window.open(``,`_blank`);if(!n)return;let r=e.map(e=>{let t=e.current_handicap!==void 0&&e.current_handicap!==null?parseFloat(e.current_handicap).toFixed(1):`0.0`,n=Q(t,Z[0]),r=Q(t,Z[1]),i=Q(t,Z[2]),a=Q(t,Z[3]);return`
            <tr>
                <td style="padding:6px 8px; border:1px solid #ddd; font-family:monospace;">${e.member_number||`—`}</td>
                <td style="padding:6px 8px; border:1px solid #ddd; font-weight:bold;">${e.name}</td>
                <td style="padding:6px 8px; border:1px solid #ddd; text-transform:uppercase;">${e.category||`SOCIO`}</td>
                <td style="padding:6px 8px; border:1px solid #ddd; text-align:center; font-weight:bold; background:#fef3c7;">${t}</td>
                <td style="padding:6px 8px; border:1px solid #ddd; text-align:center; font-weight:bold;">${n}</td>
                <td style="padding:6px 8px; border:1px solid #ddd; text-align:center; font-weight:bold;">${r}</td>
                <td style="padding:6px 8px; border:1px solid #ddd; text-align:center; font-weight:bold;">${i}</td>
                <td style="padding:6px 8px; border:1px solid #ddd; text-align:center; font-weight:bold;">${a}</td>
            </tr>
        `}).join(``);n.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Padrón Oficial de Handicaps - Club de Golf Colima</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; font-size: 11px; color: #111; }
                h1 { font-size: 18px; margin: 0 0 4px 0; text-transform: uppercase; }
                p { margin: 0 0 14px 0; color: #555; font-size: 10px; }
                table { width: 100%; border-collapse: collapse; margin-top: 10px; }
                th { background: #1e293b; color: white; padding: 8px; font-size: 10px; text-transform: uppercase; border: 1px solid #1e293b; }
            </style>
        </head>
        <body>
            <h1>Club de Golf Colima · Padrón Oficial de Handicaps (WHS)</h1>
            <p>Fecha de emisión: ${t} · Total registrados: ${e.length} jugadores · Par de Campo 68</p>
            <table>
                <thead>
                    <tr>
                        <th># Socio</th>
                        <th>Jugador / Socio</th>
                        <th>Categoría</th>
                        <th>HDCP Index</th>
                        <th>Blancas (66.5/125)</th>
                        <th>Doradas (65.7/122)</th>
                        <th>Plata (65.5/121)</th>
                        <th>Azul (68.0/128)</th>
                    </tr>
                </thead>
                <tbody>
                    ${r}
                </tbody>
            </table>
        </body>
        </html>
    `),n.document.close(),setTimeout(()=>n.print(),500)};export{Y as renderLandingPageModule};